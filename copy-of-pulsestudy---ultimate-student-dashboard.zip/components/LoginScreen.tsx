import React, { useState } from 'react';
import Captcha from './Captcha';

interface LoginScreenProps {
  setUserName: (name: string) => void;
  onSignUp: (name: string, email: string) => void;
}

const extractNameFromEmail = (email: string): string => {
    const namePart = email.split('@')[0];
    const name = namePart.replace(/[\._0-9]/g, ' ');
    return name.charAt(0).toUpperCase() + name.slice(1).split(' ')[0];
};

const LoginScreen: React.FC<LoginScreenProps> = ({ setUserName, onSignUp }) => {
    const [nameInput, setNameInput] = useState('');
    const [isFadingOut, setIsFadingOut] = useState(false);
    
    // Sign-up flow state
    const [step, setStep] = useState<'initial' | 'email' | 'captcha'>('initial');
    const [email, setEmail] = useState('');
    const [emailError, setEmailError] = useState('');

    const handleLogin = () => {
        const trimmedName = nameInput.trim();
        if (trimmedName) {
            setIsFadingOut(true);
            setTimeout(() => {
                setUserName(trimmedName);
            }, 500);
        }
    };
    
    const handleGoogleSignUpClick = () => {
        setStep('email');
    };

    const handleEmailSubmit = () => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailRegex.test(email)) {
            setEmailError('');
            setStep('captcha');
        } else {
            setEmailError('Please enter a valid email address.');
        }
    };
    
    const handleCaptchaVerify = (isVerified: boolean) => {
        if (isVerified) {
            setIsFadingOut(true);
            setTimeout(() => {
                const derivedName = extractNameFromEmail(email);
                onSignUp(derivedName, email);
            }, 500);
        }
    };
    
    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, action: 'login' | 'email') => {
        if (e.key === 'Enter') {
            if (action === 'login') handleLogin();
            if (action === 'email') handleEmailSubmit();
        }
    };

    const renderStep = () => {
        switch (step) {
            case 'email':
                return (
                    <>
                        <h1 className="text-2xl font-bold text-slate-700">Enter your email</h1>
                        <p className="text-slate-500 mt-2">To create an account and personalize your experience.</p>
                        <div className="mt-8 space-y-4">
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                onKeyDown={(e) => handleKeyDown(e, 'email')}
                                placeholder="you@example.com"
                                className="w-full text-center p-3 rounded-lg bg-transparent border border-slate-300 focus:ring-2 focus:ring-violet-500 focus:outline-none placeholder:text-slate-400 text-slate-700"
                                autoFocus
                            />
                            {emailError && <p className="text-sm text-red-500">{emailError}</p>}
                            <button
                                onClick={handleEmailSubmit}
                                disabled={!email.trim()}
                                className="w-full px-5 py-3 rounded-lg bg-violet-500 text-white font-semibold transition-transform hover:scale-105 disabled:opacity-50"
                            >
                                Continue
                            </button>
                             <button onClick={() => setStep('initial')} className="text-sm text-slate-500 hover:underline">
                                Back
                             </button>
                        </div>
                    </>
                );
            case 'captcha':
                 return (
                    <>
                        <h1 className="text-2xl font-bold text-slate-700">Please verify you're human</h1>
                        <p className="text-slate-500 mt-2">This helps us prevent spam and bots.</p>
                        <div className="mt-8">
                             <Captcha onVerify={handleCaptchaVerify} />
                        </div>
                         <button onClick={() => setStep('email')} className="text-sm text-slate-500 hover:underline mt-4">
                            Back
                         </button>
                    </>
                );
            case 'initial':
            default:
                return (
                    <>
                         <div className="flex justify-center mb-6">
                            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center text-white font-bold text-4xl shadow-lg">
                                P
                            </div>
                        </div>
                        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-800 uppercase tracking-tight">
                            Welcome to PulseStudy
                        </h1>
                        <p className="text-slate-500 mt-2">
                            Your personalized student dashboard awaits.
                        </p>
                        <div className="mt-8 space-y-4">
                             <button
                                onClick={handleGoogleSignUpClick}
                                className="w-full flex items-center justify-center gap-3 px-5 py-3 rounded-lg bg-white border border-slate-300 text-slate-700 font-semibold transition-colors hover:bg-slate-50"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/><path fill="#FF3D00" d="m6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z"/><path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.222 0-9.618-3.524-11.088-8.264l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/><path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8l.004-.001l.004.001c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/></svg>
                                Sign up with Google
                             </button>

                             <div className="flex items-center">
                                <div className="flex-grow border-t border-slate-300"></div>
                                <span className="flex-shrink mx-4 text-xs text-slate-400">OR</span>
                                <div className="flex-grow border-t border-slate-300"></div>
                            </div>

                            <input
                                type="text"
                                value={nameInput}
                                onChange={(e) => setNameInput(e.target.value)}
                                onKeyDown={(e) => handleKeyDown(e, 'login')}
                                placeholder="Just enter your name to continue"
                                className="w-full text-center p-3 rounded-lg bg-transparent border border-slate-300 focus:ring-2 focus:ring-violet-500 focus:outline-none placeholder:text-slate-400 text-slate-700"
                            />
                            <button
                                onClick={handleLogin}
                                disabled={!nameInput.trim()}
                                className={`w-full px-5 py-3 rounded-lg font-semibold transition-all duration-500 ${
                                    !nameInput.trim()
                                    ? 'bg-slate-600 text-slate-100 opacity-50 cursor-not-allowed'
                                    : 'bg-gradient-to-r from-cyan-500 to-violet-500 text-white hover:scale-105'
                                }`}
                            >
                                Continue
                            </button>
                        </div>
                    </>
                );
        }
    };

    return (
        <div className={`
            fixed inset-0 z-[100] flex items-center justify-center bg-slate-50
            transition-opacity duration-500 ease-in-out
            ${isFadingOut ? 'opacity-0' : 'opacity-100'}
        `}>
            <div className="w-full max-w-md mx-4 p-8 bg-white/80 backdrop-blur-xl border border-slate-200 rounded-3xl shadow-2xl text-center animate-fade-in-up">
               {renderStep()}
            </div>
        </div>
    );
};

export default LoginScreen;