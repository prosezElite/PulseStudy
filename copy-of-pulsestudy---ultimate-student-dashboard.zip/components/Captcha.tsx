import React, { useState, useEffect, useMemo } from 'react';

interface CaptchaProps {
    onVerify: (isVerified: boolean) => void;
}

const generateCaptchaText = (length = 6) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
};

const Captcha: React.FC<CaptchaProps> = ({ onVerify }) => {
    const [captchaText, setCaptchaText] = useState('');
    const [userInput, setUserInput] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        setCaptchaText(generateCaptchaText());
    }, []);

    const handleRefresh = () => {
        setCaptchaText(generateCaptchaText());
        setUserInput('');
        setError('');
    };

    const handleSubmit = () => {
        if (userInput.toLowerCase() === captchaText.toLowerCase()) {
            setError('');
            onVerify(true);
        } else {
            setError('Incorrect CAPTCHA. Please try again.');
            onVerify(false);
            handleRefresh();
        }
    };
    
    const captchaChars = useMemo(() => captchaText.split('').map((char, index) => ({
        char,
        style: {
            transform: `rotate(${(Math.random() - 0.5) * 25}deg)`,
            color: `hsl(${Math.random() * 360}, 50%, 40%)`,
            margin: '0 2px',
            display: 'inline-block',
        }
    })), [captchaText]);

    return (
        <div className="space-y-4 text-center">
            <div className="p-4 bg-slate-300/50 border border-slate-300 rounded-lg flex items-center justify-center select-none">
                <span className="text-2xl font-bold tracking-widest font-mono" aria-label={`CAPTCHA text: ${captchaText.split('').join(' ')}`}>
                    {captchaChars.map(({char, style}, index) => (
                        <span key={index} style={style}>{char}</span>
                    ))}
                </span>
            </div>
            <div className="flex items-center gap-2">
                 <input
                    type="text"
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSubmit()}
                    placeholder="Enter CAPTCHA"
                    className="w-full text-center p-3 rounded-lg bg-transparent border border-slate-400 focus:ring-2 focus:ring-violet-500 focus:outline-none placeholder:text-slate-500"
                    aria-label="CAPTCHA input"
                />
                <button onClick={handleRefresh} title="Refresh CAPTCHA" className="p-3 rounded-lg bg-black/10 hover:bg-black/20 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" /></svg>
                </button>
            </div>
            {error && <p className="text-sm text-red-500">{error}</p>}
            <button
                onClick={handleSubmit}
                className="w-full px-5 py-3 rounded-lg bg-violet-500 text-white font-semibold transition-transform hover:scale-105"
            >
                Verify
            </button>
        </div>
    );
};

export default Captcha;
