import React from 'react';
import type { ModalContent } from '../types';

interface FooterProps {
    onOpenModal: (type: ModalContent['type'], data?: any) => void;
}

const Footer: React.FC<FooterProps> = ({ onOpenModal }) => {
  return (
    <footer className="py-8 px-4 text-center text-sm text-slate-400 dark:text-slate-500 space-y-4">
      <p>Made with ⚡ for students — PulseStudy • Minimal Futurism</p>
      <div className="flex justify-center items-center gap-x-6 gap-y-2 flex-wrap">
        <button onClick={() => onOpenModal('legal', { policyType: 'tos' })} className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">Terms of Service</button>
        <button onClick={() => onOpenModal('legal', { policyType: 'tnc' })} className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">Terms & Conditions</button>
        <button onClick={() => onOpenModal('legal', { policyType: 'privacy' })} className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">Privacy Policy</button>
      </div>
    </footer>
  );
};

export default Footer;
