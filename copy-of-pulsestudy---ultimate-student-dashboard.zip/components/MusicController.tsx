
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import type { Track } from '../types';

// --- MOCK DATA ---
// Sourced from Pixabay for royalty-free use with stable CDN links.
const mockTracks: Track[] = [
    { title: 'Lofi Study', artist: 'FASSounds', albumArt: 'https://picsum.photos/seed/lofi-study/200', audioSrc: 'https://cdn.pixabay.com/download/audio/2022/05/24/audio_a7292a096a.mp3' },
    { title: 'Good Night', artist: 'FASSounds', albumArt: 'https://picsum.photos/seed/good-night/200', audioSrc: 'https://cdn.pixabay.com/download/audio/2022/12/22/audio_fb83344634.mp3' },
    { title: 'Morning Garden', artist: 'Olexy', albumArt: 'https://picsum.photos/seed/morning-garden/200', audioSrc: 'https://cdn.pixabay.com/download/audio/2023/05/08/audio_848c083c40.mp3' },
    { title: 'Sleepy Cat', artist: 'AleXZavesa', albumArt: 'https://picsum.photos/seed/sleepy-cat/200', audioSrc: 'https://cdn.pixabay.com/download/audio/2022/08/17/audio_62280d2a84.mp3' },
    { title: 'Coding Night', artist: 'FASSounds', albumArt: 'https://picsum.photos/seed/coding-night/200', audioSrc: 'https://cdn.pixabay.com/download/audio/2022/11/17/audio_85272a6b2c.mp3' },
    { title: 'Lofi Chill', artist: 'FASSounds', albumArt: 'https://picsum.photos/seed/lofi-chill/200', audioSrc: 'https://cdn.pixabay.com/download/audio/2022/02/07/audio_a3a0a32371.mp3' },
];


const mockPlaylists = [
    { name: 'Deep Focus', tracks: [mockTracks[0], mockTracks[4], mockTracks[5]] },
    { name: 'Coding Marathon', tracks: [mockTracks[4], mockTracks[0]] },
    { name: 'Relax & Unwind', tracks: [mockTracks[1], mockTracks[2], mockTracks[3]] },
];
// --- END MOCK DATA ---

interface MusicControllerProps {
    onClose: () => void;
}

export default function MusicController({ onClose }: MusicControllerProps) {
    const [isExpanded, setIsExpanded] = useState(false);
    
    // Music state
    const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [volume, setVolume] = useState(1);
    const [view, setView] = useState<'player' | 'search' | 'playlist'>('player');
    const [searchQuery, setSearchQuery] = useState('');
    
    const audioRef = useRef<HTMLAudioElement>(null);
    const currentTrack = mockTracks[currentTrackIndex];

    const handleNext = useCallback(() => {
        setCurrentTrackIndex(i => (i + 1) % mockTracks.length);
        setProgress(0);
    }, []);
    
    const handlePrev = useCallback(() => {
        setCurrentTrackIndex(i => (i - 1 + mockTracks.length) % mockTracks.length);
        setProgress(0);
    }, []);
    
    const handlePlayPause = useCallback(() => setIsPlaying(p => !p), []);

    const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setVolume(parseFloat(e.target.value));
    };

    const toggleMute = () => {
        setVolume(v => v > 0 ? 0 : 1);
    };

    // Effect to control audio playback (play/pause) and track changes
    useEffect(() => {
        if (isPlaying) {
            audioRef.current?.play().catch(error => {
                console.error("Audio play failed:", error);
                // It might fail due to browser autoplay policies, so we should reflect the actual state.
                setIsPlaying(false);
            });
        } else {
            audioRef.current?.pause();
        }
    }, [isPlaying, currentTrack]); // FIX: Add currentTrack as a dependency

    // Effect to control volume
    useEffect(() => {
        if (audioRef.current) {
            audioRef.current.volume = volume;
        }
    }, [volume]);
    
    const handleTimeUpdate = () => {
        if (audioRef.current?.duration) {
            setProgress((audioRef.current.currentTime / audioRef.current.duration) * 100);
        }
    };

    const handleSelectTrack = useCallback((track: Track) => {
        const index = mockTracks.findIndex(t => t.audioSrc === track.audioSrc);
        if (index > -1) {
            setCurrentTrackIndex(index);
            setProgress(0);
            setIsPlaying(true);
            setView('player');
        }
    }, []);

    const searchResults = useMemo(() => {
        if (!searchQuery) return [];
        return mockTracks.filter(t => 
            t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
            t.artist.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [searchQuery]);

    return (
        <>
            <audio ref={audioRef} src={currentTrack.audioSrc} onTimeUpdate={handleTimeUpdate} onEnded={handleNext} preload="metadata" />
        
            {/* Expanded View - Modal */}
            <div 
                className={`fixed inset-0 z-40 bg-black/50 backdrop-blur-sm transition-opacity duration-300 ${isExpanded ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={() => setIsExpanded(false)}
            />
            <div 
                className={`fixed bottom-0 inset-x-0 z-50 transform transition-transform duration-500 ease-in-out ${isExpanded ? 'translate-y-0' : 'translate-y-full'}`}
            >
                <div className="w-full max-w-2xl mx-auto bg-slate-200/80 dark:bg-slate-800/80 backdrop-blur-xl border-t border-x border-slate-300 dark:border-slate-700 rounded-t-2xl h-[70vh] max-h-[500px] flex flex-col">
                    <div className="flex items-center justify-between p-4 border-b border-slate-300 dark:border-slate-700 flex-shrink-0">
                         <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
                            <button onClick={() => setView(v => v === 'search' ? 'player' : 'search')} className={`p-2 rounded-full ${view === 'search' ? 'bg-violet-500/20' : 'hover:bg-black/5 dark:hover:bg-white/5'}`}>
                                <SearchIcon />
                            </button>
                             <button onClick={() => setView(v => v === 'playlist' ? 'player' : 'playlist')} className={`p-2 rounded-full ${view === 'playlist' ? 'bg-violet-500/20' : 'hover:bg-black/5 dark:hover:bg-white/5'}`}>
                                <PlaylistIcon />
                            </button>
                        </div>
                        <button onClick={() => setIsExpanded(false)} className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-black/10 dark:hover:bg-white/10 transition-colors">
                            <ChevronDownIcon />
                        </button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4">
                        {view === 'player' && <PlayerView track={currentTrack} progress={progress} isPlaying={isPlaying} onPlayPause={handlePlayPause} onNext={handleNext} onPrev={handlePrev} volume={volume} onVolumeChange={handleVolumeChange} onToggleMute={toggleMute} />}
                        {view === 'search' && <SearchView query={searchQuery} setQuery={setSearchQuery} results={searchResults} onSelect={handleSelectTrack} />}
                        {view === 'playlist' && <PlaylistView playlists={mockPlaylists} onSelect={handleSelectTrack} />}
                    </div>
                </div>
            </div>

            {/* Compact View - Bar */}
            <div className={`fixed bottom-0 inset-x-0 z-50 transform transition-transform duration-500 ease-in-out ${isExpanded ? 'translate-y-full' : 'translate-y-0'}`}>
                <div className="bg-slate-100/80 dark:bg-slate-900/80 backdrop-blur-xl border-t border-slate-200 dark:border-slate-700 h-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-8 h-full flex items-center justify-between">
                        <div className="flex items-center gap-3 w-1/3 cursor-pointer" onClick={() => setIsExpanded(true)}>
                            <img src={currentTrack.albumArt} alt={currentTrack.title} className="w-12 h-12 rounded-md" />
                            <div className="overflow-hidden">
                                <p className="font-semibold text-sm truncate text-slate-800 dark:text-slate-100">{currentTrack.title}</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{currentTrack.artist}</p>
                            </div>
                        </div>

                        <div className="flex flex-col items-center justify-center w-1/3">
                            <div className="flex items-center gap-6">
                                <button onClick={handlePrev} className="text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-slate-100"><PrevIcon /></button>
                                <button onClick={handlePlayPause} className="w-12 h-12 flex items-center justify-center rounded-full bg-violet-500 text-white shadow-lg transition-transform hover:scale-110">
                                    {isPlaying ? <PauseIcon size="6" /> : <PlayIcon size="6" />}
                                </button>
                                <button onClick={handleNext} className="text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-slate-100"><NextIcon /></button>
                            </div>
                            <div className="w-full max-w-xs h-1 bg-black/10 dark:bg-white/10 rounded-full mt-2">
                                <div className="h-full bg-violet-500 rounded-full" style={{ width: `${progress}%` }}></div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-3 w-1/3">
                            <div className="hidden md:flex items-center gap-2 group text-slate-500 dark:text-slate-400">
                                <button onClick={toggleMute} className="hover:text-slate-800 dark:hover:text-slate-200">
                                    {volume === 0 ? <VolumeOffIcon /> : <VolumeUpIcon />}
                                </button>
                                <input 
                                    type="range" 
                                    min="0" 
                                    max="1" 
                                    step="0.01" 
                                    value={volume} 
                                    onChange={handleVolumeChange}
                                    className="w-24 h-1.5 rounded-lg appearance-none cursor-pointer bg-black/10 dark:bg-white/10 accent-violet-500"
                                    aria-label="Volume slider"
                                />
                            </div>
                            <button onClick={() => setIsExpanded(true)} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400">
                               <ChevronUpIcon />
                            </button>
                            <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400">
                                <CloseIcon />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

// --- SUB-COMPONENTS for EXPANDED VIEW ---
const PlayerView = ({ track, progress, isPlaying, onPlayPause, onNext, onPrev, volume, onVolumeChange, onToggleMute }: {
    track: Track;
    progress: number;
    isPlaying: boolean;
    onPlayPause: () => void;
    onNext: () => void;
    onPrev: () => void;
    volume: number;
    onVolumeChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onToggleMute: () => void;
}) => (
    <div className="flex flex-col items-center justify-around h-full text-center text-slate-800 dark:text-slate-100">
        <div /> 
        <img src={track.albumArt} alt={track.title} className="w-48 h-48 rounded-lg shadow-2xl" />
        <div>
            <p className="font-bold text-2xl mt-4">{track.title}</p>
            <p className="text-md text-slate-500 dark:text-slate-400">{track.artist}</p>
        </div>
        <div>
            <div className="w-72 h-1.5 bg-black/10 dark:bg-white/10 rounded-full mt-4">
                <div className="h-full bg-violet-500 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            <div className="flex items-center justify-center gap-6 mt-4">
                <button onClick={onPrev} className="text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-slate-100"><PrevIcon /></button>
                <button onClick={onPlayPause} className="w-16 h-16 flex items-center justify-center rounded-full bg-violet-500 text-white shadow-lg transition-transform hover:scale-110">
                    {isPlaying ? <PauseIcon size="8" /> : <PlayIcon size="8" />}
                </button>
                <button onClick={onNext} className="text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-slate-100"><NextIcon /></button>
            </div>
             <div className="w-full max-w-xs flex items-center gap-3 mt-6 text-slate-500 dark:text-slate-400">
                <button onClick={onToggleMute} className="hover:text-slate-800 dark:hover:text-slate-200">
                    {volume === 0 ? <VolumeOffIcon /> : <VolumeUpIcon />}
                </button>
                <input 
                    type="range" 
                    min="0" 
                    max="1" 
                    step="0.01" 
                    value={volume} 
                    onChange={onVolumeChange}
                    className="w-full h-1.5 rounded-lg appearance-none cursor-pointer bg-black/10 dark:bg-white/10 accent-violet-500"
                    aria-label="Volume slider"
                />
            </div>
        </div>
    </div>
);


const SearchView = ({ query, setQuery, results, onSelect }: any) => (
    <div>
        <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for a song..."
            className="w-full p-2 rounded-md bg-transparent border border-slate-400 dark:border-slate-500 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-violet-500 focus:outline-none transition"
            autoFocus
        />
        <ul className="mt-2 space-y-1 max-h-40 overflow-y-auto">
            {results.map((track: Track) => (
                <li key={track.audioSrc} onClick={() => onSelect(track)} className="p-2 flex items-center gap-3 rounded-md hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer">
                    <img src={track.albumArt} alt={track.title} className="w-8 h-8 rounded" />
                    <div>
                        <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{track.title}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{track.artist}</p>
                    </div>
                </li>
            ))}
        </ul>
    </div>
);

const PlaylistView = ({ playlists, onSelect }: any) => (
    <ul className="space-y-2 max-h-full overflow-y-auto">
        {playlists.map((pl: any) => (
            <li key={pl.name}>
                <p className="font-bold text-sm mb-1 text-slate-800 dark:text-slate-100">{pl.name}</p>
                <ul className="space-y-1">
                    {pl.tracks.map((track: Track) => (
                        <li key={track.audioSrc} onClick={() => onSelect(track)} className="p-2 flex items-center gap-3 rounded-md hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer">
                            <img src={track.albumArt} alt={track.title} className="w-8 h-8 rounded" />
                            <div>
                                <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{track.title}</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400">{track.artist}</p>
                            </div>
                        </li>
                    ))}
                </ul>
            </li>
        ))}
    </ul>
);

// --- ICONS ---
const PlayIcon: React.FC<{ size?: string }> = ({ size = '5' }) => <svg xmlns="http://www.w3.org/2000/svg" className={`h-${size} w-${size}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>;
const PauseIcon: React.FC<{ size?: string }> = ({ size = '5' }) => <svg xmlns="http://www.w3.org/2000/svg" className={`h-${size} w-${size}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h1a1 1 0 100-2H9V8a1 1 0 00-1-1zm4 0a1 1 0 00-1 1v4a1 1 0 001 1h1a1 1 0 100-2h-1V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>;
const NextIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M4.555 5.168A1 1 0 003 6v8a1 1 0 001.555.832L10 11.168V14a1 1 0 001.555.832l6-4a1 1 0 000-1.664l-6-4A1 1 0 0010 6v2.832L4.555 5.168z" /></svg>;
const PrevIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M15.445 5.168A1 1 0 0014 6v2.832L8.445 5.168A1 1 0 007 6v8a1 1 0 001.445.832L14 11.168V14a1 1 0 001.555.832l-6-4a1 1 0 000-1.664l6-4z" /></svg>;
const ChevronDownIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>;
const ChevronUpIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" /></svg>;
const SearchIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" /></svg>;
const PlaylistIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 3a1 1 0 00-1 1v.01a1 1 0 001 1h4a1 1 0 001-1V4a1 1 0 00-1-1h-4z" /><path fillRule="evenodd" d="M3 8a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 13a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" /></svg>;
const CloseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>;
const VolumeUpIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.414z" clipRule="evenodd" /></svg>;
const VolumeOffIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM12.293 7.293a1 1 0 011.414 0L15 8.586l1.293-1.293a1 1 0 111.414 1.414L16.414 10l1.293 1.293a1 1 0 01-1.414 1.414L15 11.414l-1.293 1.293a1 1 0 01-1.414-1.414L13.586 10l-1.293-1.293a1 1 0 010-1.414z" clipRule="evenodd" /></svg>;
