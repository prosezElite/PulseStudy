

import React from 'react';
import type { Note, ModalContent } from '../types';

interface NotesSectionProps {
  notes: Note[];
  onOpenModal: (type: ModalContent['type'], data?: any) => void;
  onNoteScanned: (imageData: string) => void;
}

const NoteCard: React.FC<{ note: Note; onOpenModal: NotesSectionProps['onOpenModal'] }> = ({ note, onOpenModal }) => {
    const truncate = (str: string, len: number) => {
        return str.length > len ? str.substring(0, len) + "..." : str;
    };

    return (
        <div className="p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-cyan-500/10 hover:border-cyan-500/30">
            <div>
                <div className="font-semibold text-slate-700 dark:text-slate-200">{truncate(note.title, 30)}</div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">{new Date(note.created).toLocaleString()}</div>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 break-words">{truncate(note.body, 100)}</p>
                {note.file && (
                     <button
                        onClick={() => onOpenModal('fileEditor', { noteId: note.id, file: note.file })}
                        className="text-xs text-cyan-600 dark:text-cyan-400 hover:underline mt-2 flex items-center gap-1 text-left"
                        aria-label={`Open editor for ${note.file.name}`}
                     >
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/></svg>
                        <span>{truncate(note.file.name, 25)}</span>
                    </button>
                )}
            </div>
            <div className="mt-3 text-right">
                <button onClick={() => onOpenModal('note', note)} className="px-3 py-1 rounded-md bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors text-xs font-medium text-slate-700 dark:text-slate-200">
                    View / Edit
                </button>
            </div>
        </div>
    );
};

const NotesSection: React.FC<NotesSectionProps> = ({ notes, onOpenModal, onNoteScanned }) => {
  const scanInputRef = React.useRef<HTMLInputElement>(null);

  const handleScanClick = () => {
    scanInputRef.current?.click();
  };

  const handleFileScanned = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        onNoteScanned(dataUrl);
    };
    reader.readAsDataURL(file);
    e.target.value = ''; // Reset for next scan
  };

  return (
    <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 transition-transform duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-violet-500/10">
      <div className="flex justify-between items-center gap-2">
        <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-100">Notes</h2>
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
            <input 
                type="file" 
                accept="image/*" 
                capture="environment" 
                ref={scanInputRef}
                onChange={handleFileScanned}
                className="hidden"
            />
             <button onClick={handleScanClick} className="px-3 py-2 rounded-md bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors text-sm flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 2a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V4a2 2 0 00-2-2H4zm10.5 5.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" clipRule="evenodd" /><path d="M2 12.5a1.5 1.5 0 011.5-1.5h13a1.5 1.5 0 010 3h-13A1.5 1.5 0 012 12.5z" /></svg>
                Scan Note
            </button>
            <button onClick={() => onOpenModal('note')} className="px-3 py-2 rounded-md bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors">+ New</button>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {notes.length > 0 ? (
          notes.map((note) => (
            <NoteCard key={note.id} note={note} onOpenModal={onOpenModal} />
          ))
        ) : (
          <div className="sm:col-span-2 text-center py-8 text-slate-500 dark:text-slate-400">
            You have no notes. Create one to get started!
          </div>
        )}
      </div>
    </div>
  );
};

export default NotesSection;