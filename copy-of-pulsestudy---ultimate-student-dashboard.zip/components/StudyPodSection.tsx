import React from 'react';
import type { ModalContent, PomodoroSession, StudyPod } from '../types';

interface StudyPodSectionProps {
  pod: StudyPod;
  pomodoro: {
    duration: number;
    secondsLeft: number;
    isRunning: boolean;
    setIsRunning: (r: boolean) => void;
    reset: () => void;
    session: PomodoroSession;
    openFullScreen: () => void;
  };
  onLeave: () => void;
  onOpenModal: (type: ModalContent['type'], data?: any) => void;
}

const formatTime = (s: number) => {
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const secs = (s % 60).toString().padStart(2, '0');
    return `${m}:${secs}`;
};

const PulseSparkIcon = () => (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-white">
        <path d="M12 2 L14.5 9.5 L22 12 L14.5 14.5 L12 22 L9.5 14.5 L2 12 L9.5 9.5 Z" />
    </svg>
);

export default function StudyPodSection({ pod, pomodoro, onLeave, onOpenModal }: StudyPodSectionProps) {
  return (
    <aside className="bg-slate-100 dark:bg-slate-800 border-2 border-dashed border-violet-400 dark:border-violet-600 rounded-2xl p-5 flex flex-col items-center justify-between transition-all duration-300 shadow-2xl shadow-violet-500/10 origin-theme:bg-slate-900/50 origin-theme:border-violet-600">
      <div>
        <div className="flex items-center justify-between w-full">
            <div className="text-sm text-violet-600 dark:text-violet-400 font-semibold">SYNCHRONIZED POD</div>
            <button onClick={pomodoro.openFullScreen} className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors" aria-label="Open full-screen timer">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 1v4m0 0h-4m4 0l-5-5" /></svg>
            </button>
        </div>
        <div className="mt-2 p-2 bg-violet-500/10 dark:bg-violet-500/20 rounded-md text-center text-sm font-medium text-violet-800 dark:text-violet-300">
            Goal: {pod.goal}
        </div>
        <div className="text-5xl font-bold my-4 text-slate-900 dark:text-slate-50">{formatTime(pomodoro.secondsLeft)}</div>
      </div>

      <div className="w-full">
        <div className="flex items-center justify-center gap-2 mb-4 -space-x-2">
            {pod.members.map((member) => (
                <div key={member.name} title={member.name} className="flex flex-col items-center">
                    <div className={`relative w-8 h-8 rounded-full bg-slate-300 dark:bg-slate-600 flex items-center justify-center text-xs font-bold text-slate-600 dark:text-slate-300 border-2 ${member.isYou ? 'border-violet-500 bg-violet-500' : 'border-slate-100 dark:border-slate-800'}`}>
                        {member.isYou ? <PulseSparkIcon /> : member.avatar}
                        {member.isLeader && (
                            <span className="absolute -top-2.5 -right-2 text-lg" title="Focus Leader">👑</span>
                        )}
                    </div>
                    {member.focusStreak > 1 && (
                        <div className="text-xs mt-1 flex items-center" title={`Focus Streak: ${member.focusStreak}`}>
                            <span>🔥</span>
                            <span className="font-semibold text-orange-500">{member.focusStreak}</span>
                        </div>
                    )}
                </div>
            ))}
        </div>

        <div className="flex items-center justify-center gap-2 mb-4">
            {Array.from({ length: pomodoro.session.total }).map((_, i) => (
                <div key={i} className={`w-3 h-3 rounded-full transition-all duration-300 ${i < pomodoro.session.completed ? 'bg-cyan-400' : 'bg-black/20 dark:bg-white/20'}`}></div>
            ))}
        </div>
        
        <button onClick={() => onOpenModal('collaborationCanvas', { podGoal: pod.goal })} className="w-full text-center px-4 py-2 mb-3 rounded-md bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 text-sm font-semibold transition-colors">
            Open Collab Canvas
        </button>
        <div className="flex gap-3">
            <button onClick={() => pomodoro.setIsRunning(!pomodoro.isRunning)} className="w-full px-4 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105">
                {pomodoro.isRunning ? 'Pause Pod' : 'Start Pod'}
            </button>
            <button onClick={onLeave} className="px-4 py-2 rounded-md bg-red-500/10 text-red-600 hover:bg-red-500/20 transition-colors text-sm">Leave</button>
        </div>
      </div>
    </aside>
  );
}