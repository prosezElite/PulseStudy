import React, { useState, useEffect } from 'react';
import { generateCode } from '../../services/geminiService';

interface BuildModalProps {
  onClose: () => void;
}

const fileNames = {
    html: 'index.html',
    css: 'style.css',
    js: 'script.js'
};

const BuildModal: React.FC<BuildModalProps> = ({ onClose }) => {
    const [prompt, setPrompt] = useState('');
    const [generatedCode, setGeneratedCode] = useState<{ html: string; css: string; js: string; explanation: string } | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [previewSrcDoc, setPreviewSrcDoc] = useState('');
    const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
    const [activeFile, setActiveFile] = useState<'html' | 'css' | 'js'>('html');

    useEffect(() => {
        if (generatedCode) {
            const { html, css, js } = generatedCode;
            const srcDoc = `
                <html>
                    <head>
                        <style>${css}</style>
                    </head>
                    <body>
                        ${html}
                        <script>${js}</script>
                    </body>
                </html>
            `;
            setPreviewSrcDoc(srcDoc);
        }
    }, [generatedCode]);

    const handleGenerate = async () => {
        if (!prompt.trim()) return;
        setIsLoading(true);
        setError(null);
        setGeneratedCode(null);
        try {
            const result = await generateCode(prompt);
            setGeneratedCode(result);
            setViewMode('preview'); // Default to preview after generation
        } catch (e: any) {
            setError(e.message || 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopy = () => {
        if (generatedCode) {
            navigator.clipboard.writeText(generatedCode[activeFile]);
        }
    };

    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center text-white font-bold text-sm">
                        &lt;/&gt;
                    </div>
                    <div>
                        <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-100">Pulse AI Builder</h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400 -mt-0.5">Bring your ideas to life with AI-powered code generation.</p>
                    </div>
                </div>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 transition-colors" aria-label="Close builder">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </header>

            <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
                {/* Left Panel: Input & Controls */}
                <div className="w-full md:w-1/3 flex flex-col p-4 border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 overflow-y-auto">
                    <h3 className="font-semibold text-slate-700 dark:text-slate-200">Describe Your Vision</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        Explain what you want to build. Be descriptive! For example, "a simple login form with a cool gradient background" or "a button that shows a random fact when clicked".
                    </p>
                    <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="e.g., A responsive portfolio card with a profile picture, name, and social media links..."
                        className="w-full h-48 mt-4 p-3 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none transition resize-none text-slate-800 dark:text-slate-100"
                        disabled={isLoading}
                    />
                    <button onClick={handleGenerate} disabled={isLoading || !prompt.trim()} className="mt-4 w-full px-5 py-3 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed">
                        {isLoading ? (
                            <div className="flex items-center justify-center gap-2">
                                <div className="w-4 h-4 border-2 border-white/50 border-t-white rounded-full animate-spin"></div>
                                <span>Generating...</span>
                            </div>
                        ) : 'Generate Code'}
                    </button>
                    {error && <div className="text-sm text-red-500 mt-3 p-3 bg-red-500/10 rounded-md">{error}</div>}

                    {generatedCode && !isLoading && (
                        <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700 animate-fade-in-up">
                            <h4 className="font-semibold text-slate-800 dark:text-slate-100">AI Explanation</h4>
                            <p className="text-sm text-slate-600 dark:text-slate-300 mt-2 whitespace-pre-wrap">{generatedCode.explanation}</p>
                        </div>
                    )}
                </div>

                {/* Right Panel: Output & Preview */}
                <div className="flex-1 flex flex-col overflow-hidden bg-slate-100 dark:bg-slate-900">
                    {/* Toolbar */}
                    <div className="flex-shrink-0 flex items-center justify-between p-2 border-b border-slate-200 dark:border-slate-700">
                        <div>
                            {generatedCode && viewMode === 'code' && (
                                <div className="flex items-center gap-1 rounded-lg bg-slate-200 dark:bg-slate-700 p-1">
                                    {(Object.keys(fileNames) as Array<keyof typeof fileNames>).map((key) => (
                                        <button 
                                            key={key} 
                                            onClick={() => setActiveFile(key)}
                                            className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${activeFile === key ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-800 dark:text-slate-100' : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100'}`}
                                        >
                                            {fileNames[key]}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                        
                        <div className="flex items-center gap-3">
                            {generatedCode && viewMode === 'code' && (
                                <button onClick={handleCopy} className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z" /><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z" /></svg>
                                    Copy Code
                                </button>
                            )}

                            {generatedCode && (
                                <div className="flex items-center gap-1 bg-slate-200 dark:bg-slate-700 p-1 rounded-full">
                                    <button onClick={() => setViewMode('code')} className={`px-3 py-1 text-xs font-semibold rounded-full transition-colors ${viewMode === 'code' ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-800 dark:text-slate-100' : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100'}`}>
                                        Code
                                    </button>
                                    <button onClick={() => setViewMode('preview')} className={`px-3 py-1 text-xs font-semibold rounded-full transition-colors ${viewMode === 'preview' ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-800 dark:text-slate-100' : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100'}`}>
                                        Preview
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Content Area */}
                    <div className="flex-1 overflow-auto bg-white dark:bg-slate-800">
                        {!generatedCode ? (
                            <div className="flex items-center justify-center h-full text-center text-slate-500 dark:text-slate-400">
                                {isLoading ? 'The AI is building, please wait...' : 'Your code and preview will appear here.'}
                            </div>
                        ) : viewMode === 'code' ? (
                            <pre className="p-4 text-sm whitespace-pre-wrap font-mono h-full text-slate-800 dark:text-slate-100">
                                <code>{generatedCode[activeFile]}</code>
                            </pre>
                        ) : (
                            <iframe
                                srcDoc={previewSrcDoc}
                                title="Code Preview"
                                sandbox="allow-scripts"
                                className="w-full h-full border-0 bg-white"
                            />
                        )}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default BuildModal;