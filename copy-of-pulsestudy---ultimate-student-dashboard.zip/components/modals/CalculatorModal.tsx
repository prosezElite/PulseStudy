import React, { useState, useRef, useEffect } from 'react';
import { getAIMathResponse } from '../../services/geminiService';

const MATH_SAMPLE_PROMPTS = [
    "Solve for x: 3x - 7 = 14",
    "What is 15% of 250?",
    "Calculate the area of a circle with a radius of 8cm.",
    "If a train travels 120 miles in 2 hours, what is its average speed?",
];

const MarkdownRenderer: React.FC<{ text: string }> = ({ text }) => {
  const parts = text.split(/(\*\*.*?\*\*|`.*?`|```[\s\S]*?```)/g);

  return (
    <>
      {parts.map((part, index) => {
        if (part.startsWith('```') && part.endsWith('```')) {
          return <pre key={index} className="bg-slate-200 dark:bg-slate-700/70 p-3 rounded-md text-sm my-2 whitespace-pre-wrap font-mono text-slate-800 dark:text-slate-200">{part.slice(3, -3).trim()}</pre>;
        }
        if (part.startsWith('`') && part.endsWith('`')) {
          return <code key={index} className="bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded text-sm font-mono text-slate-800 dark:text-slate-200">{part.slice(1, -1)}</code>;
        }
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={index}>{part.slice(2, -2)}</strong>;
        }
        return <React.Fragment key={index}>{part.replace(/\\n/g, '\n')}</React.Fragment>;
      })}
    </>
  );
};

const CalculatorModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [problemStatement, setProblemStatement] = useState('');
  const outputRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (outputRef.current) {
        outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output, isLoading, problemStatement]);

  useEffect(() => {
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  const handleSolve = async (promptText?: string) => {
    const trimmedInput = promptText || input.trim();
    if (!trimmedInput || isLoading) return;

    setProblemStatement(trimmedInput);
    if (!promptText) setInput('');
    setIsLoading(true);
    setOutput('');

    try {
        const aiResponseText = await getAIMathResponse(trimmedInput);
        setOutput(aiResponseText);
    } catch (e) {
        setOutput("Sorry, I encountered an error. Please try again.");
    } finally {
        setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleSolve();
  };

  return (
    <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
        <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
            <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-1.57 1.996A1.532 1.532 0 013 8.22v3.56c0 .85.69 1.53 1.53 1.53.62 0 1.157.342 1.41.865.253.523.82.934 1.41.934.59 0 1.157-.411 1.41-.934a1.532 1.532 0 011.41-.865c.84 0 1.53-.68 1.53-1.53V8.22c0-.85-.69-1.53-1.53-1.53a1.532 1.532 0 01-1.41-.865c-.253-.523-.82-.934-1.41-.934a1.532 1.532 0 01-1.41.865c-.62 0-1.157-.342-1.41-.865a1.532 1.532 0 01-2.286-.948zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" /></svg>
                AI Math Solver
            </h2>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
            </button>
        </header>

      <main ref={outputRef} className="flex-1 overflow-y-auto p-4 sm:p-8">
        <div className="max-w-3xl mx-auto">
            {!output && !isLoading && !problemStatement ? (
                <div className="text-center h-full flex flex-col justify-center">
                    <p className="text-slate-500 dark:text-slate-400 mb-4">I can solve equations, handle word problems, and explain math concepts step-by-step. Try one of these:</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {MATH_SAMPLE_PROMPTS.map((p, i) => (
                            <button key={i} onClick={() => handleSolve(p)} className="p-3 text-sm text-left rounded-md bg-white dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-colors text-slate-600 dark:text-slate-300">
                                {p}
                            </button>
                        ))}
                    </div>
                </div>
            ) : (
                <div className="space-y-4 text-sm text-slate-800 dark:text-slate-100">
                    {problemStatement && (
                        <div className="p-3 rounded-lg bg-cyan-500/10 dark:bg-cyan-500/20 text-cyan-800 dark:text-cyan-300 border border-cyan-500/20 dark:border-cyan-500/30">
                            <strong className="font-semibold">Your Question:</strong>
                            <p className="mt-1">{problemStatement}</p>
                        </div>
                    )}
                    {isLoading && (
                        <div className="flex items-center gap-3 justify-start p-3">
                            <div className="w-6 h-6 flex-shrink-0 rounded-full bg-violet-500/20 flex items-center justify-center text-violet-500 text-xs font-bold animate-pulse">A</div>
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 bg-slate-400 dark:bg-slate-500 rounded-full animate-pulse"></div>
                                <div className="w-2 h-2 bg-slate-400 dark:bg-slate-500 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                                <div className="w-2 h-2 bg-slate-400 dark:bg-slate-500 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                            </div>
                        </div>
                    )}
                    {output && (
                        <div className="p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 whitespace-pre-wrap">
                            <MarkdownRenderer text={output} />
                        </div>
                    )}
                </div>
            )}
        </div>
      </main>
      
      <footer className="flex-shrink-0 p-4 border-t border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md">
        <div className="flex gap-2 max-w-3xl mx-auto">
            <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask a math question..."
                disabled={isLoading}
                className="flex-1 p-3 rounded-md bg-transparent border border-slate-400 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none transition disabled:opacity-50 text-slate-800 dark:text-slate-100"
            />
            <button
                onClick={() => handleSolve()}
                disabled={isLoading || !input.trim()}
                className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
            </button>
        </div>
      </footer>
    </div>
  );
};

export default CalculatorModal;
