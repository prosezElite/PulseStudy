import React from 'react';

interface LegalModalProps {
  policyType: 'tos' | 'tnc' | 'privacy';
  onClose: () => void;
}

const legalContent = {
  tos: {
    title: 'Terms of Service',
    content: [
      {
        heading: '1. Acceptance of Terms',
        text: 'By accessing and using PulseStudy, you accept and agree to be bound by the terms and provision of this agreement. In addition, when using these particular services, you shall be subject to any posted guidelines or rules applicable to such services.'
      },
      {
        heading: '2. Description of Service',
        text: 'PulseStudy is an all-in-one dashboard for students providing tools for note-taking, task management, study sessions, and an integrated AI doubt solver. The service is provided "as is" and we assume no responsibility for the timeliness, deletion, mis-delivery or failure to store any user communications or personalization settings.'
      },
      {
        heading: '3. User Conduct',
        text: 'You agree not to use the service to upload, post, email, transmit or otherwise make available any content that is unlawful, harmful, threatening, abusive, harassing, tortious, defamatory, vulgar, obscene, libelous, invasive of another\'s privacy, hateful, or racially, ethnically or otherwise objectionable.'
      }
    ]
  },
  tnc: {
    title: 'Terms & Conditions',
    content: [
      {
        heading: '1. Intellectual Property',
        text: 'The Service and its original content, features and functionality are and will remain the exclusive property of PulseStudy and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries.'
      },
      {
        heading: '2. Termination',
        text: 'We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms. Upon termination, your right to use the Service will immediately cease.'
      },
      {
        heading: '3. Limitation of Liability',
        text: 'In no event shall PulseStudy, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses.'
      }
    ]
  },
  privacy: {
    title: 'Privacy Policy',
    content: [
      {
        heading: '1. Information We Collect',
        text: 'We collect information you provide directly to us, such as when you create an account, create tasks, and write notes. This may include your name, email, and any content you create within the application. We also collect anonymous usage data to improve our services.'
      },
      {
        heading: '2. How We Use Information',
        text: 'We use the information we collect to operate, maintain, and provide you with the features and functionality of the Service, as well as to communicate directly with you. We may use your data to personalize your experience and for AI-powered features.'
      },
      {
        heading: '3. Sharing of Your Information',
        text: 'We will not rent or sell your information to third parties outside PulseStudy without your consent. Your data sent to the AI service is subject to the AI provider\'s privacy policy.'
      }
    ]
  }
};

const LegalModal: React.FC<LegalModalProps> = ({ policyType, onClose }) => {
  const { title, content } = legalContent[policyType];

  return (
    <div className="bg-slate-200 dark:bg-slate-800 backdrop-blur-xl border border-slate-300 dark:border-slate-700 rounded-2xl p-6 shadow-2xl animate-fade-in-up w-full max-w-2xl">
      <div className="flex items-start justify-between">
        <h4 className="font-semibold text-lg text-slate-800 dark:text-slate-100">{title}</h4>
        <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 transition">✕</button>
      </div>

      <div className="mt-4 space-y-4 max-h-[60vh] overflow-y-auto pr-4 text-slate-600 dark:text-slate-300">
        {content.map((section, index) => (
          <div key={index} className="space-y-1">
            <h5 className="font-semibold text-slate-700 dark:text-slate-200">{section.heading}</h5>
            <p className="text-sm leading-relaxed">{section.text}</p>
          </div>
        ))}
      </div>
      
      <div className="mt-6 text-right">
        <button
            onClick={onClose}
            className="px-5 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105"
        >
            Close
        </button>
      </div>
    </div>
  );
};

export default LegalModal;
