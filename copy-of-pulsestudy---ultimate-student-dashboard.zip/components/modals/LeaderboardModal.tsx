import React, { useMemo } from 'react';
import { ranks } from '../../constants';
import RankBadge from '../RankBadge';
import type { Rank } from '../../types';

interface LeaderboardUser {
    id: string;
    name: string;
    xp: number;
    rank: Rank;
}

interface LeaderboardModalProps {
  onClose: () => void;
  currentUser: {
    name: string;
    xp: number;
    rank: Rank;
  }
}

const getRankForXp = (xp: number): Rank => {
    return ranks.find(r => xp >= r.min && xp <= r.max) ?? ranks[ranks.length - 1];
};

const mockUsersRaw = [
    { id: 'user-1', name: 'Alex Nova', xp: 18500 },
    { id: 'user-2', name: 'Samira Vue', xp: 15200 },
    { id: 'user-3', name: 'Kenji React', xp: 12800 },
    { id: 'user-4', name: 'Elena Grid', xp: 9550 },
    { id: 'user-5', name: 'Marcus Style', xp: 7200 },
    { id: 'user-6', name: 'Aria Flow', xp: 6100 },
    { id: 'user-7', name: 'Leo State', xp: 4950 },
    { id: 'user-8', name: 'Zoe Animate', xp: 3800 },
    { id: 'user-9', name: 'David Query', xp: 2600 },
    { id: 'user-10', name: 'Chloe Build', xp: 2150 },
    { id: 'user-11', name: 'Nate Flex', xp: 1700 },
    { id: 'user-12', name: 'Ivy Code', xp: 1100 },
    { id: 'user-13', name: 'Peter Storm', xp: 850 },
    { id: 'user-14', name: 'Sara Smith', xp: 600 },
    { id: 'user-15', name: 'John Doe', xp: 300 },
];

export default function LeaderboardModal({ onClose, currentUser }: LeaderboardModalProps) {
    
    const leaderboardData = useMemo(() => {
        const processedMocks: LeaderboardUser[] = mockUsersRaw.map(user => ({
            ...user,
            rank: getRankForXp(user.xp),
        }));

        const currentUserData: LeaderboardUser = {
            id: 'current-user',
            name: currentUser.name || 'You',
            xp: currentUser.xp,
            rank: currentUser.rank
        };
        
        const combined = [
            ...processedMocks.filter(u => u.name.toLowerCase() !== currentUserData.name.toLowerCase()),
            currentUserData
        ];
        
        return combined.sort((a, b) => b.xp - a.xp);

    }, [currentUser]);

    const currentUserRankIndex = leaderboardData.findIndex(u => u.id === 'current-user');

    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-100">Global Leaderboard</h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </button>
            </header>

            <main className="flex-1 overflow-y-auto p-4 sm:p-8">
                <div className="max-w-2xl mx-auto">
                    <ul className="space-y-2">
                        {leaderboardData.slice(0, 15).map((user, index) => (
                            <li 
                                key={user.id} 
                                className={`
                                    flex items-center gap-4 p-3 rounded-lg border transition-colors
                                    ${user.id === 'current-user' 
                                        ? 'bg-violet-500/10 dark:bg-violet-500/20 border-violet-500/30 dark:border-violet-500/50' 
                                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                                    }`
                                }
                            >
                                <div className="w-6 text-center font-bold text-slate-500 dark:text-slate-400">{index + 1}</div>
                                <RankBadge rank={user.rank} />
                                <div className="flex-1 overflow-hidden">
                                    <div className="font-bold text-slate-800 dark:text-slate-100 truncate flex items-center gap-2">
                                        {user.name}
                                        {user.id === 'current-user' && <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500 text-white font-semibold">You</span>}
                                    </div>
                                    <div className="text-xs text-slate-500 dark:text-slate-400">
                                        {user.xp.toLocaleString()} XP
                                    </div>
                                </div>
                            </li>
                        ))}
                    </ul>

                    {currentUserRankIndex >= 15 && (
                        <div className="mt-4 pt-4 border-t-2 border-dashed border-slate-300 dark:border-slate-600">
                            <li 
                                className="flex items-center gap-4 p-3 rounded-lg bg-violet-500/10 dark:bg-violet-500/20 border-violet-500/30 dark:border-violet-500/50"
                            >
                                <div className="w-6 text-center font-bold text-slate-500 dark:text-slate-400">{currentUserRankIndex + 1}</div>
                                <RankBadge rank={currentUser.rank} />
                                <div className="flex-1 overflow-hidden">
                                    <div className="font-bold text-slate-800 dark:text-slate-100 truncate flex items-center gap-2">
                                        {currentUser.name || 'You'}
                                        <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500 text-white font-semibold">You</span>
                                    </div>
                                    <div className="text-xs text-slate-500 dark:text-slate-400">
                                        {currentUser.xp.toLocaleString()} XP
                                    </div>
                                </div>
                            </li>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};
