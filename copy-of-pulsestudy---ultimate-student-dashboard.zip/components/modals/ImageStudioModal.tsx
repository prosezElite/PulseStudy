import React, { useState } from 'react';
import { generateImage, generate3DModelCode } from '../../services/geminiService';

interface ImageStudioModalProps {
  onClose: () => void;
}

const aspectRatios = ["1:1", "16:9", "9:16", "4:3", "3:4"];

export default function ImageStudioModal({ onClose }: ImageStudioModalProps) {
    const [mode, setMode] = useState<'2d' | '3d'>('2d');
    const [prompt, setPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState('1:1');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedContent, setGeneratedContent] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (!prompt.trim()) return;
        setIsLoading(true);
        setError(null);
        setGeneratedContent(null);
        try {
            if (mode === '2d') {
                const imageBytes = await generateImage(prompt, aspectRatio);
                setGeneratedContent(`data:image/jpeg;base64,${imageBytes}`);
            } else {
                const htmlContent = await generate3DModelCode(prompt);
                setGeneratedContent(htmlContent);
            }
        } catch (e: any) {
            setError(e.message || "Failed to generate content.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const promptPlaceholder = mode === '2d' 
        ? "e.g., A diagram of a plant cell with labels..." 
        : "e.g., A 3D model of a retro robot with antennae...";

    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-white font-mono">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg text-cyan-600 dark:text-cyan-300 tracking-wider flex items-center gap-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" />
                        <path fillRule="evenodd" d="M.664 10.59a1.651 1.651 0 010-1.18l3.75-7.043a1.65 1.65 0 012.831.31l3.75 7.043a1.65 1.65 0 01-1.416 2.493H2.08a1.65 1.65 0 01-1.416-2.493zM19.336 10.59a1.651 1.651 0 000-1.18l-3.75-7.043a1.65 1.65 0 00-2.831.31l-3.75 7.043a1.65 1.65 0 001.416 2.493h9.832a1.65 1.65 0 001.416-2.493z" clipRule="evenodd" />
                    </svg>
                    AI CREATIVE STUDIO
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">✕</button>
            </header>

            <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
                {/* Controls */}
                <div className="w-full md:w-1/3 p-4 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50">
                    <div className="flex items-center gap-1 bg-black/5 dark:bg-white/5 p-1 rounded-md mb-4">
                        <button onClick={() => setMode('2d')} className={`w-full py-1 text-sm font-semibold rounded transition-colors ${mode === '2d' ? 'bg-white dark:bg-slate-700 shadow-sm text-slate-800 dark:text-slate-100' : 'text-slate-500 dark:text-slate-400'}`}>
                            2D Image
                        </button>
                        <button onClick={() => setMode('3d')} className={`w-full py-1 text-sm font-semibold rounded transition-colors ${mode === '3d' ? 'bg-white dark:bg-slate-700 shadow-sm text-slate-800 dark:text-slate-100' : 'text-slate-500 dark:text-slate-400'}`}>
                            3D Model
                        </button>
                    </div>

                    <label htmlFor="prompt" className="text-sm font-semibold text-slate-500 dark:text-slate-400">PROMPT</label>
                    <textarea
                        id="prompt"
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                        placeholder={promptPlaceholder}
                        className="w-full h-40 mt-2 p-2 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none resize-none"
                    />
                    
                    {mode === '2d' && (
                        <>
                            <label className="text-sm font-semibold text-slate-500 dark:text-slate-400 mt-4 block">ASPECT RATIO</label>
                            <div className="mt-2 grid grid-cols-5 gap-2">
                                {aspectRatios.map(ar => (
                                    <button
                                        key={ar}
                                        onClick={() => setAspectRatio(ar)}
                                        className={`py-2 rounded-md border text-xs font-semibold transition-colors ${aspectRatio === ar ? 'bg-violet-500 text-white border-violet-500' : 'border-slate-300 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                                    >
                                        {ar}
                                    </button>
                                ))}
                            </div>
                        </>
                    )}

                     <button
                        onClick={handleGenerate}
                        disabled={isLoading || !prompt.trim()}
                        className="mt-6 w-full px-5 py-3 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-bold tracking-wider transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? 'GENERATING...' : 'GENERATE'}
                    </button>
                    {error && <p className="mt-2 text-xs text-red-400">{error}</p>}
                </div>

                {/* Preview */}
                <div className="flex-1 flex items-center justify-center p-4 bg-slate-200 dark:bg-slate-800">
                    {isLoading && (
                        <div className="text-center space-y-3">
                            <div className="w-10 h-10 mx-auto border-4 border-violet-500/20 border-t-violet-500 rounded-full animate-spin"></div>
                            <p className="text-violet-500 dark:text-violet-300 animate-pulse">CREATING...</p>
                        </div>
                    )}
                    {generatedContent && (
                         mode === '2d' ? (
                            <img src={generatedContent} alt={prompt} className="max-w-full max-h-full object-contain rounded-lg shadow-2xl animate-fade-in" />
                        ) : (
                            <iframe 
                                srcDoc={generatedContent}
                                title="3D Model Preview"
                                sandbox="allow-scripts"
                                className="w-full h-full border-0 rounded-lg shadow-2xl bg-white dark:bg-slate-700 animate-fade-in"
                            />
                        )
                    )}
                    {!isLoading && !generatedContent && (
                         <div className="text-center text-slate-500">
                             <p>Your generated {mode === '2d' ? 'diagram' : '3D model'} will appear here.</p>
                             <p className="text-xs mt-1">Powered by Gemini.</p>
                         </div>
                    )}
                </div>
            </main>
        </div>
    );
}
