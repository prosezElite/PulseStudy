import React, { useState } from 'react';
import type { Dream, Task, Note } from '../../types';
import { analyzeDreamCorrelations } from '../../services/geminiService';

interface DreamJournalModalProps {
  dreams: Dream[];
  setDreams: React.Dispatch<React.SetStateAction<Dream[]>>;
  tasks: Task[];
  notes: Note[];
  onClose: () => void;
}

export default function DreamJournalModal({ dreams, setDreams, tasks, notes, onClose }: DreamJournalModalProps) {
    const [newDream, setNewDream] = useState('');
    const [analysis, setAnalysis] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleAddDream = () => {
        if (!newDream.trim()) return;
        const dream: Dream = {
            id: Date.now().toString(),
            date: Date.now(),
            content: newDream.trim(),
        };
        setDreams(prev => [dream, ...prev]);
        setNewDream('');
    };

    const handleAnalyze = async () => {
        if (dreams.length === 0) return;
        setIsLoading(true);
        setAnalysis(null);
        try {
            const result = await analyzeDreamCorrelations(dreams, tasks, notes);
            setAnalysis(result);
        } catch (error) {
            console.error(error);
            setAnalysis("Could not analyze correlations at this time.");
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 dark:bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))] flex flex-col animate-fade-in text-slate-800 dark:text-white">
             <header className="flex-shrink-0 h-16 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg flex items-center gap-3 text-slate-800 dark:text-white">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500 dark:text-violet-400" viewBox="0 0 20 20" fill="currentColor"><path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" /></svg>
                    Dream Journal
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">✕</button>
            </header>
            <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
                <div className="w-full md:w-1/2 p-4 flex flex-col border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700">
                     <textarea
                        value={newDream}
                        onChange={e => setNewDream(e.target.value)}
                        placeholder="What did you dream about...?"
                        className="w-full flex-1 p-3 rounded-md bg-transparent border border-slate-400 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none resize-none"
                    />
                    <button onClick={handleAddDream} disabled={!newDream.trim()} className="mt-2 w-full px-4 py-2 rounded-md bg-violet-500 text-white font-semibold hover:bg-violet-600 disabled:opacity-50">Log Dream</button>
                    
                    <div className="mt-4 p-4 border-t border-slate-200 dark:border-slate-700">
                        {analysis && (
                            <div className="p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-md text-sm text-cyan-700 dark:text-cyan-300 animate-fade-in">
                                <p className="font-bold mb-1">AI Correlation:</p>
                                {analysis}
                            </div>
                        )}
                        <button onClick={handleAnalyze} disabled={isLoading || dreams.length === 0} className="w-full mt-2 px-4 py-2 rounded-md bg-cyan-500/10 text-cyan-700 dark:bg-cyan-500/20 dark:text-cyan-300 font-semibold hover:bg-cyan-500/20 dark:hover:bg-cyan-500/30 disabled:opacity-50">
                            {isLoading ? "Analyzing..." : "Find Correlations"}
                        </button>
                    </div>
                </div>
                <div className="w-full md:w-1/2 p-4 flex flex-col">
                    <h3 className="font-semibold flex-shrink-0 mb-2">Recent Entries</h3>
                    <div className="flex-1 overflow-y-auto space-y-3">
                        {dreams.length > 0 ? dreams.map(dream => (
                             <div key={dream.id} className="p-3 rounded-md bg-slate-200 dark:bg-slate-800/50 border border-slate-300 dark:border-slate-700">
                                <p className="text-xs text-slate-500 dark:text-slate-400">{new Date(dream.date).toLocaleString()}</p>
                                <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{dream.content}</p>
                            </div>
                        )) : <p className="text-center text-slate-500 pt-10">Your dream log is empty.</p>}
                    </div>
                </div>
            </main>
        </div>
    );
}