import React, { useState, useRef, useEffect } from 'react';
import { getResearchAssistantResponse } from '../../services/geminiService';

const RESEARCH_SAMPLE_PROMPTS = [
    "The process of cellular respiration",
    "Key events of the French Revolution",
    "Object-Oriented Programming principles",
    "The history of the Silk Road",
];

const loadingMessages = [
    "Searching the web for high-quality sources...",
    "Analyzing academic papers and articles...",
    "Synthesizing information into a summary...",
    "Cross-referencing facts and figures...",
];

const MarkdownRenderer: React.FC<{ text: string }> = ({ text }) => {
    // Simple renderer for **bold**, *italic*, headers, and lists
    const lines = text.split('\n');
    return (
        <div className="prose prose-sm dark:prose-invert max-w-none text-slate-700 dark:text-slate-300">
            {lines.map((line, index) => {
                if (line.startsWith('### ')) return <h3 className="text-slate-800 dark:text-slate-200" key={index}>{line.substring(4)}</h3>;
                if (line.startsWith('## ')) return <h2 className="text-slate-800 dark:text-slate-200" key={index}>{line.substring(3)}</h2>;
                if (line.startsWith('# ')) return <h1 className="text-slate-800 dark:text-slate-100" key={index}>{line.substring(2)}</h1>;
                if (line.startsWith('* ')) return <li key={index}>{line.substring(2)}</li>;
                
                const parts = line.split(/(\*\*.*?\*\*|\*.*?\*)/g);
                return (
                    <p key={index} className="text-slate-700 dark:text-slate-300">
                        {parts.map((part, pIndex) => {
                            if (part.startsWith('**') && part.endsWith('**')) {
                                return <strong key={pIndex} className="text-slate-800 dark:text-slate-200">{part.slice(2, -2)}</strong>;
                            }
                            if (part.startsWith('*') && part.endsWith('*')) {
                                return <em key={pIndex}>{part.slice(1, -1)}</em>;
                            }
                            return <React.Fragment key={pIndex}>{part}</React.Fragment>;
                        })}
                    </p>
                );
            })}
        </div>
    );
};


const ResearchAssistantModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState<{ text: string, sources: any[] } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [topic, setTopic] = useState('');
  const [currentLoadingMessage, setCurrentLoadingMessage] = useState(loadingMessages[0]);

  const outputRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);
  
  useEffect(() => {
    let interval: number;
    if (isLoading) {
        interval = window.setInterval(() => {
            setCurrentLoadingMessage(prev => {
                const currentIndex = loadingMessages.indexOf(prev);
                return loadingMessages[(currentIndex + 1) % loadingMessages.length];
            });
        }, 2500);
    }
    return () => clearInterval(interval);
  }, [isLoading]);


  const handleSearch = async (promptText?: string) => {
    const trimmedInput = promptText || input.trim();
    if (!trimmedInput || isLoading) return;

    setTopic(trimmedInput);
    if (!promptText) setInput('');
    setIsLoading(true);
    setOutput(null);
    setError(null);

    try {
        const aiResponse = await getResearchAssistantResponse(trimmedInput);
        setOutput(aiResponse);
    } catch (e: any) {
        setError(e.message || "Sorry, I encountered an error. Please try again.");
    } finally {
        setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleSearch();
  };

  return (
    <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
        <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
            <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-100 flex items-center gap-2">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M9 9a2 2 0 114 0 2 2 0 01-4 0z" />
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a4 4 0 00-3.446 6.032l-2.261 2.26a1 1 0 101.414 1.414l2.26-2.26A4 4 0 1011 5z" clipRule="evenodd" />
                </svg>
                AI Research Assistant
            </h2>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
            </button>
        </header>

      <main ref={outputRef} className="flex-1 overflow-y-auto p-4 sm:p-8">
        <div className="max-w-4xl mx-auto">
            {!output && !isLoading && !topic ? (
                <div className="text-center h-full flex flex-col justify-center animate-fade-in-up">
                    <p className="text-slate-500 dark:text-slate-400 mb-4">What topic do you need to research? I'll scour the web for you. Try one of these:</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {RESEARCH_SAMPLE_PROMPTS.map((p, i) => (
                            <button key={i} onClick={() => handleSearch(p)} className="p-3 text-sm text-left rounded-md bg-white dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-colors text-slate-600 dark:text-slate-300">
                                {p}
                            </button>
                        ))}
                    </div>
                </div>
            ) : (
                <div className="space-y-6">
                    {topic && (
                        <div className="p-3 rounded-lg bg-cyan-500/10 dark:bg-cyan-500/20 text-cyan-800 dark:text-cyan-300 border border-cyan-500/20 dark:border-cyan-500/30">
                            <strong className="font-semibold">Researching:</strong>
                            <p className="mt-1">{topic}</p>
                        </div>
                    )}
                    {isLoading && (
                         <div className="p-4 text-center">
                            <div className="w-6 h-6 mx-auto border-2 border-slate-400 dark:border-slate-500 border-t-slate-800 dark:border-t-slate-100 rounded-full animate-spin"></div>
                            <p className="text-sm text-slate-500 mt-2">{currentLoadingMessage}</p>
                        </div>
                    )}
                    {error && <p className="text-red-500">{error}</p>}
                    {output && (
                        <div className="p-4 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4 animate-fade-in-up">
                            <div>
                                <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100 border-b border-slate-200 dark:border-slate-700 pb-2 mb-2">Summary</h3>
                                <MarkdownRenderer text={output.text} />
                            </div>
                            {output.sources.length > 0 && (
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100 border-b border-slate-200 dark:border-slate-700 pb-2 mb-2">Sources</h3>
                                    <ul className="space-y-2">
                                        {output.sources.map((source, index) => (
                                            <li key={index}>
                                                <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 dark:text-blue-400 hover:underline block truncate">
                                                   {source.web.title || source.web.uri}
                                                </a>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}
        </div>
      </main>
      
      <footer className="flex-shrink-0 p-4 border-t border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md">
        <div className="flex gap-2 max-w-4xl mx-auto">
            <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter a research topic..."
                disabled={isLoading}
                className="flex-1 p-3 rounded-md bg-transparent border border-slate-400 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none transition disabled:opacity-50 text-slate-800 dark:text-slate-100"
            />
            <button
                onClick={() => handleSearch()}
                disabled={isLoading || !input.trim()}
                className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" /></svg>
            </button>
        </div>
      </footer>
    </div>
  );
};

export default ResearchAssistantModal;