import React, { useState, useRef, useEffect } from 'react';
import { getConceptStressTest } from '../../services/geminiService';
import type { ConceptChallenge } from '../../types';

interface ConceptStressTestModalProps {
  onClose: () => void;
}

const TEST_SAMPLE_PROMPTS = [
    "Photosynthesis",
    "Newton's Third Law of Motion",
    "Supply and Demand",
    "The Water Cycle",
];


export default function ConceptStressTestModal({ onClose }: ConceptStressTestModalProps) {
    const [topic, setTopic] = useState('');
    const [challenge, setChallenge] = useState<ConceptChallenge | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [showHint, setShowHint] = useState(false);

    const handleGenerate = async (promptText?: string) => {
        const selectedTopic = promptText || topic;
        if (!selectedTopic.trim()) return;

        setIsLoading(true);
        setError(null);
        setChallenge(null);
        setShowHint(false);
        try {
            const result = await getConceptStressTest(selectedTopic);
            setChallenge(result);
        } catch (e: any) {
            setError(e.message || "Failed to generate a challenge. The AI might be recharging.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100 font-mono">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg text-cyan-600 dark:text-cyan-300 tracking-wider flex items-center gap-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
                    CONCEPT STRESS TEST
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">✕</button>
            </header>

            <main className="flex-1 flex items-center justify-center p-4 relative overflow-hidden">
                <div className="absolute inset-0 w-full h-full bg-grid-cyan-500/10 [mask-image:radial-gradient(ellipse_at_center,white,transparent_70%)]"></div>
                <div className="absolute top-0 left-0 w-full h-2 bg-cyan-400/50 animate-[scanline_4s_ease-in-out_infinite] blur-xl"></div>
                
                <div className="w-full max-w-3xl text-center z-10">
                    {!challenge && !isLoading && (
                         <div className="animate-fade-in-up">
                            <h3 className="text-3xl font-bold text-slate-800 dark:text-white">Enter a Concept to Challenge Your Understanding.</h3>
                            <p className="mt-2 text-slate-500 dark:text-slate-400">The AI will generate a question designed to test the limits of your knowledge.</p>
                             <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl mx-auto">
                                {TEST_SAMPLE_PROMPTS.map(p => (
                                    <button key={p} onClick={() => {setTopic(p); handleGenerate(p);}} className="p-3 text-sm text-left rounded-md bg-white/50 dark:bg-slate-800/70 hover:bg-slate-200/70 dark:hover:bg-slate-700/70 border border-slate-300 dark:border-slate-700 transition-colors text-slate-600 dark:text-slate-300">
                                        &rarr; {p}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                    
                    {isLoading && (
                        <div className="space-y-4">
                            <div className="w-12 h-12 mx-auto border-4 border-cyan-400/20 border-t-cyan-400 rounded-full animate-spin"></div>
                            <p className="text-cyan-500 dark:text-cyan-300 animate-pulse">STRESS-TESTING PARAMETERS...</p>
                        </div>
                    )}

                    {error && <p className="text-red-500 p-4 bg-red-500/10 border border-red-500/30 rounded-md">{error}</p>}
                    
                    {challenge && (
                        <div className="animate-fade-in-up space-y-6">
                             <p className="text-sm text-slate-500 dark:text-slate-400">TOPIC: {topic}</p>
                             <h4 className="text-2xl md:text-3xl font-semibold text-slate-800 dark:text-white leading-relaxed">{challenge.challenge}</h4>
                             <div>
                                <button onClick={() => setShowHint(h => !h)} className="text-xs text-yellow-600/70 dark:text-yellow-400/70 hover:text-yellow-600 dark:hover:text-yellow-400 tracking-widest border border-yellow-500/30 dark:border-yellow-400/30 px-3 py-1 rounded-full hover:bg-yellow-500/10 dark:hover:bg-yellow-400/10 transition-colors">
                                    {showHint ? 'HIDE HINT' : 'SHOW HINT'}
                                 </button>
                                 {showHint && (
                                     <p className="mt-3 text-sm text-yellow-600 dark:text-yellow-500 italic max-w-xl mx-auto animate-fade-in">{challenge.hint}</p>
                                 )}
                             </div>
                        </div>
                    )}
                </div>
            </main>

             <footer className="flex-shrink-0 p-4 border-t border-slate-200 dark:border-slate-700 bg-white/50 dark:bg-slate-800/50 backdrop-blur-md z-10">
                <div className="flex gap-2 max-w-3xl mx-auto">
                    <input
                        type="text"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                        placeholder="Enter a topic (e.g., General Relativity, Mitosis...)"
                        disabled={isLoading}
                        className="flex-1 p-3 rounded-md bg-transparent border border-slate-400 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none transition disabled:opacity-50 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                    />
                    <button
                        onClick={() => handleGenerate()}
                        disabled={isLoading || !topic.trim()}
                        className="px-6 py-3 flex-shrink-0 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-bold tracking-wider transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        GENERATE
                    </button>
                </div>
            </footer>
        </div>
    );
}