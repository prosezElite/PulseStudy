import React, { useState, useRef, useEffect, useCallback } from 'react';
import functionPlot from 'function-plot';
import { useDebounce } from '../../hooks/useLocalStorage';

const presetFunctions = ['x^2', 'x^3', 'sqrt(x)', 'sin(x)', 'cos(x)', 'log(x)'];

const GraphingCalculatorModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [fn, setFn] = useState('sin(x)');
    const debouncedFn = useDebounce(fn, 500); // Debounce input for live plotting
    const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
    const graphRef = useRef<HTMLDivElement>(null);

    // Observe theme changes
    useEffect(() => {
        const observer = new MutationObserver(() => {
            setIsDarkMode(document.documentElement.classList.contains('dark'));
        });
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
        return () => observer.disconnect();
    }, []);

    // The core plotting function. It's memoized and only depends on theme.
    const plotFunction = useCallback((functionString: string) => {
        if (!graphRef.current) return;
        
        const width = graphRef.current.clientWidth;
        const height = graphRef.current.clientHeight;
        
        if (width === 0 || height === 0) return;

        graphRef.current.innerHTML = ''; // Clear previous plot

        // Filter out empty strings which cause errors
        const functions = functionString.split(',')
            .map(func => func.trim())
            .filter(Boolean);
            
        // Don't plot if there's nothing valid to plot
        if (functions.length === 0) {
            return;
        }

        try {
            functionPlot({
                target: graphRef.current,
                width,
                height,
                grid: true,
                data: functions.map(f => ({ fn: f })),
                tip: { xLine: true, yLine: true },
                xAxis: { label: 'x', color: isDarkMode ? '#94a3b8' : '#475569' },
                yAxis: { label: 'y', color: isDarkMode ? '#94a3b8' : '#475569' },
            });
            // HACK for styling grid and text colors based on theme
            setTimeout(() => {
                if (!graphRef.current) return;
                const gridLines = graphRef.current.querySelectorAll('.grid');
                gridLines.forEach(line => {
                    (line as SVGPathElement).style.stroke = isDarkMode ? 'rgba(148, 163, 184, 0.1)' : 'rgba(71, 85, 105, 0.1)';
                });
                const textElements = graphRef.current.querySelectorAll('text');
                textElements.forEach(text => {
                    (text as SVGTextElement).style.fill = isDarkMode ? '#94a3b8' : '#475569';
                });
            }, 0);
        } catch (e) {
            console.error("Function plot error:", e);
            // Only show error if the input wasn't just whitespace or empty
            if (functionString.trim()) {
                graphRef.current.innerHTML = `<p class="p-4 text-red-500">Invalid function. Examples: x^2, sin(x), 1/x</p>`;
            }
        }
    }, [isDarkMode]);

    // This single useEffect handles live updates from typing, theme changes, and resizes.
    useEffect(() => {
        // Plot immediately on debounced input change or theme change.
        plotFunction(debouncedFn);

        // Also handle window resizing with a debounce.
        let timeoutId: number;
        const handleResize = () => {
            clearTimeout(timeoutId);
            timeoutId = window.setTimeout(() => plotFunction(debouncedFn), 200);
        };
        
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, [debouncedFn, isDarkMode, plotFunction]);
    
    // Initial draw on mount
    useEffect(() => {
        const timeoutId = setTimeout(() => plotFunction('sin(x)'), 50);
        return () => clearTimeout(timeoutId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [plotFunction]);


    const handlePlot = (e: React.FormEvent) => {
        e.preventDefault();
        // Plot immediately with the current (non-debounced) input value
        plotFunction(fn);
    };

    const handlePresetClick = (preset: string) => {
        setFn(f => f.trim() ? `${f.trim()}, ${preset}` : preset);
    };

    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3 6C8.5 6 9 18 15 18s5-12 8-12" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h18" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18" />
                    </svg>
                    Graphing Calculator
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </button>
            </header>

            <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
                <div className="w-full md:w-80 p-4 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50 flex flex-col">
                    <form onSubmit={handlePlot} className="flex flex-col flex-1">
                        <label htmlFor="fn-input" className="font-semibold text-slate-800 dark:text-slate-100">Function(s)</label>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Enter a function, e.g., <code className="bg-black/10 dark:bg-white/10 px-1 rounded">x^2</code>. Separate multiple functions with a comma.</p>
                        <textarea
                            id="fn-input"
                            value={fn}
                            onChange={(e) => setFn(e.target.value)}
                            className="w-full h-24 mt-2 p-2 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none resize-none"
                        />
                        <button type="submit" className="mt-4 px-4 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105">
                            Plot
                        </button>
                    </form>

                     <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700">
                        <h4 className="font-semibold text-slate-800 dark:text-slate-100 text-sm">Presets</h4>
                        <div className="mt-2 grid grid-cols-3 gap-2">
                            {presetFunctions.map(p => (
                                <button
                                    key={p}
                                    onClick={() => handlePresetClick(p)}
                                    className="p-2 text-xs rounded-md bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 transition-colors font-mono"
                                >
                                    {p}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
                <div ref={graphRef} className="flex-1 bg-white dark:bg-slate-900" />
            </main>
        </div>
    );
};

export default GraphingCalculatorModal;