import React, { useState } from 'react';
import type { Quiz, Question, KeyTimestamp, YouTubeBookmark } from '../../types';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { 
    summarizeYouTubeVideo, 
    generateQuizFromYouTubeVideo, 
    getKeyTimestampsFromYouTubeVideo 
} from '../../services/geminiService';

interface StudyYoutubeModalProps {
  onClose: () => void;
}

type OutputMode = 'summary' | 'quiz' | 'timestamps';
type ActiveTab = 'tools' | 'bookmarks';

const getYouTubeVideoId = (url: string): string | null => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
};

const QuizComponent: React.FC<{ quiz: Quiz }> = ({ quiz }) => {
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
    const [isAnswered, setIsAnswered] = useState(false);
    const [score, setScore] = useState(0);

    const currentQuestion = quiz.questions[currentQuestionIndex];
    
    const handleAnswerSubmit = () => {
        if (!selectedAnswer) return;
        if (selectedAnswer === currentQuestion.answer) {
            setScore(s => s + 1);
        }
        setIsAnswered(true);
    };

    const handleNext = () => {
        setIsAnswered(false);
        setSelectedAnswer(null);
        setCurrentQuestionIndex(i => i + 1);
    };

    if (currentQuestionIndex >= quiz.questions.length) {
        return <div className="p-4 text-center">
            <h3 className="font-bold text-lg">Quiz Complete!</h3>
            <p>Your score: {score} / {quiz.questions.length}</p>
        </div>;
    }
    
    const getButtonClass = (option: string) => {
        if (!isAnswered) {
            return `bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 ${selectedAnswer === option ? 'ring-2 ring-violet-500' : ''}`;
        }
        if (option === currentQuestion.answer) return 'bg-green-500/30 text-green-800 dark:text-green-300';
        if (option === selectedAnswer) return 'bg-red-500/30 text-red-800 dark:text-red-300';
        return 'bg-black/5 dark:bg-white/5 opacity-60';
    };

    return (
        <div className="p-4">
            <p className="text-xs text-slate-500 dark:text-slate-400">Question {currentQuestionIndex + 1} of {quiz.questions.length}</p>
            <p className="font-semibold my-2">{currentQuestion.questionText}</p>
            <div className="space-y-2 mt-3">
                {(currentQuestion.options || ['True', 'False']).map(option => (
                    <button key={option} onClick={() => !isAnswered && setSelectedAnswer(option)} disabled={isAnswered} className={`w-full p-2 text-left rounded-md text-sm transition-all ${getButtonClass(option)}`}>
                        {option}
                    </button>
                ))}
            </div>
            {isAnswered && (
                <div className="mt-3 p-2 text-sm rounded-md bg-yellow-500/20 text-yellow-800 dark:text-yellow-300 animate-fade-in">
                    <p className="font-bold">{selectedAnswer === currentQuestion.answer ? "Correct!" : "Not quite!"}</p>
                    <p>{currentQuestion.explanation}</p>
                </div>
            )}
            <div className="mt-4 text-right">
                {isAnswered ? (
                    <button onClick={handleNext} className="px-4 py-1.5 rounded-md bg-violet-500 text-white text-sm font-semibold">Next</button>
                ) : (
                    <button onClick={handleAnswerSubmit} disabled={!selectedAnswer} className="px-4 py-1.5 rounded-md bg-slate-600 text-white text-sm font-semibold disabled:opacity-50">Submit</button>
                )}
            </div>
        </div>
    );
};

export default function StudyYoutubeModal({ onClose }: StudyYoutubeModalProps) {
    const [url, setUrl] = useState('');
    const [videoId, setVideoId] = useState<string | null>(null);
    const [outputMode, setOutputMode] = useState<OutputMode | null>(null);
    
    const [summary, setSummary] = useState<string | null>(null);
    const [quiz, setQuiz] = useState<Quiz | null>(null);
    const [timestamps, setTimestamps] = useState<KeyTimestamp[] | null>(null);

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    
    const [activeTab, setActiveTab] = useState<ActiveTab>('tools');
    const [quizLength, setQuizLength] = useState(5);
    const [bookmarkNote, setBookmarkNote] = useState('');
    const [bookmarks, setBookmarks] = useLocalStorage<YouTubeBookmark[]>('pulse-youtube-bookmarks', []);

    const handleUrlSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const id = getYouTubeVideoId(url);
        setVideoId(id);
        if (!id) {
            setError("Invalid YouTube URL. Please check and try again.");
        } else {
            setError(null);
        }
        setSummary(null);
        setQuiz(null);
        setTimestamps(null);
        setOutputMode(null);
        setBookmarkNote('');
    };

    const handleAction = async (mode: OutputMode) => {
        if (!videoId) {
            setError("Please enter a valid YouTube URL first.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setOutputMode(mode);
        
        try {
            switch (mode) {
                case 'summary':
                    setSummary(await summarizeYouTubeVideo(url));
                    break;
                case 'quiz':
                    setQuiz(await generateQuizFromYouTubeVideo(url, quizLength));
                    break;
                case 'timestamps':
                    const result = await getKeyTimestampsFromYouTubeVideo(url);
                    setTimestamps(result.timestamps);
                    break;
            }
        } catch (e: any) {
            setError(e.message || `Failed to generate ${mode}.`);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleAddBookmark = () => {
        if (!videoId || !url) return;
        const newBookmark: YouTubeBookmark = { url, videoId, note: bookmarkNote, date: Date.now() };
        setBookmarks(prev => [newBookmark, ...prev.filter(b => b.videoId !== videoId)]); // Add or update
        setBookmarkNote('');
        setActiveTab('bookmarks');
    };

    const handleLoadBookmark = (bookmark: YouTubeBookmark) => {
        setUrl(bookmark.url);
        setVideoId(bookmark.videoId);
        setBookmarkNote(bookmark.note);
        setActiveTab('tools');
        setOutputMode(null);
        setError(null);
    };

    const handleDeleteBookmark = (date: number) => {
        setBookmarks(prev => prev.filter(b => b.date !== date));
    };

    const renderOutput = () => {
        if (isLoading) {
            return <div className="p-4 text-center text-slate-500 animate-pulse">AI is working...</div>;
        }
        if (error) {
            return <div className="p-4 text-center text-red-500">{error}</div>;
        }
        switch (outputMode) {
            case 'summary':
                return <div className="p-4 whitespace-pre-wrap">{summary}</div>;
            case 'quiz':
                return quiz && <QuizComponent quiz={quiz} />;
            case 'timestamps':
                return (
                    <ul className="p-4 space-y-3">
                        {timestamps?.map(ts => (
                            <li key={ts.time} className="flex items-start gap-3 text-sm">
                                <span className="font-mono font-semibold text-violet-500 dark:text-violet-400 bg-violet-500/10 px-2 py-0.5 rounded">{ts.time}</span>
                                <span className="text-slate-600 dark:text-slate-300">{ts.description}</span>
                            </li>
                        ))}
                    </ul>
                );
            default:
                return (
                  <div className="p-4 space-y-4">
                      {videoId && (
                        <div>
                            <h4 className="font-semibold text-sm mb-2">Bookmark This Video</h4>
                            <textarea
                                value={bookmarkNote}
                                onChange={e => setBookmarkNote(e.target.value)}
                                placeholder="Add a note about this video..."
                                className="w-full h-20 p-2 text-sm rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none"
                            />
                            <button onClick={handleAddBookmark} className="mt-2 w-full px-3 py-1.5 text-sm rounded-md bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20">Save Bookmark</button>
                        </div>
                      )}
                      <p className="text-center text-slate-500 pt-4">Select an action to begin.</p>
                  </div>
                );
        }
    };

    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500" viewBox="0 0 24 24" fill="currentColor"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"></path></svg>
                    Study with YouTube
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">✕</button>
            </header>

            <main className="flex-1 grid grid-cols-1 lg:grid-cols-2 overflow-hidden">
                <div className="p-4 flex flex-col gap-4">
                    <form onSubmit={handleUrlSubmit} className="flex gap-2">
                        <input
                            type="text"
                            value={url}
                            onChange={e => setUrl(e.target.value)}
                            placeholder="Paste YouTube video URL..."
                            className="flex-1 p-2 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none"
                        />
                        <button type="submit" className="px-4 py-2 rounded-md bg-violet-500 text-white font-semibold hover:bg-violet-600">Load</button>
                    </form>
                    <div className="flex-1 w-full min-h-0 relative" style={{ paddingTop: '56.25%' }}>
                        <div className="absolute inset-0 bg-slate-200 dark:bg-black rounded-lg flex items-center justify-center">
                            {videoId ? (
                                <iframe
                                    className="w-full h-full rounded-lg"
                                    src={`https://www.youtube.com/embed/${videoId}?autoplay=1&controls=1`}
                                    title="YouTube video player"
                                    frameBorder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowFullScreen
                                ></iframe>
                            ) : (
                                <p className="text-slate-500">{error || "Video player will appear here"}</p>
                            )}
                        </div>
                    </div>
                </div>

                <div className="p-4 flex flex-col border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-700">
                    <div className="flex-shrink-0 flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                        <div className="flex items-center gap-1 p-1 rounded-md bg-black/5 dark:bg-white/5">
                            <button onClick={() => setActiveTab('tools')} className={`px-3 py-1 text-sm font-semibold rounded ${activeTab === 'tools' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-500 hover:bg-black/5'}`}>AI Tools</button>
                            <button onClick={() => setActiveTab('bookmarks')} className={`px-3 py-1 text-sm font-semibold rounded ${activeTab === 'bookmarks' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-500 hover:bg-black/5'}`}>Bookmarks</button>
                        </div>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto mt-2">
                        {activeTab === 'tools' ? (
                            <>
                                <div className="flex items-center gap-2 p-2 flex-wrap">
                                    <button onClick={() => handleAction('summary')} disabled={isLoading || !videoId} className="px-3 py-1.5 text-sm rounded-md bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 disabled:opacity-50">Summarize</button>
                                    <button onClick={() => handleAction('timestamps')} disabled={isLoading || !videoId} className="px-3 py-1.5 text-sm rounded-md bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 disabled:opacity-50">Key Timestamps</button>
                                    <div className="flex items-center gap-2 p-1.5 rounded-md bg-black/5 dark:bg-white/10">
                                        <button onClick={() => handleAction('quiz')} disabled={isLoading || !videoId} className="px-3 text-sm disabled:opacity-50">Quiz Me</button>
                                        <select value={quizLength} onChange={e => setQuizLength(Number(e.target.value))} disabled={isLoading || !videoId} className="bg-transparent text-xs p-1 rounded border border-slate-300 dark:border-slate-600 focus:ring-1 focus:ring-violet-500 disabled:opacity-50">
                                            <option value={5}>5 Qs</option>
                                            <option value={10}>10 Qs</option>
                                            <option value={15}>15 Qs</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="border-t border-slate-200 dark:border-slate-700">
                                    {renderOutput()}
                                </div>
                            </>
                        ) : (
                            <div className="p-2">
                                {bookmarks.length > 0 ? (
                                    <ul className="space-y-2">
                                        {bookmarks.map(b => (
                                            <li key={b.date} className="p-3 rounded-md bg-black/5 dark:bg-white/5 group">
                                                <div className="flex justify-between items-start">
                                                    <button onClick={() => handleLoadBookmark(b)} className="text-left">
                                                        <p className="text-xs truncate max-w-xs text-slate-500 dark:text-slate-400 group-hover:underline">{b.url}</p>
                                                        <p className="text-sm mt-1">{b.note || 'No note.'}</p>
                                                    </button>
                                                    <button onClick={() => handleDeleteBookmark(b.date)} className="p-1 rounded-full hover:bg-red-500/10 text-slate-400 hover:text-red-500">
                                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
                                                    </button>
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <p className="text-center text-slate-500 pt-8">No bookmarks yet. Load a video and save it!</p>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </main>
        </div>
    );
}