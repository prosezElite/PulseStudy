import React, { useState, useEffect, useRef } from 'react';
import { startVideoGeneration, checkVideoOperation } from '../../services/geminiService';
import type { Note } from '../../types';

interface VideoStudioModalProps {
  notes: Note[];
  onClose: () => void;
}

const loadingMessages = [
  "Reticulating splines...",
  "Gathering pixels from the digital ether...",
  "Teaching photons to dance...",
  "Consulting the oracle of motion...",
  "Assembling the cinematic dream sequence...",
  "This can take a few minutes, time for a quick stretch!",
];

export default function VideoStudioModal({ notes, onClose }: VideoStudioModalProps) {
    const [hasApiKey, setHasApiKey] = useState(false);
    const [isCheckingApiKey, setIsCheckingApiKey] = useState(true);

    const [prompt, setPrompt] = useState('');
    const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);

    const pollIntervalRef = useRef<number | null>(null);

    // Check for API key on mount
    useEffect(() => {
        const checkKey = async () => {
            if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
                const result = await window.aistudio.hasSelectedApiKey();
                setHasApiKey(result);
            }
            setIsCheckingApiKey(false);
        };
        checkKey();
    }, []);

    const handleSelectKey = async () => {
        if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
            await window.aistudio.openSelectKey();
            // Assume success to avoid race condition and allow immediate generation attempt
            setHasApiKey(true);
        }
    };
    
    useEffect(() => {
        // Cleanup polling on unmount
        return () => {
            if (pollIntervalRef.current) {
                clearInterval(pollIntervalRef.current);
            }
        };
    }, []);
    
    // Loading message rotator
     useEffect(() => {
        if (isLoading) {
            const interval = setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    const nextIndex = (currentIndex + 1) % loadingMessages.length;
                    return loadingMessages[nextIndex];
                });
            }, 4000);
            return () => clearInterval(interval);
        }
    }, [isLoading]);

    const pollForVideo = (operation: any) => {
        pollIntervalRef.current = window.setInterval(async () => {
            try {
                const updatedOperation = await checkVideoOperation(operation);
                if (updatedOperation.done) {
                    clearInterval(pollIntervalRef.current!);
                    const downloadLink = updatedOperation.response?.generatedVideos?.[0]?.video?.uri;
                    if (downloadLink) {
                        // The service worker will append the API key
                        setVideoUrl(downloadLink);
                    } else {
                        setError("Video generation complete, but no video URL was found.");
                    }
                    setIsLoading(false);
                }
            } catch (e: any) {
                console.error("Polling error:", e);
                setError(`An error occurred while checking video status: ${e.message}`);
                setIsLoading(false);
                clearInterval(pollIntervalRef.current!);
            }
        }, 10000); // Poll every 10 seconds
    };

    const handleGenerate = async () => {
        if (!prompt.trim() && !selectedNoteId) return;
        setIsLoading(true);
        setError(null);
        setVideoUrl(null);
        setLoadingMessage(loadingMessages[0]);

        try {
            const note = selectedNoteId ? notes.find(n => n.id === selectedNoteId) || null : null;
            const operation = await startVideoGeneration(prompt, note);
            pollForVideo(operation);
        } catch (e: any) {
            if (e.message?.includes("Requested entity was not found.")) {
                setError("Your API key is invalid. Please select a valid one.");
                setHasApiKey(false); // Reset key selection state
            } else {
                setError(e.message || "Failed to start video generation.");
            }
            setIsLoading(false);
        }
    };
    
    if (isCheckingApiKey) {
        return <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex items-center justify-center animate-fade-in text-slate-800 dark:text-white">Loading...</div>;
    }

    if (!hasApiKey) {
        return (
            <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col items-center justify-center animate-fade-in text-slate-800 dark:text-white text-center p-8">
                 <h2 className="font-semibold text-lg text-violet-500 dark:text-violet-300 tracking-wider">API KEY REQUIRED</h2>
                 <p className="mt-4 max-w-md text-slate-600 dark:text-slate-300">
                    The AI Video Studio uses advanced models that require you to select your own API key. This is a mandatory step. Please ensure your project has billing enabled.
                 </p>
                 <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-sm text-cyan-500 dark:text-cyan-400 hover:underline mt-2">Learn more about billing.</a>
                 <div className="flex gap-4 mt-8">
                    <button onClick={onClose} className="px-5 py-2 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white font-semibold">Cancel</button>
                    <button onClick={handleSelectKey} className="px-5 py-2 rounded-md bg-violet-500 text-white font-semibold">Select API Key</button>
                 </div>
            </div>
        );
    }
    
    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-white font-mono">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg text-violet-500 dark:text-violet-300 tracking-wider flex items-center gap-3">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 001.553.832l3-2a1 1 0 000-1.664l-3-2z" /></svg>
                    AI VIDEO STUDIO
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">✕</button>
            </header>

            <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
                {/* Controls */}
                <div className="w-full md:w-1/3 p-4 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50">
                    <label className="text-sm font-semibold text-slate-500 dark:text-slate-400">PROMPT</label>
                    <textarea
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                        placeholder="e.g., A cinematic shot of a computer motherboard with electricity flowing through circuits..."
                        className="w-full h-32 mt-2 p-2 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none resize-none"
                    />
                    
                    <label className="text-sm font-semibold text-slate-500 dark:text-slate-400 mt-4 block">OR GENERATE FROM NOTE</label>
                    <select
                        value={selectedNoteId || ''}
                        onChange={e => setSelectedNoteId(e.target.value)}
                        className="w-full mt-2 p-2 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none"
                    >
                        <option value="">-- Select a note --</option>
                        {notes.map(note => <option key={note.id} value={note.id}>{note.title}</option>)}
                    </select>

                     <button
                        onClick={handleGenerate}
                        disabled={isLoading || (!prompt.trim() && !selectedNoteId)}
                        className="mt-6 w-full px-5 py-3 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-bold tracking-wider transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? 'GENERATING...' : 'GENERATE VIDEO'}
                    </button>
                    {error && <p className="mt-2 text-xs text-red-400">{error}</p>}
                </div>

                {/* Preview */}
                <div className="flex-1 flex items-center justify-center p-4">
                    {isLoading && (
                        <div className="text-center space-y-3">
                            <div className="w-10 h-10 mx-auto border-4 border-violet-500/20 border-t-violet-500 rounded-full animate-spin"></div>
                            <p className="text-violet-500 dark:text-violet-300 animate-pulse">{loadingMessage}</p>
                        </div>
                    )}
                    {videoUrl && (
                        <video src={`${videoUrl}&key=${process.env.API_KEY}`} controls autoPlay loop className="max-w-full max-h-full object-contain rounded-lg shadow-2xl animate-fade-in" />
                    )}
                    {!isLoading && !videoUrl && (
                         <div className="text-center text-slate-500">
                             <p>Your generated video will appear here.</p>
                             <p className="text-xs mt-1">Powered by Veo.</p>
                         </div>
                    )}
                </div>
            </main>
        </div>
    );
}