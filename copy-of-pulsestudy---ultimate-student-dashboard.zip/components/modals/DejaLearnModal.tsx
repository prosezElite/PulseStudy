import React, { useState, useEffect, useMemo } from 'react';
import type { Note, Task, DejaLearnItem } from '../../types';
import { getDejaLearnQuestion } from '../../services/geminiService';

interface DejaLearnModalProps {
  notes: Note[];
  tasks: Task[];
  onClose: () => void;
}

export default function DejaLearnModal({ notes, tasks, onClose }: DejaLearnModalProps) {
    const [currentItem, setCurrentItem] = useState<DejaLearnItem | null>(null);
    const [question, setQuestion] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [showAnswer, setShowAnswer] = useState(false);

    const allItems = useMemo(() => [...notes, ...tasks], [notes, tasks]);

    useEffect(() => {
        if (allItems.length === 0) {
            setIsLoading(false);
            return;
        }

        const getNextItem = async () => {
            setIsLoading(true);
            setShowAnswer(false);
            setQuestion('');

            const now = Date.now();
            const scoredItems: DejaLearnItem[] = allItems
                .map(item => {
                    const daysSince = (now - item.created) / (1000 * 60 * 60 * 24);
                    // Simple decay: higher score for older items, maxing out around 30 days
                    const memoryDecay = Math.min(1, Math.log10(daysSince + 1) / 1.5);
                    return {
                        type: ('done' in item ? 'task' : 'note') as 'task' | 'note',
                        item,
                        memoryDecay,
                    };
                })
                .sort((a, b) => b.memoryDecay - a.memoryDecay);
            
            // Select a random item from the top 5 most "forgotten"
            const topItems = scoredItems.slice(0, 5);
            const selected = topItems[Math.floor(Math.random() * topItems.length)];
            setCurrentItem(selected);
            
            try {
                const generatedQuestion = await getDejaLearnQuestion(selected.item);
                setQuestion(generatedQuestion);
            } catch (error) {
                console.error(error);
                setQuestion("What was the main point of this item?");
            } finally {
                setIsLoading(false);
            }
        };

        getNextItem();
    }, [allItems]);

    const handleNext = () => {
         const getNextItem = async () => {
            setIsLoading(true);
            setShowAnswer(false);
            setQuestion('');

            const now = Date.now();
            const scoredItems: DejaLearnItem[] = allItems
                .map(item => {
                    const daysSince = (now - item.created) / (1000 * 60 * 60 * 24);
                    const memoryDecay = Math.min(1, Math.log10(daysSince + 1) / 1.5);
                    return {
                        type: ('done' in item ? 'task' : 'note') as 'task' | 'note',
                        item,
                        memoryDecay,
                    };
                })
                .sort((a, b) => b.memoryDecay - a.memoryDecay);
            
            const topItems = scoredItems.slice(0, 5);
            const selected = topItems[Math.floor(Math.random() * topItems.length)];
            setCurrentItem(selected);
            
            try {
                const generatedQuestion = await getDejaLearnQuestion(selected.item);
                setQuestion(generatedQuestion);
            } catch (error) {
                console.error(error);
                setQuestion("What was the main point of this item?");
            } finally {
                setIsLoading(false);
            }
        };

        getNextItem();
    };

    return (
        <div className="fixed inset-0 z-[60] bg-indigo-100 dark:bg-indigo-900 dark:bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(56,189,248,0.3),rgba(255,255,255,0))] flex flex-col items-center justify-center p-4 text-slate-800 dark:text-white animate-fade-in">
            <header className="absolute top-0 left-0 right-0 flex-shrink-0 h-16 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg flex items-center gap-3">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500 dark:text-blue-400" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8.257 3.099A.75.75 0 019 2.5h2a.75.75 0 01.743.599l.823 3.292a.75.75 0 01-.364 1.118l-1.921.96a.75.75 0 01-.867 0l-1.921-.96a.75.75 0 01-.364-1.118l.823-3.292zM12 11a1 1 0 11-2 0 1 1 0 012 0zM11.601 14.341a.75.75 0 01-1.202 0l-.823-1.646a.75.75 0 011.06-1.06l.265.265.265-.265a.75.75 0 011.06 1.06l-.823 1.646z" clipRule="evenodd" /><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM3 10a7 7 0 1114 0 7 7 0 01-14 0z" clipRule="evenodd" /></svg>
                   Memory Injection: DejaLearn
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300" aria-label="Close">✕</button>
            </header>

            <div className="w-full max-w-2xl text-center">
            {isLoading ? (
                <p className="animate-pulse">Searching memories...</p>
            ) : !currentItem ? (
                <p>You need more notes or tasks to start a session.</p>
            ) : (
                <div className="animate-fade-in-up">
                    <div className="p-8 bg-black/5 dark:bg-black/20 backdrop-blur-sm border border-slate-300 dark:border-white/10 rounded-lg min-h-[250px] flex flex-col justify-center">
                        <p className="text-xl font-semibold text-blue-700 dark:text-blue-300">{question}</p>
                        {showAnswer && (
                            <div className="mt-6 pt-4 border-t border-slate-300 dark:border-white/20 animate-fade-in">
                                <p className="text-sm text-slate-500 dark:text-slate-400 font-semibold">{currentItem.item.title}</p>
                                {currentItem.type === 'note' && <p className="mt-1 text-slate-600 dark:text-slate-300 max-h-24 overflow-y-auto">{(currentItem.item as Note).body}</p>}
                            </div>
                        )}
                    </div>
                    <div className="mt-6 flex justify-center gap-4">
                        <button onClick={() => setShowAnswer(true)} disabled={showAnswer} className="px-6 py-2 rounded-md bg-black/5 dark:bg-white/10 border border-slate-300 dark:border-white/20 hover:bg-black/10 dark:hover:bg-white/20 disabled:opacity-50">
                            Reveal Answer
                        </button>
                        <button onClick={handleNext} className="px-6 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white hover:opacity-90 font-semibold">
                            Next Item
                        </button>
                    </div>
                </div>
            )}
            </div>
        </div>
    );
}