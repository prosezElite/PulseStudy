import React, { useState, useEffect, useRef } from 'react';
import type { FocusSessionHistory, SessionRewindData, Task, Note } from '../../types';
import { generateSessionSummary, generateSpeech } from '../../services/geminiService';

// --- AUDIO HELPER FUNCTIONS ---
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
// --- END AUDIO HELPER FUNCTIONS ---


// --- PARTICLE ANIMATION ---
class Particle {
    x: number; y: number;
    vx: number; vy: number;
    alpha: number;
    color: string;
    constructor(x: number, y: number, color: string) {
        this.x = x;
        this.y = y;
        this.vx = (Math.random() - 0.5) * 4;
        this.vy = (Math.random() - 0.5) * 4;
        this.alpha = 1;
        this.color = color;
    }
    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.alpha -= 0.02;
    }
    draw(ctx: CanvasRenderingContext2D) {
        ctx.globalAlpha = this.alpha;
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, 2, 0, Math.PI * 2);
        ctx.fill();
    }
}
// --- END PARTICLE ANIMATION ---

interface SessionRewindModalProps {
  session: FocusSessionHistory;
  tasks: Task[];
  notes: Note[];
  onClose: () => void;
}

export default function SessionRewindModal({ session, tasks, notes, onClose }: SessionRewindModalProps) {
  const [rewindData, setRewindData] = useState<SessionRewindData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [currentEventIndex, setCurrentEventIndex] = useState(-1);
  const [displayedText, setDisplayedText] = useState('');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameId = useRef<number | null>(null);

  useEffect(() => {
    const fetchDataAndAudio = async () => {
      try {
        const data = await generateSessionSummary(session, tasks, notes);
        setRewindData(data);
        
        // Fetch audio in parallel
        if (data.summary) {
            const audioData = await generateSpeech(data.summary);
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            const audioBuffer = await decodeAudioData(decode(audioData), audioContextRef.current, 24000, 1);
            const source = audioContextRef.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContextRef.current.destination);
            
            // Start playing audio after a delay to sync with summary text appearance
            setTimeout(() => {
                source.start();
            }, 4000);
        }
      } catch (error) {
        console.error("Failed to generate session summary or audio", error);
        setRewindData({ summary: "You had a great focus session!", keyEvents: [] });
      } finally {
        setIsLoading(false);
      }
    };
    fetchDataAndAudio();
  }, [session, tasks, notes]);
  
  const createBurst = (x: number, y: number, color: string) => {
    for (let i = 0; i < 50; i++) {
        particlesRef.current.push(new Particle(x, y, color));
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animateParticles = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particlesRef.current = particlesRef.current.filter(p => p.alpha > 0);
        particlesRef.current.forEach(p => {
            p.update();
            p.draw(ctx);
        });
        animationFrameId.current = requestAnimationFrame(animateParticles);
    };
    animateParticles();

    return () => {
        if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
    };
  }, []);

  useEffect(() => {
    if (!rewindData || isLoading) return;

    const timelineDuration = 5000;
    const startTime = Date.now();

    const animateTimeline = () => {
      const elapsedTime = Date.now() - startTime;
      const currentProgress = Math.min(elapsedTime / timelineDuration, 1);
      setProgress(currentProgress * 100);

      const nextEventIndex = rewindData.keyEvents.findIndex(event => {
        const eventProgress = (event.time - session.startTime) / (session.endTime - session.startTime);
        return eventProgress >= currentProgress;
      });
      
      const potentialCurrentEventIndex = nextEventIndex > 0 ? nextEventIndex - 1 : (currentProgress === 1 ? rewindData.keyEvents.length - 1 : -1);

      if (potentialCurrentEventIndex !== currentEventIndex && potentialCurrentEventIndex !== -1) {
          setCurrentEventIndex(potentialCurrentEventIndex);
          const event = rewindData.keyEvents[potentialCurrentEventIndex];
          const eventProgress = ((event.time - session.startTime) / (session.endTime - session.startTime));
          
          if (event.type === 'task') {
             createBurst(window.innerWidth * eventProgress, window.innerHeight / 2, '#a855f7'); // purple
          } else if (event.type === 'note' && event.keyPhrase) {
             setDisplayedText(event.keyPhrase);
             setTimeout(() => setDisplayedText(''), 2000); // Clear text after 2s
          }
      }

      if (currentProgress < 1) {
        requestAnimationFrame(animateTimeline);
      }
    };

    const startDelay = 1000;
    const timer = setTimeout(animateTimeline, startDelay);
    
    return () => clearTimeout(timer);
  }, [rewindData, isLoading, session.startTime, session.endTime, currentEventIndex]);


  const sessionDuration = session.endTime - session.startTime;

  return (
    <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col items-center justify-center p-8 text-slate-800 dark:text-white animate-fade-in overflow-hidden">
      <canvas ref={canvasRef} id="rewind-particles" width={window.innerWidth} height={window.innerHeight} />
      <button onClick={onClose} className="absolute top-6 right-6 p-2 rounded-full bg-black/10 dark:bg-white/10 hover:bg-black/20 dark:hover:bg-white/20 transition-colors z-20" aria-label="Close">✕</button>
      
      {isLoading ? (
        <p className="animate-pulse text-xl">Generating your session rewind...</p>
      ) : rewindData ? (
        <div className="w-full max-w-3xl text-center relative z-0">
            <h2 className="text-3xl font-bold animate-fade-in-up">Session Rewind</h2>
            <p className="text-cyan-600 dark:text-cyan-300 mt-2 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
                {new Date(session.startTime).toLocaleString()}
            </p>
            
            <div className="relative h-2 my-12 bg-slate-300 dark:bg-slate-700 rounded-full animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
                <div 
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-500 to-violet-500 rounded-full"
                    style={{ width: `${progress}%` }}
                />
                {rewindData.keyEvents.map((event, index) => {
                    const eventProgress = ((event.time - session.startTime) / sessionDuration) * 100;
                    return (
                        <div 
                            key={index}
                            className="absolute top-1/2 -translate-y-1/2 group"
                            style={{ left: `${eventProgress}%` }}
                        >
                            <div className="w-5 h-5 rounded-full bg-white dark:bg-slate-900 flex items-center justify-center">
                                <div className={`w-3 h-3 rounded-full ${event.type === 'task' ? 'bg-violet-500' : 'bg-cyan-500'}`} />
                            </div>
                            <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 w-48 p-2 text-xs bg-slate-200 dark:bg-slate-800 rounded-md border border-slate-300 dark:border-slate-600 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                {event.text}
                            </div>
                        </div>
                    );
                })}
            </div>
            
            {displayedText && <p className="text-3xl font-bold my-4 materialize-text">{displayedText}</p>}

            <p className="text-xl text-slate-600 dark:text-slate-300 animate-fade-in-up" style={{ animationDelay: '4s' }}>
                {rewindData.summary}
            </p>

            <button
                onClick={onClose}
                className="mt-12 px-8 py-3 text-lg bg-slate-200/50 dark:bg-slate-800/50 border-2 border-slate-300 dark:border-slate-700 rounded-md backdrop-blur-sm hover:bg-slate-300/50 dark:hover:bg-slate-700/50 hover:border-slate-400 dark:hover:border-slate-600 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-cyan-400 animate-fade-in-up"
                style={{ animationDelay: '5s' }}
            >
                Awesome!
            </button>

        </div>
      ) : (
        <p>Could not load session rewind data.</p>
      )}
    </div>
  );
}