import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { Task, Note, FocusNode, FocusLink } from '../../types';
import { getSemanticConnections } from '../../services/geminiService';

interface FocusFlowModalProps {
  tasks: Task[];
  notes: Note[];
  onClose: () => void;
}

const NODE_RADIUS = 40;
const STRENGTH = 0.02;
const REPULSION = -150;
const DAMPING = 0.95;

export default function FocusFlowModal({ tasks, notes, onClose }: FocusFlowModalProps) {
  const [nodes, setNodes] = useState<FocusNode[]>([]);
  const [links, setLinks] = useState<FocusLink[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedNode, setSelectedNode] = useState<FocusNode | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameId = useRef<number | null>(null);
  const dragInfo = useRef<{ node: FocusNode; offsetX: number; offsetY: number } | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { nodes: initialNodes, links: initialLinks } = await getSemanticConnections(tasks, notes);
        // Initialize positions randomly
        initialNodes.forEach(node => {
          node.x = Math.random() * (window.innerWidth - 200) + 100;
          node.y = Math.random() * (window.innerHeight - 200) + 100;
          node.vx = 0;
          node.vy = 0;
        });
        setNodes(initialNodes);
        setLinks(initialLinks);
      } catch (error) {
        console.error("Failed to get semantic connections", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [tasks, notes]);
  
  const draw = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.clearRect(0, 0, width, height);
    const isDarkMode = document.documentElement.classList.contains('dark');

    // Draw links
    ctx.strokeStyle = isDarkMode ? 'rgba(100, 116, 139, 0.3)' : 'rgba(156, 163, 175, 0.4)'; // slate-600 / gray-400
    ctx.lineWidth = 1;
    links.forEach(link => {
        const source = nodes.find(n => n.id === link.source);
        const target = nodes.find(n => n.id === link.target);
        if (source && target) {
            ctx.beginPath();
            ctx.moveTo(source.x, source.y);
            ctx.lineTo(target.x, target.y);
            ctx.stroke();
        }
    });

    // Draw nodes
    nodes.forEach(node => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, NODE_RADIUS, 0, Math.PI * 2);
        const isSelected = selectedNode?.id === node.id;
        
        const taskColors = isDarkMode ? { selected: '#a855f7', base: '#c084fc' } : { selected: '#9333ea', base: '#a855f7' };
        const noteColors = isDarkMode ? { selected: '#0ea5e9', base: '#38bdf8' } : { selected: '#0284c7', base: '#0ea5e9' };

        ctx.fillStyle = node.type === 'task' ? 
            (isSelected ? taskColors.selected : taskColors.base) : 
            (isSelected ? noteColors.selected : noteColors.base); 
        ctx.fill();

        ctx.strokeStyle = isSelected ? (isDarkMode ? '#fff' : '#000') : (node.type === 'task' ? taskColors.selected : noteColors.selected);
        ctx.lineWidth = isSelected ? 4 : 2;
        ctx.stroke();

        ctx.fillStyle = isDarkMode ? '#fff' : '#000';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '12px Inter, sans-serif';
        const lines = node.label.split(' ');
        if (lines.length > 2) {
            ctx.fillText(lines.slice(0, 2).join(' ') + '...', node.x, node.y);
        } else {
            ctx.fillText(node.label, node.x, node.y);
        }
    });
  }, [nodes, links, selectedNode]);

  const updatePositions = useCallback(() => {
    if (dragInfo.current) {
        // Skip physics for dragged node
        const draggedNode = dragInfo.current.node;
        draggedNode.vx = 0;
        draggedNode.vy = 0;
    }

    setNodes(currentNodes => {
      const nextNodes = JSON.parse(JSON.stringify(currentNodes)) as FocusNode[];

      // Apply forces
      for (let i = 0; i < nextNodes.length; i++) {
        const nodeA = nextNodes[i];
        if (dragInfo.current?.node.id === nodeA.id) continue;

        // Repulsion from other nodes
        for (let j = 0; j < nextNodes.length; j++) {
            if (i === j) continue;
            const nodeB = nextNodes[j];
            const dx = nodeA.x - nodeB.x;
            const dy = nodeA.y - nodeB.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if (distance > 0) {
                const force = REPULSION / (distance * distance);
                nodeA.vx += (dx / distance) * force;
                nodeA.vy += (dy / distance) * force;
            }
        }

        // Center gravity
        const dx = (window.innerWidth / 2) - nodeA.x;
        const dy = (window.innerHeight / 2) - nodeA.y;
        nodeA.vx += dx * 0.0001;
        nodeA.vy += dy * 0.0001;
      }
      
      // Apply spring force from links
      links.forEach(link => {
          const source = nextNodes.find(n => n.id === link.source);
          const target = nextNodes.find(n => n.id === link.target);
          if (source && target) {
              const dx = target.x - source.x;
              const dy = target.y - source.y;
              source.vx += dx * STRENGTH;
              source.vy += dy * STRENGTH;
              target.vx -= dx * STRENGTH;
              target.vy -= dy * STRENGTH;
          }
      });

      // Update positions
      nextNodes.forEach(node => {
        if (dragInfo.current?.node.id === node.id) return;
        node.vx *= DAMPING;
        node.vy *= DAMPING;
        node.x += node.vx;
        node.y += node.vy;

        // Boundary collision
        node.x = Math.max(NODE_RADIUS, Math.min(window.innerWidth - NODE_RADIUS, node.x));
        node.y = Math.max(NODE_RADIUS, Math.min(window.innerHeight - NODE_RADIUS, node.y));
      });

      return nextNodes;
    });
  }, [links]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animate = () => {
      updatePositions();
      draw(ctx, canvas.width, canvas.height);
      animationFrameId.current = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
    };
  }, [draw, updatePositions]);

  const handleMouseDown = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    for (const node of nodes) {
        const dx = x - node.x;
        const dy = y - node.y;
        if (dx * dx + dy * dy < NODE_RADIUS * NODE_RADIUS) {
            dragInfo.current = { node, offsetX: dx, offsetY: dy };
            setSelectedNode(node);
            return;
        }
    }
    setSelectedNode(null);
  };
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!dragInfo.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    dragInfo.current.node.x = x - dragInfo.current.offsetX;
    dragInfo.current.node.y = y - dragInfo.current.offsetY;
  };
  const handleMouseUp = () => dragInfo.current = null;

  return (
    <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-white">
      <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
        <h2 className="font-semibold text-lg flex items-center gap-2">Focus Flow</h2>
        <button onClick={onClose} className="p-2 rounded-full text-slate-500 dark:text-slate-300 hover:bg-black/10 dark:hover:bg-white/10" aria-label="Close">✕</button>
      </header>
      <main className="flex-1 relative">
        <canvas
            ref={canvasRef}
            width={window.innerWidth}
            height={window.innerHeight}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
        />
        {isLoading && <div className="absolute inset-0 flex items-center justify-center bg-slate-100/50 dark:bg-slate-900/50 text-xl animate-pulse">Analyzing Connections...</div>}
        {selectedNode && (
            <div className="absolute bottom-4 left-4 p-4 rounded-lg bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border border-slate-200 dark:border-slate-700 animate-fade-in-up text-sm">
                <p><span className="font-bold text-slate-500 dark:text-slate-400">Type:</span> {selectedNode.type}</p>
                <p><span className="font-bold text-slate-500 dark:text-slate-400">Label:</span> {selectedNode.label}</p>
            </div>
        )}
      </main>
    </div>
  );
}