import React, { useState, useEffect, useRef } from 'react';
import { getAIRatingAdjustment } from '../../services/geminiService';
import type { Task, Note, FocusSessionHistory } from '../../types';

interface AIRatingAdjustmentModalProps {
  initialRating: number;
  setAiRating: React.Dispatch<React.SetStateAction<number>>;
  onComplete: () => void;
  tasks: Task[];
  notes: Note[];
  focusSessionHistory: FocusSessionHistory[];
  xp: number;
}

type Stage = 'initializing' | 'weaving' | 'superposition' | 'collapse' | 'revealed';

// --- CANVAS ANIMATION HELPERS ---
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

class Blob {
    radius: number;
    x: number;
    y: number;
    numPoints: number;
    points: { angle: number; radiusOffset: number; animPhase: number; animFreq: number; }[];

    constructor(canvasWidth: number, canvasHeight: number) {
        this.radius = Math.min(canvasWidth, canvasHeight) / 3.5;
        this.x = canvasWidth / 2;
        this.y = canvasHeight / 2;
        this.numPoints = 12;
        this.points = [];
        for (let i = 0; i < this.numPoints; i++) {
            this.points.push({
                angle: (i / this.numPoints) * Math.PI * 2,
                radiusOffset: 0,
                animPhase: Math.random() * Math.PI * 2,
                animFreq: Math.random() * 0.5 + 0.5,
            });
        }
    }

    update(time: number, stage: Stage, progress: number) {
        let amplitude = this.radius * 0.2;
        let speed = 0.5;

        if (stage === 'superposition') {
            amplitude *= 1.5;
            speed *= 1.2;
        }
        if (stage === 'collapse') amplitude *= (1 - progress);

        this.points.forEach(p => {
            p.radiusOffset = Math.sin(time * speed * p.animFreq + p.animPhase) * amplitude;
        });
    }

    draw(ctx: CanvasRenderingContext2D, stage: Stage, progress: number) {
        ctx.save();
        ctx.translate(this.x, this.y);

        let scale = 1;
        if (stage === 'initializing') scale = progress;
        if (stage === 'collapse') scale = 1 - progress;
        ctx.scale(scale, scale);

        ctx.shadowColor = 'rgba(56, 189, 248, 0.5)';
        ctx.shadowBlur = 50;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;

        const gradient = ctx.createRadialGradient(0, 0, this.radius * 0.5, 0, 0, this.radius);
        gradient.addColorStop(0, 'rgba(56, 189, 248, 0.8)');
        gradient.addColorStop(1, 'rgba(124, 58, 237, 0.8)');
        ctx.fillStyle = gradient;

        ctx.beginPath();
        const pointsCoords = this.points.map(p => {
            const r = this.radius + p.radiusOffset;
            return {
                x: Math.cos(p.angle) * r,
                y: Math.sin(p.angle) * r
            };
        });

        ctx.moveTo((pointsCoords[0].x + pointsCoords[this.numPoints - 1].x) / 2, (pointsCoords[0].y + pointsCoords[this.numPoints - 1].y) / 2);
        for (let i = 0; i < this.numPoints; i++) {
            const p1 = pointsCoords[i];
            const p2 = pointsCoords[(i + 1) % this.numPoints];
            const midX = (p1.x + p2.x) / 2;
            const midY = (p1.y + p2.y) / 2;
            ctx.quadraticCurveTo(p1.x, p1.y, midX, midY);
        }
        ctx.closePath();
        ctx.fill();
        
        ctx.restore();
    }
}


// --- COMPONENT ---

const AIRatingAdjustmentModal: React.FC<AIRatingAdjustmentModalProps> = ({
  initialRating, setAiRating, onComplete, tasks, notes, focusSessionHistory, xp
}) => {
    const [stage, setStage] = useState<Stage>('initializing');
    const [adjustmentData, setAdjustmentData] = useState<{ adjustment: number, reason: string } | null>(null);
    const [finalRating, setFinalRating] = useState<number | null>(null);
    const [isTransitioningOut, setIsTransitioningOut] = useState(false);
    
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const animationFrameId = useRef<number | null>(null);

    useEffect(() => {
        const fetchAdjustment = async () => {
            try {
                const focusTime = Math.round(focusSessionHistory.reduce((acc, s) => acc + (s.endTime - s.startTime), 0) / 60000);
                const result = await getAIRatingAdjustment(xp, tasks, focusTime, notes.length);
                setAdjustmentData(result);
            } catch (error) {
                console.error("AI Rating Adjustment failed:", error);
                setAdjustmentData({ adjustment: 0, reason: "SYSTEM CHECK FAILED. RATING NOMINAL." });
            }
        };
        fetchAdjustment();
    }, [xp, tasks, notes, focusSessionHistory]);
    
    useEffect(() => {
        const timers: number[] = [];
        if (stage === 'initializing') {
            timers.push(window.setTimeout(() => setStage('weaving'), 2500));
        }
        if (stage === 'weaving') {
            timers.push(window.setTimeout(() => setStage('superposition'), 3500));
        }
        if (stage === 'superposition' && adjustmentData) {
            timers.push(window.setTimeout(() => setStage('collapse'), 3500));
        }
        if (stage === 'collapse' && adjustmentData) {
            timers.push(window.setTimeout(() => {
                const newFinalRating = initialRating + (adjustmentData.adjustment || 0);
                setFinalRating(newFinalRating);
                setAiRating(Math.max(1000, newFinalRating));
                setStage('revealed');
            }, 2500));
        }
        return () => timers.forEach(clearTimeout);
    }, [stage, adjustmentData, initialRating, setAiRating]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let blob: Blob | null = null;
        let startTime = performance.now();
        let stageStartTime = performance.now();
        let lastStage = stage;
        
        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            blob = new Blob(canvas.width, canvas.height);
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);


        const draw = (currentTime: number) => {
            if (!blob) return;

            if (stage !== lastStage) {
                stageStartTime = currentTime;
                lastStage = stage;
            }
            const time = (currentTime - startTime) / 1000;
            const stageTime = (currentTime - stageStartTime);

            let progress = 0;
            if (stage === 'initializing') progress = Math.min(stageTime / 2500, 1);
            if (stage === 'collapse') progress = Math.min(stageTime / 2500, 1);
            
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            blob.update(time, stage, progress);
            blob.draw(ctx, stage, progress);
            
            if (stage === 'collapse') {
                ctx.fillStyle = `rgba(2, 6, 23, ${progress * 0.9})`;
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            }
            
            if(stage !== 'revealed') {
                animationFrameId.current = requestAnimationFrame(draw);
            } else {
                 ctx.fillStyle = '#020617';
                 ctx.fillRect(0, 0, canvas.width, canvas.height);
            }
        };

        draw(performance.now());

        return () => {
            if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, [stage]);
    
    const stageText: Record<Stage, string> = {
        initializing: 'INITIATING QUANTUM CALIBRATION...',
        weaving: 'WEAVING PRODUCTIVITY SIGNATURE...',
        superposition: 'ANALYZING PROBABILITY WAVEFORM...',
        collapse: 'COLLAPSING WAVEFUNCTION...',
        revealed: ''
    };

    const handleProceed = () => setIsTransitioningOut(true);
    
    const handleAnimationEnd = (e: React.AnimationEvent<HTMLDivElement>) => {
        if (e.animationName.includes('fade-out') || e.animationName.includes('zoom-in')) {
            onComplete();
        }
    };
    
    return (
        <div 
            onAnimationEnd={handleAnimationEnd}
            className={`fixed inset-0 z-[100] flex flex-col items-center justify-center p-8 text-white ai-calibration-overlay ${
                isTransitioningOut ? 'ai-calibration-container-transition-out' : ''
            }`}
        >
            <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full" />
            
            {stage !== 'revealed' && (
                <div className="ai-calibration-text-overlay font-mono text-cyan-300">
                    <p>{stageText[stage]}</p>
                </div>
            )}
            
            <div className={`text-center transition-opacity duration-1000 ${
                stage === 'revealed' ? 'opacity-100' : 'opacity-0 pointer-events-none'
            } ${isTransitioningOut ? 'ai-calibration-content-transition-out' : ''}`}>
                {adjustmentData && finalRating !== null && (
                    <div className="ai-calibration-reveal-content">
                        <p className="text-lg text-cyan-400 font-mono">{adjustmentData.reason}</p>
                        <h1 className="text-8xl font-bold my-4">{finalRating.toLocaleString()}</h1>
                        <p className="text-xl text-slate-400">NEW AI RATING</p>
                        <button
                            onClick={handleProceed}
                            className="mt-8 px-8 py-3 text-lg bg-slate-800/50 border-2 border-slate-700 rounded-md backdrop-blur-sm hover:bg-slate-700/50 hover:border-slate-600 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                        >
                            PROCEED
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AIRatingAdjustmentModal;
