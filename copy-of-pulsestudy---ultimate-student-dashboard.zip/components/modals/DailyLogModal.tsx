import React, { useState } from 'react';
import type { DailyLog } from '../../types';

interface DailyLogModalProps {
  dailyLogs: DailyLog[];
  setDailyLogs: React.Dispatch<React.SetStateAction<DailyLog[]>>;
  onClose: () => void;
}

const moods: { mood: DailyLog['mood']; emoji: string }[] = [
    { mood: 'awful', emoji: '😞' },
    { mood: 'bad', emoji: '😕' },
    { mood: 'okay', emoji: '😐' },
    { mood: 'good', emoji: '😊' },
    { mood: 'great', emoji: '😁' },
];

export default function DailyLogModal({ dailyLogs, setDailyLogs, onClose }: DailyLogModalProps) {
    const todayStr = new Date().toISOString().split('T')[0];
    const todayLog = dailyLogs.find(log => log.date === todayStr);

    const [sleepHours, setSleepHours] = useState(todayLog?.sleepHours || 8);
    const [mood, setMood] = useState<DailyLog['mood'] | null>(todayLog?.mood || null);

    const handleSave = () => {
        if (!mood) return;
        const newLog: DailyLog = {
            id: todayLog?.id || Date.now().toString(),
            date: todayStr,
            sleepHours,
            mood,
        };
        setDailyLogs(prev => {
            const otherLogs = prev.filter(log => log.date !== todayStr);
            return [newLog, ...otherLogs].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        });
        onClose();
    };

    return (
        <div className="bg-slate-200 dark:bg-slate-800 backdrop-blur-xl border border-slate-300 dark:border-slate-700 rounded-2xl p-6 shadow-2xl animate-fade-in-up w-full max-w-md">
            <div className="flex items-start justify-between">
                <h4 className="font-semibold text-lg text-slate-800 dark:text-slate-100">Daily Log for {new Date().toLocaleDateString()}</h4>
                <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 transition">✕</button>
            </div>
            <div className="mt-6 space-y-6">
                <div>
                    <label className="text-sm font-medium text-slate-500 dark:text-slate-400">How many hours did you sleep last night?</label>
                    <div className="flex items-center gap-4 mt-2">
                        <input
                            type="range"
                            min="0" max="12" step="0.5"
                            value={sleepHours}
                            onChange={e => setSleepHours(parseFloat(e.target.value))}
                            className="w-full h-2 bg-slate-300 dark:bg-slate-600 rounded-lg appearance-none cursor-pointer accent-violet-500"
                        />
                        <span className="font-semibold text-lg text-slate-800 dark:text-slate-100 w-16 text-center">{sleepHours} hrs</span>
                    </div>
                </div>
                 <div>
                    <label className="text-sm font-medium text-slate-500 dark:text-slate-400">How are you feeling today?</label>
                    <div className="flex items-center justify-between mt-2">
                        {moods.map(({ mood: m, emoji }) => (
                            <button
                                key={m}
                                onClick={() => setMood(m)}
                                className={`w-12 h-12 text-3xl rounded-full transition-all duration-200 ${mood === m ? 'bg-violet-500/20 ring-2 ring-violet-500 scale-110' : 'bg-black/5 dark:bg-white/10 hover:scale-110'}`}
                            >
                                {emoji}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
            <div className="mt-8 text-right">
                <button
                    onClick={handleSave}
                    disabled={!mood}
                    className="px-5 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105 disabled:opacity-50"
                >
                    Save Log
                </button>
            </div>
        </div>
    );
}
