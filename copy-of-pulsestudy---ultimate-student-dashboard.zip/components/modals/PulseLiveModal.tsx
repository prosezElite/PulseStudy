
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { LiveTranscriptionTurn } from '../../types';
import { GoogleGenAI, LiveServerMessage, Modality, Blob, } from '@google/genai';

// --- AUDIO HELPER FUNCTIONS (as per Gemini API guidelines) ---
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

const blobToBase64 = (blob: globalThis.Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};
// --- END AUDIO HELPER FUNCTIONS ---

type SessionStatus = 'idle' | 'connecting' | 'connected' | 'error';

interface PulseLiveModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const CameraIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 001.553.832l3-2a1 1 0 000-1.664l-3-2z" /></svg>;
const ScreenShareIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M18 3H2a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V5a2 2 0 00-2-2zM4.5 12.5a.5.5 0 11-1 0 .5.5 0 011 0zM17 10H3V5h14v5z" /></svg>;
const SwitchCameraIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" /></svg>;


export default function PulseLiveModal({ isOpen, onClose }: PulseLiveModalProps) {
    const [status, setStatus] = useState<SessionStatus>('idle');
    const [transcription, setTranscription] = useState<LiveTranscriptionTurn[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [isCameraOn, setIsCameraOn] = useState(false);
    const [isScreenSharing, setIsScreenSharing] = useState(false);
    const [isScreenShareSupported, setIsScreenShareSupported] = useState(false);
    const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
    const [currentVideoDeviceId, setCurrentVideoDeviceId] = useState<string | undefined>(undefined);

    const sessionPromise = useRef<Promise<any> | null>(null);
    const audioStreamRef = useRef<MediaStream | null>(null);
    const audioResourcesRef = useRef<any>({});
    
    const nextStartTime = useRef(0);
    const sources = useRef(new Set<AudioBufferSourceNode>());

    const currentInputTranscription = useRef('');
    const currentOutputTranscription = useRef('');
    const transcriptionContainerRef = useRef<HTMLDivElement>(null);

    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const frameIntervalRef = useRef<number | null>(null);
    const visualStreamRef = useRef<MediaStream | null>(null);

    useEffect(() => {
        setIsScreenShareSupported(!!(navigator.mediaDevices && 'getDisplayMedia' in navigator.mediaDevices));
    }, []);

    useEffect(() => {
        if (transcriptionContainerRef.current) {
            transcriptionContainerRef.current.scrollTop = transcriptionContainerRef.current.scrollHeight;
        }
    }, [transcription]);

    const stopVisualStreams = useCallback(() => {
        if (frameIntervalRef.current) {
            clearInterval(frameIntervalRef.current);
            frameIntervalRef.current = null;
        }
        if (visualStreamRef.current) {
            visualStreamRef.current.getTracks().forEach(track => track.stop());
            visualStreamRef.current = null;
        }
        if(videoRef.current) videoRef.current.srcObject = null;
        
        setIsCameraOn(false);
        setIsScreenSharing(false);
    }, []);

    const stopSession = useCallback(() => {
        stopVisualStreams();

        sessionPromise.current?.then(session => session.close()).catch(console.error);
        sessionPromise.current = null;
        
        audioStreamRef.current?.getTracks().forEach(track => track.stop());
        audioStreamRef.current = null;

        const { scriptProcessor, source, inputAudioContext, outputAudioContext } = audioResourcesRef.current;
        if(scriptProcessor) scriptProcessor.disconnect();
        if(source) source.disconnect();
        if(inputAudioContext?.state !== 'closed') inputAudioContext?.close().catch(console.error);
        if(outputAudioContext?.state !== 'closed') outputAudioContext?.close().catch(console.error);
        
        sources.current.forEach(sourceNode => sourceNode.stop());
        sources.current.clear();
        nextStartTime.current = 0;
        
        setStatus('idle');
    }, [stopVisualStreams]);

    const handleStartSession = useCallback(async () => {
        if (status !== 'idle' && status !== 'error') return;

        setError(null);
        setTranscription([]);
        setStatus('connecting');

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            audioStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });

            const devices = await navigator.mediaDevices.enumerateDevices();
            setVideoDevices(devices.filter(d => d.kind === 'videoinput'));

            const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            audioResourcesRef.current.outputAudioContext = outputAudioContext;

            sessionPromise.current = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: () => {
                        if (!audioStreamRef.current) return;
                        setStatus('connected');
                        
                        const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                        const source = inputAudioContext.createMediaStreamSource(audioStreamRef.current);
                        const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
                        
                        scriptProcessor.onaudioprocess = (event) => {
                            const inputData = event.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromise.current?.then((session) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };

                        source.connect(scriptProcessor);
                        scriptProcessor.connect(inputAudioContext.destination);

                        audioResourcesRef.current = { ...audioResourcesRef.current, inputAudioContext, source, scriptProcessor };
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        // Handle transcription
                        if (message.serverContent?.outputTranscription) currentOutputTranscription.current += message.serverContent.outputTranscription.text;
                        if (message.serverContent?.inputTranscription) currentInputTranscription.current += message.serverContent.inputTranscription.text;

                        if (message.serverContent?.turnComplete) {
                            const userText = currentInputTranscription.current.trim();
                            const aiText = currentOutputTranscription.current.trim();
                            if (userText || aiText) {
                               setTranscription(prev => [...prev, { id: Date.now(), user: userText, ai: aiText }]);
                            }
                            currentInputTranscription.current = '';
                            currentOutputTranscription.current = '';
                        }

                        // Handle audio output
                        const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                        const outputCtx = audioResourcesRef.current.outputAudioContext;
                        if (audioData && outputCtx) {
                            nextStartTime.current = Math.max(nextStartTime.current, outputCtx.currentTime);
                            const audioBuffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
                            const source = outputCtx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputCtx.destination);
                            source.addEventListener('ended', () => sources.current.delete(source));
                            source.start(nextStartTime.current);
                            nextStartTime.current += audioBuffer.duration;
                            sources.current.add(source);
                        }
                    },
                    onerror: (e) => {
                        console.error('Session error:', e);
                        setError('A connection error occurred. Please try again.');
                        setStatus('error');
                    },
                    onclose: () => {
                        setStatus('idle');
                    },
                },
                config: {
                    responseModalities: [Modality.AUDIO],
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                },
            });

        } catch (err) {
            console.error('Failed to start session:', err);
            setError('Could not access microphone. Please grant permission and try again.');
            setStatus('error');
        }
    }, [status]);
    
    useEffect(() => {
        if (isOpen) {
            handleStartSession();
        } else {
            stopSession();
        }
        return stopSession;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen]);

    const sendVideoFrame = (source: HTMLVideoElement) => {
        if (!sessionPromise.current || source.paused || source.ended || source.videoWidth === 0) return;
        const canvas = canvasRef.current;
        if (!canvas) return;
        canvas.width = source.videoWidth;
        canvas.height = source.videoHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(source, 0, 0, source.videoWidth, source.videoHeight);
        canvas.toBlob(async (blob) => {
            if (blob) {
                const base64Data = await blobToBase64(blob);
                sessionPromise.current?.then((session) => {
                    session.sendRealtimeInput({ media: { data: base64Data, mimeType: 'image/jpeg' } });
                });
            }
        }, 'image/jpeg', 0.8);
    };

    const startCamera = async (deviceId?: string) => {
        stopVisualStreams();
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: deviceId ? { deviceId: { exact: deviceId } } : true });
            visualStreamRef.current = stream;
            if (videoRef.current) videoRef.current.srcObject = stream;
            
            frameIntervalRef.current = window.setInterval(() => {
                if (videoRef.current) sendVideoFrame(videoRef.current);
            }, 1000);

            const currentId = stream.getVideoTracks()[0].getSettings().deviceId;
            setCurrentVideoDeviceId(currentId);
            setIsCameraOn(true);
        } catch (err) {
            setError("Camera access denied.");
            stopVisualStreams();
        }
    };
    
    const handleToggleCamera = () => isCameraOn ? stopVisualStreams() : startCamera();
    const handleSwitchCamera = () => {
        if (!isCameraOn || videoDevices.length <= 1 || !currentVideoDeviceId) return;
        const currentIndex = videoDevices.findIndex(d => d.deviceId === currentVideoDeviceId);
        const nextDeviceId = videoDevices[(currentIndex + 1) % videoDevices.length].deviceId;
        startCamera(nextDeviceId);
    };
    const handleToggleScreenShare = async () => {
        if(isScreenSharing) {
            stopVisualStreams();
        } else {
            try {
                const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
                visualStreamRef.current = stream;
                if (videoRef.current) videoRef.current.srcObject = stream;

                stream.getVideoTracks()[0].onended = () => stopVisualStreams();

                frameIntervalRef.current = window.setInterval(() => {
                    if (videoRef.current) sendVideoFrame(videoRef.current);
                }, 1000);
                setIsScreenSharing(true);
            } catch (err) {
                 console.error("Screen share error:", err);
            }
        }
    };

    const getStatusText = () => {
        if (error) return error;
        if (isCameraOn) return 'Analyzing camera feed...';
        if (isScreenSharing) return 'Analyzing screen presentation...';
        switch (status) {
            case 'idle': return 'Click the mic to start a live session.';
            case 'connecting': return 'Connecting...';
            case 'connected': return 'Listening...';
            case 'error': return 'An error occurred. Please try again.';
        }
    };

    return (
        <div className={`fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-white flex flex-col items-center justify-between p-8 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            <video ref={videoRef} autoPlay playsInline muted className={`absolute top-24 right-8 w-48 rounded-lg shadow-2xl transition-opacity duration-300 transform scale-x-[-1] ${isCameraOn || isScreenSharing ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}/>
            <canvas ref={canvasRef} className="hidden"></canvas>
            
            <div className="w-full flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full transition-colors ${status === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-slate-500'}`}></div>
                    <span className="font-semibold tracking-wider">PULSE LIVE</span>
                </div>
                <button onClick={onClose} className="p-2 rounded-full bg-black/10 dark:bg-white/10 hover:bg-black/20 dark:hover:bg-white/20 transition-colors" aria-label="Close Live Session">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>
            
            <div ref={transcriptionContainerRef} className="w-full max-w-3xl flex-1 overflow-y-auto my-8 space-y-4 scroll-smooth">
                {transcription.map(turn => (
                    <div key={turn.id} className="animate-fade-in-up">
                        {turn.user && <p className="text-right text-lg text-slate-600 dark:text-slate-300"> <span className="font-semibold text-slate-900 dark:text-white">You:</span> {turn.user}</p>}
                        {turn.ai && <p className="text-left text-lg text-cyan-700 dark:text-cyan-300 mt-2"><span className="font-semibold text-slate-900 dark:text-white">Pulse:</span> {turn.ai}</p>}
                    </div>
                ))}
            </div>

            <div className="flex flex-col items-center">
                 <div className="flex items-center gap-8">
                    <div className="flex items-center gap-2">
                        <button onClick={handleToggleCamera} disabled={status !== 'connected'} className={`p-5 rounded-full transition-colors disabled:opacity-50 ${isCameraOn ? 'bg-cyan-500/30' : 'bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20'}`} title={isCameraOn ? 'Stop Camera Analysis' : 'Analyse with Camera'}>
                            <CameraIcon />
                        </button>
                        {isCameraOn && videoDevices.length > 1 && (
                            <button onClick={handleSwitchCamera} className="p-3 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 transition-colors animate-fade-in" title="Switch Camera">
                                <SwitchCameraIcon />
                            </button>
                        )}
                    </div>
                    
                    <div className="relative w-24 h-24 flex items-center justify-center">
                        {status === 'connected' && (<div className="absolute w-24 h-24 rounded-full bg-cyan-500 pulse-live-ring"></div>)}
                        <button onClick={status === 'connected' ? stopSession : handleStartSession} disabled={status === 'connecting'} className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 z-10 shadow-lg text-white ${status === 'connected' ? 'bg-cyan-500 hover:bg-cyan-400' : 'bg-slate-500 dark:bg-slate-700 hover:bg-slate-600 dark:hover:bg-slate-600'}`} aria-label={status === 'connected' ? 'Stop Session' : 'Start Session'}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
                            </svg>
                        </button>
                    </div>

                    <button onClick={handleToggleScreenShare} disabled={status !== 'connected' || !isScreenShareSupported} className={`p-5 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${isScreenSharing ? 'bg-cyan-500/30' : 'bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20'}`} title={!isScreenShareSupported ? "Screen sharing not supported by browser" : (isScreenSharing ? 'Stop Presenting' : 'Present Screen')}>
                        <ScreenShareIcon />
                    </button>
                </div>
                <p className="mt-6 text-slate-500 dark:text-slate-400 text-center h-5">{getStatusText()}</p>
            </div>
        </div>
    );
}
