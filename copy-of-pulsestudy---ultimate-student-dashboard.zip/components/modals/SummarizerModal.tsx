import React, { useState } from 'react';
import { getAISummary } from '../../services/geminiService';

interface SummarizerModalProps {
  onClose: () => void;
}

type InputMode = 'text' | 'image';

const SummarizerModal: React.FC<SummarizerModalProps> = ({ onClose }) => {
    const [inputMode, setInputMode] = useState<InputMode>('text');
    const [inputText, setInputText] = useState('');
    const [imageSrc, setImageSrc] = useState<string | null>(null);
    const [summary, setSummary] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSummarize = async () => {
        setIsLoading(true);
        setError(null);
        setSummary('');
        try {
            let result;
            if (inputMode === 'text' && inputText.trim()) {
                result = await getAISummary({ text: inputText });
            } else if (inputMode === 'image' && imageSrc) {
                result = await getAISummary({ image: imageSrc });
            } else {
                setError("Please provide some content to summarize.");
                setIsLoading(false);
                return;
            }
            setSummary(result);
        } catch (e: any) {
            setError(e.message || "Failed to generate summary.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setImageSrc(event.target?.result as string);
                setSummary(''); // Clear previous summary
                setError(null);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleClearInput = () => {
        setInputText('');
        setImageSrc(null);
        setSummary('');
        setError(null);
        // Reset file input
        const fileInput = document.getElementById('image-upload') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
    };

    const canSummarize = (inputMode === 'text' && inputText.trim().length > 0) || (inputMode === 'image' && imageSrc);

    return (
         <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
            <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500" viewBox="0 0 20 20" fill="currentColor"><path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v1h-2V4H7v1H5V4zM5 7h10v9a2 2 0 01-2 2H7a2 2 0 01-2-2V7z" /><path d="M7 9a1 1 0 000 2h6a1 1 0 100-2H7zM7 13a1 1 0 000 2h4a1 1 0 100-2H7z" /></svg>
                    AI Summarizer
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </button>
            </header>

            <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
                {/* Input Panel */}
                <div className="w-full md:w-1/2 p-4 flex flex-col border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-1 bg-black/5 dark:bg-white/5 p-1 rounded-md">
                            <button onClick={() => setInputMode('text')} className={`w-full px-2 py-1 text-sm font-semibold rounded transition-colors ${inputMode === 'text' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-600 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/10'}`}>
                                Text
                            </button>
                            <button onClick={() => setInputMode('image')} className={`w-full px-2 py-1 text-sm font-semibold rounded transition-colors ${inputMode === 'image' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-600 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/10'}`}>
                                Image
                            </button>
                        </div>
                         <button onClick={handleClearInput} className="text-sm text-slate-500 hover:text-red-500 transition-colors">Clear</button>
                    </div>

                    {inputMode === 'text' ? (
                        <textarea
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            placeholder="Paste or type text to summarize..."
                            className="w-full flex-1 p-3 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-violet-500 focus:outline-none transition text-slate-800 dark:text-slate-100 resize-none"
                        />
                    ) : (
                        <div className="flex-1 flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-md text-center bg-black/5 dark:bg-white/5">
                            {imageSrc ? (
                                <img src={imageSrc} alt="Upload preview" className="max-h-64 mx-auto rounded-md object-contain" />
                            ) : (
                                <p className="text-slate-500 dark:text-slate-400">Upload an image containing text.</p>
                            )}
                            <input type="file" id="image-upload" accept="image/*" onChange={handleImageUpload} className="mt-4 text-sm text-slate-600 dark:text-slate-300 file:mr-4 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-violet-500/20 file:text-violet-700 dark:file:bg-violet-500/30 dark:file:text-violet-300 hover:file:bg-violet-500/40" />
                        </div>
                    )}
                     <button
                        onClick={handleSummarize}
                        disabled={!canSummarize || isLoading}
                        className="mt-4 w-full px-5 py-3 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? 'Summarizing...' : 'Summarize'}
                    </button>
                </div>

                {/* Output Panel */}
                <div className="w-full md:w-1/2 p-4 flex flex-col overflow-y-auto">
                    <h5 className="font-semibold text-slate-700 dark:text-slate-200 flex-shrink-0">Summary:</h5>
                     <div className="flex-1 mt-2 overflow-y-auto rounded-md bg-white dark:bg-slate-800 p-3 border border-slate-200 dark:border-slate-700">
                        {isLoading && <p className="text-slate-500 dark:text-slate-400 animate-pulse">AI is generating your summary...</p>}
                        {error && <p className="text-red-500">{error}</p>}
                        {summary && <p className="text-slate-600 dark:text-slate-300 whitespace-pre-wrap">{summary}</p>}
                        {!isLoading && !error && !summary && <p className="text-slate-400 dark:text-slate-500">Your summary will appear here.</p>}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default SummarizerModal;
