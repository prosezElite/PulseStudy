import React, { useEffect, useRef } from 'react';

// Globe SVG Path Data (simplified)
const GLOBE_PATH = "M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zM4 12c0-1.846.634-3.543 1.688-4.897l1.02 1.02C5.978 8.875 5.5 10.33 5.5 12s.478 3.125 1.208 3.877l-1.02 1.02C4.634 15.543 4 13.846 4 12zm14.312-4.897C19.366 8.457 20 10.154 20 12c0 1.846-.634 3.543-1.688 4.897l-1.02-1.02c.73-.752 1.208-2.207 1.208-3.877s-.478-3.125-1.208-3.877l1.02-1.02z";

const mockPoints = Array.from({ length: 30 }, () => ({
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 5,
}));

export default function GlobalPulseMeshModal({ onClose }: { onClose: () => void }) {

    return (
        <div className="fixed inset-0 z-[60] bg-slate-50 dark:bg-[#0A0014] flex flex-col items-center justify-center animate-fade-in text-slate-800 dark:text-white overflow-hidden">
            <style>{`
                @keyframes pulse-point {
                    0%, 100% { transform: scale(0.5); opacity: 0.5; }
                    50% { transform: scale(1.2); opacity: 1; }
                }
                @keyframes travel-line {
                    from { stroke-dashoffset: 200; }
                    to { stroke-dashoffset: 0; }
                }
            `}</style>
            
            <header className="absolute top-0 left-0 right-0 flex-shrink-0 h-16 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg flex items-center gap-3">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500 dark:text-violet-400" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM4.332 8.027a6.002 6.002 0 019.336 0l.243.243a1 1 0 01-1.415 1.415L12 9.272a4 4 0 00-4.002 0l-.41.41a1 1 0 01-1.415-1.415l.159-.159zM10 15a4 4 0 004-4H6a4 4 0 004 4z" clipRule="evenodd" /></svg>
                   Global Pulse Mesh
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300" aria-label="Close">✕</button>
            </header>

            <div className="relative w-full h-full flex items-center justify-center">
                 <svg viewBox="0 0 24 24" className="absolute w-[80vmin] h-[80vmin] opacity-10 dark:opacity-20">
                    <path d={GLOBE_PATH} stroke="currentColor" strokeWidth="0.2" fill="none" />
                </svg>

                <div className="w-[80vmin] h-[80vmin] relative">
                    {mockPoints.map((p, i) => (
                        <div
                            key={i}
                            className="absolute w-1.5 h-1.5 bg-cyan-400 rounded-full"
                            style={{
                                left: `${p.x}%`,
                                top: `${p.y}%`,
                                animation: `pulse-point 3s ease-in-out infinite`,
                                animationDelay: `${p.delay}s`,
                                boxShadow: '0 0 10px #22d3ee, 0 0 20px #22d3ee'
                            }}
                        />
                    ))}
                    <svg className="w-full h-full absolute inset-0 overflow-visible opacity-50 dark:opacity-30">
                        {mockPoints.map((p1, i) => {
                            const p2 = mockPoints[(i + 5) % mockPoints.length];
                            return (
                                <line
                                    key={i}
                                    x1={`${p1.x}%`} y1={`${p1.y}%`}
                                    x2={`${p2.x}%`} y2={`${p2.y}%`}
                                    stroke="url(#line-gradient)"
                                    strokeWidth="1"
                                    strokeDasharray="100 100"
                                    style={{ animation: `travel-line ${2 + p1.delay}s linear infinite`, animationDelay: `${p1.delay}s` }}
                                />
                            );
                        })}
                        <defs>
                            <linearGradient id="line-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" stopColor="rgba(167, 139, 250, 0)" />
                                <stop offset="100%" stopColor="rgba(167, 139, 250, 1)" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
            </div>
             <p className="absolute bottom-10 text-slate-500 dark:text-slate-400 text-sm">Visualizing collective focus across the globe...</p>
        </div>
    );
}