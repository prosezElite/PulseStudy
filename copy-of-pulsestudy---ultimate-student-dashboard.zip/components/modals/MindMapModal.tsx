import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { MindMap, MindMapNode } from '../../types';
import { generateMindMapSuggestions } from '../../services/geminiService';

interface MindMapModalProps {
  mindMap: MindMap;
  onSave: (mindMap: MindMap) => void;
  onClose: () => void;
}

const NODE_WIDTH = 150;
const NODE_HEIGHT = 50;

export default function MindMapModal({ mindMap, onSave, onClose }: MindMapModalProps) {
    const [title, setTitle] = useState(mindMap.title);
    const [nodes, setNodes] = useState<MindMapNode[]>(mindMap.nodes);
    const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
    const [editingNodeId, setEditingNodeId] = useState<string | null>(null);

    const [suggestions, setSuggestions] = useState<string[]>([]);
    const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

    const svgRef = useRef<SVGSVGElement>(null);
    const dragInfo = useRef<{ nodeId: string; offsetX: number; offsetY: number } | null>(null);

    // Add initial node if map is empty
    useEffect(() => {
        if (nodes.length === 0 && svgRef.current) {
            const { width, height } = svgRef.current.getBoundingClientRect();
            const initialNode: MindMapNode = {
                id: Date.now().toString(),
                text: 'Central Idea',
                parentId: null,
                x: width / 2 - NODE_WIDTH / 2,
                y: height / 2 - NODE_HEIGHT / 2,
            };
            setNodes([initialNode]);
            setSelectedNodeId(initialNode.id);
            setEditingNodeId(initialNode.id);
        }
    }, [nodes.length]);

    const handleUpdateNodeText = (nodeId: string, newText: string) => {
        setNodes(nds => nds.map(n => (n.id === nodeId ? { ...n, text: newText } : n)));
    };

    const handleAddNode = (parentId: string | null, text = 'New Idea') => {
        const parentNode = nodes.find(n => n.id === parentId);
        const x = parentNode ? parentNode.x + NODE_WIDTH + 50 : 50;
        const y = parentNode ? parentNode.y : 50;
        const newNode: MindMapNode = { id: Date.now().toString(), text, parentId, x, y };
        setNodes(nds => [...nds, newNode]);
        setSelectedNodeId(newNode.id);
    };

    const handleDeleteNode = (nodeId: string) => {
        if (!nodeId) return;
        setNodes(nds => {
            const childrenIds = nds.filter(n => n.parentId === nodeId).map(n => n.id);
            return nds.filter(n => n.id !== nodeId && !childrenIds.includes(n.id));
        });
        setSelectedNodeId(null);
    };

    const handleGetSuggestions = async () => {
        const selectedNode = nodes.find(n => n.id === selectedNodeId);
        if (!selectedNode) return;
        setIsLoadingSuggestions(true);
        setSuggestions([]);
        try {
            const result = await generateMindMapSuggestions(selectedNode.text, nodes.map(n => n.text));
            setSuggestions(result);
        } catch (error) {
            console.error(error);
        } finally {
            setIsLoadingSuggestions(false);
        }
    };
    
    const handleAddSuggestionAsNode = (suggestion: string) => {
        handleAddNode(selectedNodeId, suggestion);
        setSuggestions([]);
    };
    
    const handleKeyDown = useCallback((e: KeyboardEvent) => {
        if ((e.key === 'Delete' || e.key === 'Backspace') && selectedNodeId && !editingNodeId) {
            handleDeleteNode(selectedNodeId);
        }
    }, [selectedNodeId, editingNodeId]);
    
    useEffect(() => {
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [handleKeyDown]);
    
    const startDrag = (e: React.MouseEvent, nodeId: string) => {
        const node = nodes.find(n => n.id === nodeId);
        if (!node || !svgRef.current) return;
        const pt = svgRef.current.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        const svgP = pt.matrixTransform(svgRef.current.getScreenCTM()?.inverse());
        dragInfo.current = { nodeId, offsetX: svgP.x - node.x, offsetY: svgP.y - node.y };
        e.stopPropagation();
    };

    const drag = (e: React.MouseEvent) => {
        if (!dragInfo.current || !svgRef.current) return;
        const pt = svgRef.current.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        const svgP = pt.matrixTransform(svgRef.current.getScreenCTM()?.inverse());
        const { nodeId, offsetX, offsetY } = dragInfo.current;
        setNodes(nds =>
            nds.map(n =>
                n.id === nodeId ? { ...n, x: svgP.x - offsetX, y: svgP.y - offsetY } : n
            )
        );
    };
    
    const endDrag = () => dragInfo.current = null;
    
    const handleSave = () => onSave({ ...mindMap, title, nodes });

    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
             <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <input
                    type="text"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    className="bg-transparent font-semibold text-lg text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-violet-500 rounded px-2 py-1"
                />
                <div className="flex items-center gap-3">
                    <button onClick={handleSave} className="px-4 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105">Save</button>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">✕</button>
                </div>
            </header>
            <main className="flex-1 flex overflow-hidden">
                <div className="w-64 bg-white dark:bg-slate-800 p-4 border-r border-slate-200 dark:border-slate-700 overflow-y-auto">
                    <h3 className="font-semibold text-slate-700 dark:text-slate-200">Controls</h3>
                    <ul className="text-xs text-slate-500 dark:text-slate-400 mt-2 space-y-1.5 list-disc list-inside">
                        <li><b>Double-click canvas:</b> Add new idea.</li>
                        <li><b>Double-click node:</b> Edit text.</li>
                        <li><b>Select node + Delete key:</b> Remove.</li>
                        <li><b>Click + Drag node:</b> Reposition.</li>
                    </ul>

                     <button
                        onClick={() => handleAddNode(selectedNodeId)}
                        disabled={!selectedNodeId}
                        className="w-full mt-4 px-3 py-2 text-sm rounded-md bg-black/5 dark:bg-white/5 text-slate-800 dark:text-slate-100 hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-50"
                     >
                        Add Child Node
                     </button>
                    
                    <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                        <button
                            onClick={handleGetSuggestions}
                            disabled={!selectedNodeId || isLoadingSuggestions}
                            className="w-full px-3 py-2 text-sm rounded-md bg-cyan-500/20 dark:bg-cyan-500/30 text-cyan-800 dark:text-cyan-300 hover:bg-cyan-500/30 dark:hover:bg-cyan-500/40 disabled:opacity-50 disabled:cursor-wait font-semibold"
                        >
                            {isLoadingSuggestions ? 'Thinking...' : 'AI Suggestions ✨'}
                        </button>
                        {suggestions.length > 0 && (
                            <div className="mt-2 space-y-1">
                                {suggestions.map(s => (
                                    <button
                                        key={s}
                                        onClick={() => handleAddSuggestionAsNode(s)}
                                        className="w-full text-left text-xs p-2 rounded bg-black/5 dark:bg-white/5 text-slate-800 dark:text-slate-100 hover:bg-black/10 dark:hover:bg-white/10"
                                    >
                                        + {s}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
                <div className="flex-1 bg-slate-200 dark:bg-slate-900" onMouseMove={drag} onMouseUp={endDrag} onMouseLeave={endDrag}>
                     <svg
                        ref={svgRef}
                        className="w-full h-full cursor-grab active:cursor-grabbing"
                        onDoubleClick={() => handleAddNode(null)}
                     >
                        <defs>
                            <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                                <path d="M 0 0 L 10 5 L 0 10 z" className="fill-slate-400 dark:fill-slate-500" />
                            </marker>
                        </defs>
                        {nodes.map(node => {
                            const parent = nodes.find(p => p.id === node.parentId);
                            if (!parent) return null;
                            const startX = parent.x + NODE_WIDTH / 2;
                            const startY = parent.y + NODE_HEIGHT / 2;
                            const endX = node.x + NODE_WIDTH / 2;
                            const endY = node.y + NODE_HEIGHT / 2;
                            return (
                                <path
                                    key={`${parent.id}-${node.id}`}
                                    d={`M ${startX} ${startY} C ${startX + 50} ${startY}, ${endX - 50} ${endY}, ${endX} ${endY}`}
                                    className="stroke-slate-400 dark:stroke-slate-500"
                                    strokeWidth="2"
                                    fill="none"
                                />
                            );
                        })}
                        {nodes.map(node => (
                            <g key={node.id} transform={`translate(${node.x}, ${node.y})`} onMouseDown={e => startDrag(e, node.id)} className="cursor-pointer">
                                <foreignObject width={NODE_WIDTH} height={NODE_HEIGHT}>
                                    <div
                                        onClick={() => setSelectedNodeId(node.id)}
                                        onDoubleClick={(e) => { e.stopPropagation(); setEditingNodeId(node.id); }}
                                        className={`w-full h-full flex items-center justify-center p-2 rounded-lg border-2 text-center text-sm font-medium text-slate-800 dark:text-slate-100
                                            ${selectedNodeId === node.id ? 'border-violet-500 bg-violet-500/10 dark:bg-violet-500/20' : 'border-slate-400 dark:border-slate-500 bg-white dark:bg-slate-700'}`}
                                    >
                                        {editingNodeId === node.id ? (
                                            <textarea
                                                value={node.text}
                                                onChange={e => handleUpdateNodeText(node.id, e.target.value)}
                                                onBlur={() => setEditingNodeId(null)}
                                                onKeyDown={e => e.key === 'Enter' && setEditingNodeId(null)}
                                                className="w-full h-full bg-transparent resize-none text-center outline-none text-slate-800 dark:text-slate-100"
                                                autoFocus
                                            />
                                        ) : (
                                            <span>{node.text}</span>
                                        )}
                                    </div>
                                </foreignObject>
                            </g>
                        ))}
                    </svg>
                </div>
            </main>
        </div>
    );
}
