import React, { useState, useEffect, useMemo } from 'react';
import type { Note, Quiz, Question, QuizMode } from '../../types';
import { generateQuiz } from '../../services/geminiService';

interface QuizModalProps {
  note: Note;
  onClose: () => void;
}

export default function QuizModal({ note, onClose }: QuizModalProps) {
    const [quiz, setQuiz] = useState<Quiz | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
    const [isAnswered, setIsAnswered] = useState(false);
    const [score, setScore] = useState(0);
    const [showResults, setShowResults] = useState(false);
    const [quizMode, setQuizMode] = useState<QuizMode>('standard');
    const [view, setView] = useState<'setup' | 'quiz' | 'results'>('setup');

    const fetchQuiz = async () => {
        setIsLoading(true);
        setError(null);
        setView('quiz');
        try {
            const generatedQuiz = await generateQuiz(note, quizMode);
            setQuiz(generatedQuiz);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setIsLoading(false);
        }
    };
    
    const currentQuestion = useMemo(() => quiz?.questions[currentQuestionIndex], [quiz, currentQuestionIndex]);

    const handleAnswerSubmit = () => {
        if (!selectedAnswer || !currentQuestion) return;
        if (selectedAnswer === currentQuestion.answer) {
            setScore(s => s + 1);
        }
        setIsAnswered(true);
    };

    const handleNextQuestion = () => {
        if (currentQuestionIndex < (quiz?.questions.length || 0) - 1) {
            setCurrentQuestionIndex(i => i + 1);
            setSelectedAnswer(null);
            setIsAnswered(false);
        } else {
            setView('results');
        }
    };
    
    const getButtonClass = (option: string) => {
        if (!isAnswered) {
            return `bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 text-slate-800 dark:text-slate-100 ${selectedAnswer === option ? 'bg-violet-500/30 border-violet-500' : 'border-transparent'}`;
        }
        if (option === currentQuestion?.answer) {
            return 'bg-green-500/30 dark:bg-green-500/20 border-green-500 text-green-800 dark:text-green-300';
        }
        if (option === selectedAnswer && option !== currentQuestion?.answer) {
            return 'bg-red-500/30 dark:bg-red-500/20 border-red-500 text-red-800 dark:text-red-300';
        }
        return 'bg-black/5 dark:bg-white/5 border-transparent opacity-60 text-slate-800 dark:text-slate-100';
    };
    
    const renderContent = () => {
        if (view === 'setup') return (
            <div className="p-6 text-center">
                 <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">Prepare for a Quiz!</h3>
                 <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">The AI will generate questions based on your note: <span className="font-semibold text-slate-600 dark:text-slate-300">"{note.title}"</span>.</p>
                 <div className="my-6">
                    <label className="text-sm font-semibold text-slate-500 dark:text-slate-400">Choose your quiz mode:</label>
                    <div className="mt-2 flex items-center justify-center gap-2 p-1 rounded-full bg-black/5 dark:bg-white/5">
                        <button onClick={() => setQuizMode('standard')} className={`w-full px-3 py-1 rounded-full text-sm font-semibold transition-colors ${quizMode === 'standard' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-500 dark:text-slate-400'}`}>
                            Standard
                        </button>
                         <button onClick={() => setQuizMode('stress-test')} className={`w-full px-3 py-1 rounded-full text-sm font-semibold transition-colors ${quizMode === 'stress-test' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-500 dark:text-slate-400'}`}>
                            Stress-Test
                        </button>
                    </div>
                 </div>
                 <button onClick={fetchQuiz} className="w-full px-5 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105">
                    Start Quiz
                </button>
            </div>
        );
        if (isLoading) return <div className="text-center p-8 text-slate-800 dark:text-slate-100">Generating your quiz... <div className="w-6 h-6 mx-auto mt-4 border-2 border-slate-400 dark:border-slate-500 border-t-slate-800 dark:border-t-slate-100 rounded-full animate-spin"></div></div>;
        if (error) return <div className="text-center p-8 text-red-500">{error}</div>;
        if (view === 'results') return (
            <div className="text-center p-8 animate-fade-in-up">
                <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Quiz Complete!</h3>
                <p className="text-slate-500 dark:text-slate-400 mt-2">You scored</p>
                <p className="text-6xl font-extrabold my-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-violet-500">{score} / {quiz?.questions.length}</p>
                <button onClick={onClose} className="mt-6 px-5 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105">Close</button>
            </div>
        );
        if (quiz && currentQuestion) return (
             <div className="p-6 animate-fade-in">
                <p className="text-sm text-slate-500 dark:text-slate-400">Question {currentQuestionIndex + 1} of {quiz.questions.length}</p>
                <h4 className="font-semibold text-lg my-2 text-slate-800 dark:text-slate-100">{currentQuestion.questionText}</h4>
                <div className="space-y-3 mt-4">
                    {currentQuestion.type === 'multiple-choice' && currentQuestion.options?.map(option => (
                        <button key={option} onClick={() => !isAnswered && setSelectedAnswer(option)} disabled={isAnswered} className={`w-full p-3 text-left rounded-lg border-2 transition-all ${getButtonClass(option)}`}>
                            {option}
                        </button>
                    ))}
                    {currentQuestion.type === 'true-false' && ['True', 'False'].map(option => (
                        <button key={option} onClick={() => !isAnswered && setSelectedAnswer(option)} disabled={isAnswered} className={`w-full p-3 text-left rounded-lg border-2 transition-all ${getButtonClass(option)}`}>
                            {option}
                        </button>
                    ))}
                </div>
                {isAnswered && (
                    <div className="mt-4 p-3 rounded-lg bg-yellow-500/20 dark:bg-yellow-500/20 text-yellow-800 dark:text-yellow-300 animate-fade-in-up">
                        <p className="font-bold">{selectedAnswer === currentQuestion.answer ? "Correct!" : "Not quite!"}</p>
                        <p className="text-sm mt-1">{currentQuestion.explanation}</p>
                    </div>
                )}
                <div className="mt-6 text-right">
                    {isAnswered ? (
                        <button onClick={handleNextQuestion} className="px-5 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105">Next</button>
                    ) : (
                        <button onClick={handleAnswerSubmit} disabled={!selectedAnswer} className="px-5 py-2 rounded-md bg-black/10 dark:bg-white/10 text-slate-800 dark:text-slate-100 font-semibold disabled:opacity-50 disabled:cursor-not-allowed">Submit</button>
                    )}
                </div>
            </div>
        );

        return <div className="p-8 text-center text-slate-500 dark:text-slate-400">Could not load quiz.</div>;
    }

    return (
        <div className="bg-slate-200 dark:bg-slate-800 backdrop-blur-xl border border-slate-300 dark:border-slate-700 rounded-2xl shadow-2xl animate-fade-in-up w-full max-w-2xl">
            <div className="flex items-start justify-between p-4 border-b border-slate-300 dark:border-slate-700">
                <h4 className="font-semibold text-lg text-slate-800 dark:text-slate-100">{quiz?.title || 'Quiz'}</h4>
                <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 transition">✕</button>
            </div>
            {renderContent()}
        </div>
    );
}
