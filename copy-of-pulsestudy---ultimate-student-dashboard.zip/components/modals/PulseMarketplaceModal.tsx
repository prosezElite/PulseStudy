import React from 'react';

interface PulseMarketplaceModalProps {
  pulseCredits: number;
  onClose: () => void;
}

const mockItems = [
    { title: "Advanced Calculus Note Pack", author: "Alex Nova", price: 250, type: "Notes" },
    { title: "Focus Lofi Playlist Vol. 3", author: "Samira Vue", price: 100, type: "Music" },
    { title: "Video Tutorial: Quantum Mechanics", author: "Kenji React", price: 500, type: "Video" },
    { title: "Origin² Core Theme", author: "PulseStudy", price: 10000, type: "Theme", req: "ELITE Rank" },
];

export default function PulseMarketplaceModal({ pulseCredits, onClose }: PulseMarketplaceModalProps) {
    return (
        <div className="fixed inset-0 z-[60] bg-slate-100 dark:bg-slate-900 flex flex-col animate-fade-in text-slate-800 dark:text-slate-100">
             <header className="flex-shrink-0 h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 z-10">
                <h2 className="font-semibold text-lg flex items-center gap-3">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500" viewBox="0 0 20 20" fill="currentColor"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" /></svg>
                    PulseMarketplace
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400" aria-label="Close">✕</button>
            </header>
            <main className="flex-1 overflow-y-auto p-4 sm:p-8">
                <div className="max-w-4xl mx-auto">
                    <div className="p-6 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-white flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div>
                            <p className="text-sm opacity-80">YOUR BALANCE</p>
                            <p className="text-4xl font-bold">{pulseCredits.toLocaleString()} PC</p>
                        </div>
                        <p className="text-sm sm:text-right max-w-sm">Earn PulseCredits by completing tasks, creating notes, and maintaining focus streaks. Spend them on community-created content and exclusive themes!</p>
                    </div>

                    <div className="mt-8">
                        <h3 className="font-bold text-xl text-slate-800 dark:text-slate-100">Featured Items (Coming Soon!)</h3>
                        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {mockItems.map(item => (
                                <div key={item.title} className="p-4 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col justify-between">
                                    <div>
                                        <div className="text-xs text-violet-500 dark:text-violet-400 font-semibold">{item.type}</div>
                                        <p className="font-semibold mt-1 text-slate-800 dark:text-slate-100">{item.title}</p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400">by {item.author}</p>
                                        {item.req && <p className="text-xs text-yellow-500 dark:text-yellow-400 mt-1">Requires: {item.req}</p>}
                                    </div>
                                    <button disabled className="mt-4 w-full text-sm font-semibold py-2 rounded-md bg-black/5 dark:bg-white/10 text-slate-500 dark:text-slate-400 cursor-not-allowed">
                                        💰 {item.price.toLocaleString()} PC
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}