import React, { useState, useEffect, useRef } from 'react';
import { getAICollaborationSuggestion } from '../../services/geminiService';

interface CollaborationCanvasModalProps {
  podGoal: string;
  onClose: () => void;
}

const mockCursors = [
  { name: 'Alex', color: '#34d399' }, // emerald-400
  { name: 'Sam', color: '#fb923c' }, // orange-400
];

export default function CollaborationCanvasModal({ podGoal, onClose }: CollaborationCanvasModalProps) {
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cursorsRef = useRef(mockCursors.map(c => ({ ...c, x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight, tx: 0, ty: 0 })));
  const animationFrameId = useRef<number | null>(null);
  
  const isDrawing = useRef(false);
  const lastPos = useRef<{ x: number, y: number } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const updateCursors = () => {
      cursorsRef.current.forEach(c => {
        if (Math.random() < 0.01) { // Change target position occasionally
          c.tx = Math.random() * canvas.width;
          c.ty = Math.random() * canvas.height;
        }
        c.x += (c.tx - c.x) * 0.05;
        c.y += (c.ty - c.y) * 0.05;
      });
    };

    const animate = () => {
      updateCursors();
      animationFrameId.current = requestAnimationFrame(animate);
    };
    animate();

    return () => {
        if(animationFrameId.current) {
            cancelAnimationFrame(animationFrameId.current);
        }
    }
  }, []);

  const handleGetSuggestion = async () => {
    setIsLoading(true);
    try {
      const result = await getAICollaborationSuggestion(podGoal);
      setSuggestion(result);
    } catch (error) {
      console.error(error);
      setSuggestion("Sorry, could not get a suggestion right now.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const getMousePos = (canvas: HTMLCanvasElement, e: React.MouseEvent) => {
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };
  
  const startDrawing = (e: React.MouseEvent) => {
    isDrawing.current = true;
    lastPos.current = getMousePos(canvasRef.current!, e);
  };

  const draw = (e: React.MouseEvent) => {
    if (!isDrawing.current) return;
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const pos = getMousePos(canvas, e);
    const isDarkMode = document.documentElement.classList.contains('dark');
    
    ctx.beginPath();
    ctx.moveTo(lastPos.current!.x, lastPos.current!.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = isDarkMode ? '#f8fafc' : '#1e293b'; // slate-50 or slate-900
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.stroke();
    lastPos.current = pos;
  };

  const stopDrawing = () => isDrawing.current = false;

  return (
    <div className="fixed inset-0 z-[60] bg-slate-200 dark:bg-slate-800 flex flex-col animate-fade-in text-slate-800 dark:text-white">
      <header className="flex-shrink-0 h-16 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md border-b border-slate-300 dark:border-slate-700 flex items-center justify-between px-4 z-10">
        <div>
            <h2 className="font-semibold text-lg">Live Collaboration Canvas</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 -mt-1">Pod Goal: {podGoal}</p>
        </div>
        <button onClick={onClose} className="p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-black/10 dark:hover:bg-white/10" aria-label="Close">✕</button>
      </header>
      <main className="flex-1 relative cursor-crosshair">
        <canvas 
            ref={canvasRef} 
            width={window.innerWidth}
            height={window.innerHeight}
            className="absolute inset-0"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
        />
        {/* Mock Cursors */}
        {cursorsRef.current.map(c => (
            <div key={c.name} style={{ transform: `translate(${c.x}px, ${c.y}px)`, position: 'absolute', top: 0, left: 0 }} className="transition-transform duration-500 ease-linear pointer-events-none">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 -rotate-45" style={{ color: c.color }} viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                 <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: c.color, color: '#000' }}>{c.name}</span>
            </div>
        ))}

        {/* Suggestion box */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-full max-w-lg p-4 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border border-slate-300 dark:border-slate-700 rounded-lg shadow-2xl text-center">
            {isLoading ? (
                <p className="animate-pulse text-slate-600 dark:text-slate-300">AI is thinking...</p>
            ) : suggestion ? (
                <p className="text-sm text-cyan-600 dark:text-cyan-300">{suggestion}</p>
            ) : (
                <p className="text-sm text-slate-500 dark:text-slate-400">Click the button below to get a helpful tip from the AI Facilitator.</p>
            )}
             <button
                onClick={handleGetSuggestion}
                disabled={isLoading}
                className="mt-3 px-4 py-2 text-xs font-semibold rounded-md bg-cyan-500/10 text-cyan-700 dark:bg-cyan-500/20 dark:text-cyan-300 hover:bg-cyan-500/20 dark:hover:bg-cyan-500/30 disabled:opacity-50"
            >
                {isLoading ? '...' : '✨ AI Facilitator'}
            </button>
        </div>
      </main>
    </div>
  );
}