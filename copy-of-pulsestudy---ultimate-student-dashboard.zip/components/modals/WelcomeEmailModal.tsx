import React from 'react';

interface WelcomeEmailModalProps {
  userName: string;
  userEmail: string;
  onClose: () => void;
}

const WelcomeEmailModal: React.FC<WelcomeEmailModalProps> = ({ userName, userEmail, onClose }) => {
  return (
    <div className="bg-slate-200 dark:bg-slate-800 backdrop-blur-xl border border-slate-300 dark:border-slate-700 rounded-2xl p-6 shadow-2xl animate-fade-in-up w-full max-w-2xl">
      <div className="flex items-start justify-between">
        <h4 className="font-semibold text-lg text-slate-800 dark:text-slate-100">✅ Sign Up Successful!</h4>
        <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 transition">✕</button>
      </div>
      <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">We've sent a welcome email to your inbox. Here's a preview:</p>
      
      <div className="mt-4 p-4 bg-white dark:bg-slate-900 rounded-lg border border-slate-300 dark:border-slate-700 max-h-[60vh] overflow-y-auto">
        <div className="text-sm space-y-1 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700 pb-3 mb-3">
            <p><span className="font-semibold text-slate-700 dark:text-slate-200">From:</span> PulseStudy Team &lt;welcome@pulsestudy.app&gt;</p>
            <p><span className="font-semibold text-slate-700 dark:text-slate-200">To:</span> {userName} &lt;{userEmail}&gt;</p>
            <p><span className="font-semibold text-slate-700 dark:text-slate-200">Subject:</span> Welcome to PulseStudy — Your Ultimate Student Dashboard!</p>
        </div>

        <div className="prose prose-sm max-w-none text-slate-700 dark:text-slate-300">
            <h2 className="text-slate-800 dark:text-slate-100">Hello {userName},</h2>
            <p>Welcome to <strong>PulseStudy!</strong> We're thrilled to have you on board. You've just unlocked a powerful suite of tools designed to elevate your learning, boost your productivity, and help you achieve your academic goals.</p>
            
            <h3 className="dark:text-slate-200">Here's a quick look at what you can do:</h3>
            <ul className="dark:text-slate-300">
                <li><strong>Organize Everything:</strong> Manage your tasks with priorities and due dates, and create detailed notes for all your subjects.</li>
                <li><strong>Master Your Focus:</strong> Use the built-in Pomodoro timer to manage intense study sprints and track your focus time.</li>
                <li><strong>Level Up Your Learning:</strong> Earn XP for completing tasks and notes, climb the ranks, and see how you stack up on the global leaderboard.</li>
                <li><strong>Get Instant Help:</strong> Our AI Doubt Solver, "Pulse," is available 24/7 to explain complex topics, help with math problems, and even generate code!</li>
                <li><strong>Boost Productivity:</strong> Use quick tools like the AI Summarizer, Mind Map creator, and Well-being checker to study smarter, not just harder.</li>
            </ul>

            <p>We're constantly working to make PulseStudy even better. Your journey to becoming a top student starts now.</p>
            <p>Happy studying!</p>
            <p>— The PulseStudy Team</p>
        </div>
      </div>
      
      <div className="mt-6 text-right">
        <button
            onClick={onClose}
            className="px-5 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105"
        >
            Get Started
        </button>
      </div>
    </div>
  );
};

export default WelcomeEmailModal;