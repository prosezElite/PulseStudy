import React, { useState, useEffect } from 'react';

interface WellBeingModalProps {
  suggestion: string;
  onClose: () => void;
}

const BREATH_CYCLE = {
    in: 4000,
    hold: 2000,
    out: 6000,
};

export default function WellBeingModal({ suggestion, onClose }: WellBeingModalProps) {
    const [breathState, setBreathState] = useState<'in' | 'hold' | 'out'>('in');

    useEffect(() => {
        const cycle = () => {
            setBreathState('in');
            setTimeout(() => {
                setBreathState('hold');
                setTimeout(() => {
                    setBreathState('out');
                }, BREATH_CYCLE.hold);
            }, BREATH_CYCLE.in);
        };
        
        cycle(); // Initial cycle
        const interval = setInterval(cycle, BREATH_CYCLE.in + BREATH_CYCLE.hold + BREATH_CYCLE.out);
        
        return () => clearInterval(interval);
    }, []);

    const getBreathText = () => {
        switch (breathState) {
            case 'in': return 'Breathe in...';
            case 'hold': return 'Hold';
            case 'out': return 'Breathe out...';
        }
    };

    const getAnimatorStyle = (): React.CSSProperties => {
        switch (breathState) {
            case 'in': return { transform: 'scale(1)', transition: `transform ${BREATH_CYCLE.in}ms ease-out` };
            case 'hold': return { transform: 'scale(1)', transition: 'none' };
            case 'out': return { transform: 'scale(0.5)', transition: `transform ${BREATH_CYCLE.out}ms ease-in-out` };
        }
    };
    
    return (
        <div className="fixed inset-0 z-[60] bg-gradient-to-br from-cyan-900 via-slate-900 to-violet-900 flex flex-col items-center justify-center p-8 text-white animate-fade-in text-center">
            <button onClick={onClose} className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors text-white" aria-label="Close">✕</button>
            
            <div className="w-full max-w-md">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center text-cyan-400 text-3xl">
                    🧘
                </div>

                <h4 className="font-semibold text-2xl text-white">A friendly reminder from Pulse</h4>
                <p className="mt-2 text-slate-300">{suggestion}</p>

                <div className="my-12 flex items-center justify-center h-48">
                    <div className="relative w-48 h-48 flex items-center justify-center">
                        <div
                            className="absolute w-full h-full rounded-full bg-cyan-500/20"
                            style={{ transform: 'scale(0.5)', ...getAnimatorStyle() }}
                        />
                        <div className="relative text-xl font-semibold text-slate-200">
                            {getBreathText()}
                        </div>
                    </div>
                </div>

                <button
                    onClick={onClose}
                    className="w-full px-5 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105"
                >
                    Thanks, I'll take a break!
                </button>
            </div>
        </div>
    );
}
