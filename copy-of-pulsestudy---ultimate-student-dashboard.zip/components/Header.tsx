import React from 'react';
import type { Theme } from '../App';

interface HeaderProps {
    onToggleMusicPlayer: () => void;
    theme: Theme;
    setTheme: (theme: Theme) => void;
    xp: number;
    pulseCredits: number;
}

const Header: React.FC<HeaderProps> = ({ onToggleMusicPlayer, theme, setTheme, xp, pulseCredits }) => {
  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <header className="w-full fixed top-4 left-0 z-40 px-4 sm:px-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border border-slate-200 dark:border-slate-700 rounded-2xl p-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center text-white font-bold text-lg">
            P
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-100">PulseStudy</div>
            <div className="text-xs text-slate-500 dark:text-slate-400 -mt-0.5">Ultimate Student Dashboard</div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-lg bg-black/5 dark:bg-white/5">
            <span title="PulseCredits">💰</span>
            <span className="font-semibold text-slate-700 dark:text-slate-200">{pulseCredits.toLocaleString()} PC</span>
          </div>

          <button onClick={toggleTheme} className="p-2.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors" aria-label="Toggle theme">
            {theme === 'light' ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 20 20" fill="currentColor"><path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" /></svg>
            ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.707.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zM4 11a1 1 0 100-2H3a1 1 0 100 2h1z" clipRule="evenodd" /></svg>
            )}
          </button>
          <button onClick={onToggleMusicPlayer} className="p-2.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-slate-600 dark:text-slate-300" aria-label="Open music player">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M18 3a1 1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3V7.82l8-1.6v5.894A4.37 4.37 0 0015 12c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3V4a1 1 0 00-.804-.98l-10-2z" /></svg>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;