
import React from 'react';
import type { Rank, PomodoroSession, StudyPod, CognitiveLoadData } from '../types';
import { ranks } from '../constants';
import RankBadge from './RankBadge';
import AiInsights from './AiInsights';
import StudyPodSection from './StudyPodSection';
import PulseLive from './PulseLive';
import CognitivePulseMonitor from './CognitivePulseMonitor';

interface DashboardProps {
  userName: string;
  taskCount: number;
  noteCount: number;
  focusTime: number;
  xp: number;
  rank: Rank;
  onOpenModal: (type: 'ranks' | 'stats' | 'aiRatingInfo' | 'studyPodSetup' | 'collaborationCanvas') => void;
  aiRating: number;
  pomodoro: {
    duration: number;
    setDuration: (d: number) => void;
    breakDuration: number;
    setBreakDuration: (d: number) => void;
    secondsLeft: number;
    isRunning: boolean;
    setIsRunning: (r: boolean) => void;
    reset: () => void;
    session: PomodoroSession;
    setSession: React.Dispatch<React.SetStateAction<PomodoroSession>>;
    openFullScreen: () => void;
    isBreak: boolean;
  };
  onGenerateInsights: () => Promise<string[]>;
  studyPod: StudyPod;
  onLeavePod: () => void;
  onOpenPulseLive: () => void;
  cognitiveLoad: CognitiveLoadData;
}

const StatCard: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
  <div className="p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 transition-transform duration-300 hover:-translate-y-1 origin-theme:bg-cyan-400/5 origin-theme:border-cyan-400/20">
    <div className="text-xs text-slate-500 dark:text-slate-400">{label}</div>
    <div className="text-lg font-bold text-slate-700 dark:text-slate-200">{value}</div>
  </div>
);

const AIRatingCard: React.FC<{ rating: number, onClick: () => void }> = ({ rating, onClick }) => (
    <button onClick={onClick} className="p-4 rounded-xl text-left w-full bg-gradient-to-br from-violet-500/10 to-cyan-500/10 border border-violet-400/30 relative overflow-hidden transition-all duration-300 hover:border-violet-400/60 hover:-translate-y-1 hover:shadow-lg hover:shadow-violet-500/20 origin-theme:bg-slate-800/20 origin-theme:border-violet-400/40">
        <div className="flex items-center justify-between">
            <div className="text-xs text-violet-500 dark:text-violet-400">AI Rating</div>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
        </div>
        <div className="text-lg font-bold text-slate-700 dark:text-slate-200">{rating > 0 ? rating.toLocaleString() : '...'}</div>
    </button>
);

const formatDate = (d: Date) => d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });

const PomodoroTimer: React.FC<DashboardProps['pomodoro'] & { cognitiveLoad: CognitiveLoadData }> = ({ duration, setDuration, breakDuration, setBreakDuration, secondsLeft, isRunning, setIsRunning, reset, session, setSession, openFullScreen, cognitiveLoad }) => {
    
    const handleReset = () => {
        reset();
    };

    const handleDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newDuration = parseInt(e.target.value, 10);
        if (newDuration > 0 && newDuration <= 120) {
            setDuration(newDuration);
        }
    };

    const handleBreakDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newDuration = parseInt(e.target.value, 10);
        setBreakDuration(newDuration);
    };
    
    const handleGoalChange = (amount: number) => {
        setSession(s => ({ ...s, total: Math.max(1, s.total + amount) }));
    };

    const formatTime = (s: number) => {
        const m = Math.floor(s / 60).toString().padStart(2, '0');
        const secs = (s % 60).toString().padStart(2, '0');
        return `${m}:${secs}`;
    };

    return (
        <aside className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 flex flex-col items-center justify-between transition-transform duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-violet-500/10 h-full origin-theme:bg-slate-900/50 origin-theme:border-slate-700">
            <div className="w-full">
                <div className="flex items-center justify-between w-full">
                    <div className="text-sm text-slate-500 dark:text-slate-400">Pomodoro</div>
                     <button onClick={openFullScreen} className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors text-slate-600 dark:text-slate-300" aria-label="Open full-screen timer">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 1v4m0 0h-4m4 0l-5-5" /></svg>
                    </button>
                </div>
                 <div className="flex items-center justify-between w-full gap-2 text-sm text-slate-500 dark:text-slate-400 mt-2">
                    <div className="flex items-center gap-2">
                        <input 
                            id="customPomodoro" 
                            type="number" 
                            value={duration}
                            onChange={handleDurationChange}
                            className="w-14 text-slate-700 dark:text-slate-200 p-1 rounded-md bg-black/10 dark:bg-white/10 text-center focus:ring-2 focus:ring-violet-500 focus:outline-none"
                        /> 
                        <label htmlFor="customPomodoro">min focus</label>
                    </div>
                    <div className="flex items-center gap-2">
                        <input 
                            id="customBreak" 
                            type="number" 
                            value={breakDuration}
                            onChange={handleBreakDurationChange}
                            className="w-14 text-slate-700 dark:text-slate-200 p-1 rounded-md bg-black/10 dark:bg-white/10 text-center focus:ring-2 focus:ring-violet-500 focus:outline-none"
                        /> 
                        <label htmlFor="customBreak">min break</label>
                    </div>
                </div>
                <div className="text-5xl font-bold my-2 text-slate-800 dark:text-slate-100 w-full text-center">{formatTime(secondsLeft)}</div>
            </div>

            <div className="w-full">
                 <div className="w-full">
                    <div className="flex items-center justify-center mb-1">
                        <h4 className="text-xs text-slate-500 dark:text-slate-400 font-semibold">COGNITIVE PULSE</h4>
                        <div className="relative group ml-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-slate-400 dark:text-slate-500" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                            </svg>
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 bg-slate-800 text-white text-xs rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10">
                                The Cognitive Pulse visualizes your estimated focus intensity during a session. As you progress, the pulse grows, simulating increased mental engagement. It's a visual cue to remind you to take breaks and avoid burnout.
                                <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-8 border-x-transparent border-t-8 border-t-slate-800"></div>
                            </div>
                        </div>
                    </div>
                    <CognitivePulseMonitor load={cognitiveLoad.load} message={cognitiveLoad.message} />
                </div>
                <div className="flex items-center justify-center gap-2 mb-4">
                    {Array.from({ length: session.total }).map((_, i) => (
                        <div key={i} className={`w-3 h-3 rounded-full transition-all duration-300 ${i < session.completed ? 'bg-cyan-400' : 'bg-black/20 dark:bg-white/20'}`}></div>
                    ))}
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-3">
                    <span>Today's Goal</span>
                    <div className="flex items-center gap-2">
                        <button onClick={() => handleGoalChange(-1)} className="w-5 h-5 rounded bg-black/10 dark:bg-white/10 hover:bg-black/20 dark:hover:bg-white/20">-</button>
                        <span>{session.total} sessions</span>
                        <button onClick={() => handleGoalChange(1)} className="w-5 h-5 rounded bg-black/10 dark:bg-white/10 hover:bg-black/20 dark:hover:bg-white/20">+</button>
                    </div>
                </div>

                <div className="flex gap-3">
                    <button onClick={() => setIsRunning(!isRunning)} className="w-full px-4 py-2 rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105">
                        {isRunning ? 'Pause' : 'Start'}
                    </button>
                    <button onClick={handleReset} className="px-4 py-2 rounded-md bg-black/10 dark:bg-white/10 hover:bg-black/20 dark:hover:bg-white/20 transition-colors text-slate-700 dark:text-slate-200">Reset</button>
                </div>
            </div>
        </aside>
    );
};


export default function Dashboard({ userName, taskCount, noteCount, focusTime, xp, rank, onOpenModal, aiRating, pomodoro, onGenerateInsights, studyPod, onLeavePod, onOpenPulseLive, cognitiveLoad }: DashboardProps) {
  const currentRankIndex = ranks.findIndex(r => r.name === rank.name);
  const nextRank = currentRankIndex !== -1 && currentRankIndex < ranks.length - 1 ? ranks[currentRankIndex + 1] : null;

  let xpPercentage = 0;
  let xpDisplay = `${xp.toLocaleString()}`;

  if (nextRank) {
      const rankXpRange = nextRank.min - rank.min;
      const xpInCurrentRank = xp - rank.min;
      xpPercentage = Math.max(0, Math.min((xpInCurrentRank / rankXpRange) * 100, 100));
      xpDisplay = `${xp.toLocaleString()} / ${nextRank.min.toLocaleString()}`;
  } else {
      // Last rank, bar is full
      xpPercentage = 100;
  }

  return (
    <section className="space-y-6">
      <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-6 transition-transform duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-violet-500/10 space-y-6 origin-theme:bg-slate-900/50 origin-theme:border-slate-700">
        <div>
            <div className="flex items-start justify-between gap-4">
              <div>
                <h1 className="text-2xl font-extrabold text-slate-800 dark:text-slate-100">Welcome back, {userName}!</h1>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Let's make today productive.</p>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-xs text-slate-500 dark:text-slate-400">Today</div>
                <div className="font-semibold text-slate-700 dark:text-slate-200">{formatDate(new Date())}</div>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard label="Tasks" value={taskCount} />
              <AIRatingCard rating={aiRating} onClick={() => onOpenModal('aiRatingInfo')} />
              <StatCard label="Notes" value={noteCount} />
              <StatCard label="Focus Time" value={`${focusTime}m`} />
            </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <AiInsights onGenerate={onGenerateInsights} />
          <PulseLive onOpen={onOpenPulseLive} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-1 transition-transform duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-violet-500/10 origin-theme:bg-slate-900/50 origin-theme:border-slate-700">
            <button 
                onClick={() => onOpenModal('ranks')}
                className="w-full h-full p-4 rounded-xl flex items-center gap-4 text-left transition-colors hover:bg-black/5 dark:hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-violet-500"
                aria-label="View rank progression"
            >
                <RankBadge rank={rank} />
                <div className="flex-1">
                    <div className="text-xs text-slate-500 dark:text-slate-400 mb-1 flex justify-between">
                        <span>XP: {xpDisplay}</span>
                        <span className="font-semibold text-slate-700 dark:text-slate-200">Rank: {rank.name}</span>
                    </div>
                    <div className="w-full h-2.5 bg-black/20 dark:bg-white/10 rounded-full overflow-hidden">
                        <div 
                            className="h-full bg-gradient-to-r from-cyan-500 to-violet-500 rounded-full transition-all duration-500 ease-out" 
                            style={{ width: `${xpPercentage}%` }}
                        ></div>
                    </div>
                </div>
            </button>
        </div>

        {studyPod.isActive ? (
            <StudyPodSection 
                pod={studyPod}
                pomodoro={pomodoro}
                onLeave={onLeavePod}
                onOpenModal={onOpenModal}
            />
        ) : (
            <PomodoroTimer {...pomodoro} cognitiveLoad={cognitiveLoad} />
        )}
      </div>
    </section>
  );
};