
import React, { useRef, useEffect } from 'react';

interface CognitivePulseMonitorProps {
  load: number; // 0 to 1
  message: string;
}

const CognitivePulseMonitor: React.FC<CognitivePulseMonitorProps> = ({ load, message }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameId = useRef<number | null>(null);
  const lastLoad = useRef(load);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let currentLoad = lastLoad.current;
    
    const animate = (time: number) => {
      // Smoothly transition the load value
      currentLoad += (load - currentLoad) * 0.05;
      lastLoad.current = currentLoad;

      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const centerX = width / 2;
      const centerY = height / 2;
      const baseRadius = height * 0.2;
      const maxRadius = height * 0.45;
      
      const radius = baseRadius + (maxRadius - baseRadius) * currentLoad;
      const pulse = Math.sin(time / 400) * 3 * currentLoad;

      const hue = 200 - (180 * currentLoad); // 200 (blue) to 20 (orange/red)
      const saturation = 80 + 20 * currentLoad;
      const lightness = 55;

      // Outer glow
      const glowGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius + pulse + 15);
      glowGradient.addColorStop(0, `hsla(${hue}, ${saturation}%, ${lightness}%, 0.4)`);
      glowGradient.addColorStop(0.7, `hsla(${hue}, ${saturation}%, ${lightness}%, 0.1)`);
      glowGradient.addColorStop(1, `hsla(${hue}, ${saturation}%, ${lightness}%, 0)`);
      ctx.fillStyle = glowGradient;
      ctx.fillRect(0, 0, width, height);

      // Main orb
      const orbGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius + pulse);
      orbGradient.addColorStop(0, `hsla(${hue}, ${saturation}%, ${lightness}%, 1)`);
      orbGradient.addColorStop(1, `hsla(${hue - 30}, ${saturation}%, ${lightness - 10}%, 1)`);
      ctx.fillStyle = orbGradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius + pulse, 0, Math.PI * 2);
      ctx.fill();

      // Inner highlight
      const highlightGradient = ctx.createRadialGradient(centerX - radius*0.2, centerY - radius*0.2, 0, centerX, centerY, radius);
      highlightGradient.addColorStop(0, `hsla(0, 0%, 100%, 0.2)`);
      highlightGradient.addColorStop(1, `hsla(0, 0%, 100%, 0)`);
      ctx.fillStyle = highlightGradient;
      ctx.fill();

      animationFrameId.current = requestAnimationFrame(animate);
    };

    animationFrameId.current = requestAnimationFrame(animate);

    return () => {
      if(animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [load]);

  return (
    <div className="relative h-24 w-full mb-2 cursor-pointer group" title={`Cognitive Pulse: ${message}`}>
      <canvas ref={canvasRef} width="300" height="96" className="w-full h-full" />
      <div className="absolute inset-0 flex items-center justify-center">
        <p className="text-xs font-semibold text-white/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-sm bg-black/20 px-2 py-1 rounded-md">{message}</p>
      </div>
    </div>
  );
};

export default CognitivePulseMonitor;
