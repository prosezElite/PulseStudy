import React, { useState, useRef, useEffect } from 'react';
import { getAIChatResponseStream } from '../services/geminiService';
import { AI_SAMPLE_PROMPTS } from '../constants';
import { TaskPriority, ChatMessage, NoteFile } from '../types';
import { GenerateContentResponse } from '@google/genai';

type Message = ChatMessage;
type AiMode = 'direct' | 'socratic' | 'time-twin' | 'quantum';

interface AiSolverProps {
  isOpen: boolean;
  onClose: () => void;
  userName: string;
  setUserName: (name: string) => void;
  onAddTask: (title: string, priority: TaskPriority, dueDate?: number, reminderOffset?: number) => void;
}

const MarkdownRenderer: React.FC<{ text: string }> = ({ text }) => {
  // Simple regex for **bold** and *italic*
  const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g);

  return (
    <>
      {parts.map((part, index) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={index}>{part.slice(2, -2)}</strong>;
        }
        if (part.startsWith('*') && part.endsWith('*')) {
          return <em key={index}>{part.slice(1, -1)}</em>;
        }
        return <React.Fragment key={index}>{part}</React.Fragment>;
      })}
    </>
  );
};


const AiSolver: React.FC<AiSolverProps> = ({ isOpen, onClose, userName, setUserName, onAddTask }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<NoteFile | null>(null);
  const [aiMode, setAiMode] = useState<AiMode>('direct');
  const chatBoxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (chatBoxRef.current) {
      chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight;
    }
  }, [messages]);

  // Prompt for name if not set and focus input when chat opens
  useEffect(() => {
    if (isOpen) {
        if (!userName) {
            const name = window.prompt("What should I call you? This will personalize your experience.");
            if (name) {
                setUserName(name);
            }
        }
        setTimeout(() => inputRef.current?.focus(), 300); // After animation
    }
  }, [isOpen, userName, setUserName]);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const maxSizeBytes = 20 * 1024 * 1024; // 20 MB
    if (file.size > maxSizeBytes) {
        alert('File size exceeds 20MB limit.');
        return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        setAttachedFile({ name: file.name, type: file.type, dataUrl });
    };
    reader.readAsDataURL(file);
    e.target.value = ''; // Reset file input
  };

  const handleSend = async (promptText?: string) => {
    const trimmedInput = promptText || input.trim();
    if ((!trimmedInput && !attachedFile) || isLoading) return;

    const userMessage: Message = { text: trimmedInput, from: 'user', file: attachedFile || undefined };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    
    if (!promptText) {
        setInput('');
    }
    setAttachedFile(null);
    setIsLoading(true);

    try {
        const stream = await getAIChatResponseStream(newMessages, aiMode);
        
        let functionCalls: any[] = [];
        let hasAddedAIMessage = false;

        for await (const chunk of stream) {
            const chunkText = chunk.text;
            if (chunkText) {
                if (!hasAddedAIMessage) {
                    setMessages(prev => [...prev, { text: '', from: 'ai' }]);
                    hasAddedAIMessage = true;
                }
                
                setMessages(prev => {
                    const updated = [...prev];
                    const lastMsg = updated[updated.length - 1];
                    if (lastMsg && lastMsg.from === 'ai') {
                       lastMsg.text += chunkText;
                    }
                    return updated;
                });
            }
            if (chunk.functionCalls) {
                functionCalls.push(...chunk.functionCalls);
            }
        }

        if (functionCalls.length > 0) {
            let confirmationText = '';
            for (const fc of functionCalls) {
                if (fc.name === 'createTask') {
                    const { title, priority, dueDate } = fc.args as { title: string; priority?: TaskPriority; dueDate?: number };
                    onAddTask(title, priority || 'medium', dueDate, undefined);
                    confirmationText += `✅ Task added: "${title}"\n`;
                }
            }

            const lastMessageText = messages[messages.length - 1]?.text?.trim() || '';

            if (confirmationText.trim() && !lastMessageText) {
                const confirmationMessage: Message = { text: confirmationText.trim(), from: 'ai' };
                if (hasAddedAIMessage) {
                    setMessages(prev => {
                        const updatedMessages = [...prev];
                        updatedMessages[updatedMessages.length - 1] = confirmationMessage;
                        return updatedMessages;
                    });
                } else {
                    setMessages(prev => [...prev, confirmationMessage]);
                }
            }
        }

    } catch (e) {
        const errorMessage: Message = { text: "Sorry, I encountered an error. Please try again.", from: 'ai' };
        setMessages(prev => [...prev, errorMessage]);
    } finally {
        setIsLoading(false);
    }
  };


  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };
  
  const aiModeOptions: { id: AiMode; label: string; description: string }[] = [
    { id: 'direct', label: 'Direct', description: 'Standard, helpful answers.' },
    { id: 'socratic', label: 'Socratic', description: 'Answers with guiding questions.' },
    { id: 'time-twin', label: 'Time-Twin', description: 'Concise advice from your future self.' },
    { id: 'quantum', label: 'Quantum', description: 'Connects ideas across different fields.' },
  ];

  return (
    <div className={`fixed inset-0 z-50 bg-slate-200/80 dark:bg-slate-900/80 backdrop-blur-xl flex flex-col transition-opacity duration-300 ease-in-out
      ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-slate-300 dark:border-slate-700 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center text-white font-bold text-sm">
            AI
          </div>
          <h3 className="font-semibold text-lg text-slate-800 dark:text-slate-100">AI Doubt Solver</h3>
        </div>
        <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-black/10 dark:hover:bg-white/10 transition" aria-label="Close AI Chat">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
      </header>

      {/* Chat Body */}
      <div ref={chatBoxRef} className="flex-1 overflow-y-auto p-4 scroll-smooth">
        {messages.length === 0 ? (
          <div className="flex flex-col justify-center items-center h-full text-center animate-fade-in-up">
            <div className="w-16 h-16 mb-4 rounded-full bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center text-white font-bold text-3xl shadow-lg">
              P
            </div>
            <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">
              Hello, {userName || 'Student'}! How can I help you today?
            </h2>
            <p className="text-slate-500 dark:text-slate-400 mt-2 mb-6 max-w-md">
              I'm Pulse, your AI tutor. Ask me anything from complex theories to simple definitions. You can also ask me to create tasks for you, like "add a task to read chapter 5 by tomorrow".
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-2xl w-full">
              {AI_SAMPLE_PROMPTS.map((prompt, i) => (
                <button 
                  key={i}
                  onClick={() => handleSend(prompt)}
                  className="p-4 rounded-lg bg-black/5 dark:bg-white/5 border border-slate-300 dark:border-slate-700 text-left font-medium hover:bg-black/10 dark:hover:bg-white/10 transition-colors duration-200 text-sm text-slate-600 dark:text-slate-300"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4 text-sm max-w-3xl mx-auto py-4">
            {messages.map((msg, index) => (
              <div key={index} className={`flex items-start gap-3 ${msg.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.from === 'ai' && (
                  <div className="w-7 h-7 flex-shrink-0 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-500 text-xs font-bold">
                    P
                  </div>
                )}
                <div className={`p-3 rounded-xl max-w-[85%] ${msg.from === 'user' ? 'bg-violet-500 text-white rounded-br-none' : 'bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-bl-none'}`}>
                  <div className="whitespace-pre-wrap">
                    <MarkdownRenderer text={msg.text} />
                    {msg.from === 'user' && msg.file && (
                        <div className="mt-2 p-2 bg-violet-600/80 rounded-md flex items-center gap-2 text-xs border border-violet-400/50">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" /></svg>
                            <span className="truncate">{msg.file.name}</span>
                        </div>
                    )}
                    {msg.from === 'ai' && isLoading && index === messages.length - 1 && (
                        <span className="blinking-cursor">|</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {isLoading && (messages.length === 0 || messages[messages.length - 1].from === 'user') && (
                <div className="flex items-start gap-3 justify-start">
                     <div className="w-7 h-7 flex-shrink-0 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 text-xs font-bold">
                        P
                     </div>
                     <div className="p-3 rounded-xl max-w-[85%] bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-bl-none">
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></div>
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                        </div>
                    </div>
                </div>
            )}
          </div>
        )}
      </div>

      {/* Input Footer */}
      <div className="p-4 border-t border-slate-300 dark:border-slate-700 flex-shrink-0">
        <div className="max-w-3xl mx-auto space-y-2">
            <div className="flex justify-center mb-2">
                <div className="relative group">
                    <div className="flex items-center gap-2 p-1 rounded-full bg-black/5 dark:bg-white/5 text-xs font-semibold">
                        {aiModeOptions.map(opt => (
                            <button key={opt.id} onClick={() => setAiMode(opt.id)} className={`px-3 py-1 rounded-full transition-colors ${aiMode === opt.id ? 'bg-white dark:bg-slate-700 shadow-sm text-slate-700 dark:text-slate-200' : 'text-slate-500 dark:text-slate-400'}`}>
                                {opt.label}
                            </button>
                        ))}
                    </div>
                    <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 w-48 p-2 bg-slate-800 text-white text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                        <span className="font-bold">{aiModeOptions.find(o => o.id === aiMode)?.label}: </span>
                        {aiModeOptions.find(o => o.id === aiMode)?.description}
                    </div>
                </div>
            </div>
            {attachedFile && (
                <div className="p-2 rounded-md bg-violet-500/10 flex items-center justify-between gap-2 animate-fade-in-up">
                    <div className="flex items-center gap-2 overflow-hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-violet-500 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" /></svg>
                        <span className="text-sm text-slate-700 dark:text-slate-200 truncate">{attachedFile.name}</span>
                    </div>
                    <button onClick={() => setAttachedFile(null)} className="p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" /></svg>
                    </button>
                </div>
            )}
            <div className="flex gap-2">
                <input ref={fileInputRef} type="file" onChange={handleFileChange} className="hidden" />
                <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isLoading}
                    className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-md bg-black/5 dark:bg-white/10 text-slate-600 dark:text-slate-300 hover:bg-black/10 dark:hover:bg-white/10 transition-colors disabled:opacity-50"
                    aria-label="Attach file"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8 4a3 3 0 00-3 3v4a3 3 0 006 0V7a1 1 0 112 0v4a5 5 0 01-10 0V7a5 5 0 0110 0v4a3 3 0 11-6 0V7a1 1 0 012 0v4a1 1 0 102 0V7a3 3 0 00-3-3z" clipRule="evenodd" /></svg>
                </button>
                <input
                    ref={inputRef}
                    id="doubtInput"
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type your doubt or ask to add a task..."
                    disabled={isLoading}
                    className="flex-1 p-3 rounded-md bg-transparent border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-violet-500 focus:outline-none transition disabled:opacity-50"
                />
                <button
                    onClick={() => handleSend()}
                    disabled={isLoading || (!input.trim() && !attachedFile)}
                    className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-md bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100"
                    aria-label="Send message"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                    </svg>
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default AiSolver;