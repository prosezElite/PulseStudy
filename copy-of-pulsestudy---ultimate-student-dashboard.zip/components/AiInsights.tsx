import React, { useState } from 'react';

interface AiInsightsProps {
    onGenerate: () => Promise<string[]>;
}

export default function AiInsights({ onGenerate }: AiInsightsProps) {
    const [insights, setInsights] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [hasGenerated, setHasGenerated] = useState(false);

    const handleGenerateClick = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const result = await onGenerate();
            setInsights(result);
            setHasGenerated(true);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="p-4 rounded-xl bg-gradient-to-br from-cyan-500/10 to-violet-500/10 border border-cyan-400/30">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-cyan-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
                    <div className="text-xs font-semibold text-cyan-600 dark:text-cyan-400">PULSE INSIGHTS</div>
                </div>
                {!hasGenerated && (
                    <button onClick={handleGenerateClick} disabled={isLoading} className="px-3 py-1 text-xs font-semibold rounded-md bg-white/50 dark:bg-slate-700/50 hover:bg-white/80 dark:hover:bg-slate-600/50 border border-slate-200 dark:border-slate-600 transition-colors disabled:opacity-50 text-slate-700 dark:text-slate-200">
                        {isLoading ? 'Analyzing...' : 'Analyze My Day'}
                    </button>
                )}
            </div>
            <div className="mt-3">
                {isLoading && <p className="text-sm text-slate-500 dark:text-slate-400 animate-pulse">Checking your progress...</p>}
                {error && <p className="text-sm text-red-500">{error}</p>}
                {!isLoading && !error && hasGenerated && (
                    insights.length > 0 ? (
                        <ul className="space-y-2">
                            {insights.map((insight, index) => (
                                <li key={index} className="text-sm text-slate-700 dark:text-slate-200 leading-tight bg-white/30 dark:bg-slate-900/30 p-2 rounded-md">
                                    {insight}
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-slate-500 dark:text-slate-400">Looks like you're on a steady track. Keep up the great work!</p>
                    )
                )}
                 {!isLoading && !error && !hasGenerated && (
                    <p className="text-sm text-slate-500 dark:text-slate-400">Click "Analyze" for personalized tips from your AI tutor based on your recent activity.</p>
                 )}
            </div>
        </div>
    );
}