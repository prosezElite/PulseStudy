import React from 'react';
import type { ModalContentType } from '../types';

interface QuickToolsProps {
  onOpenModal: (type: ModalContentType) => void;
  onWellBeingCheck: () => void;
}

const ToolButton: React.FC<{ onClick: () => void, children: React.ReactNode, className?: string, title: string }> = ({ onClick, children, className = '', title }) => (
    <button onClick={onClick} className={`p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 text-center font-semibold text-sm text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/10 transition-all duration-300 flex flex-col items-center justify-center gap-2 hover:-translate-y-1 hover:shadow-lg origin-theme:bg-cyan-400/5 origin-theme:border-cyan-400/20 ${className}`} title={title}>
        {children}
    </button>
);

const QuickTools: React.FC<QuickToolsProps> = ({ onOpenModal, onWellBeingCheck }) => {
  return (
    <section id="tools" className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 transition-transform duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-violet-500/10 mt-6 origin-theme:bg-slate-900/50 origin-theme:border-slate-700">
      <h3 className="font-semibold text-lg text-slate-800 dark:text-slate-100">Quick Tools</h3>
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        
        <ToolButton onClick={() => onOpenModal('build')} title="Build with AI" className="md:col-span-2 bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-slate-700 dark:text-slate-200 font-bold border-cyan-500/30">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
            <span>Build with AI</span>
        </ToolButton>

        <ToolButton onClick={() => onOpenModal('researchAssistant')} title="AI Research Assistant" className="md:col-span-2 bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-slate-700 dark:text-slate-200 font-bold border-cyan-500/30">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path d="M9 9a2 2 0 114 0 2 2 0 01-4 0z" />
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a4 4 0 00-3.446 6.032l-2.261 2.26a1 1 0 101.414 1.414l2.26-2.26A4 4 0 1011 5z" clipRule="evenodd" />
            </svg>
            <span>Research AI</span>
        </ToolButton>

        <ToolButton onClick={() => onOpenModal('imageStudio')} title="AI Creative Studio" className="md:col-span-2 bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-slate-700 dark:text-slate-200 font-bold border-cyan-500/30">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" />
            <path fillRule="evenodd" d="M.664 10.59a1.651 1.651 0 010-1.18l3.75-7.043a1.65 1.65 0 012.831.31l3.75 7.043a1.65 1.65 0 01-1.416 2.493H2.08a1.65 1.65 0 01-1.416-2.493zM19.336 10.59a1.651 1.651 0 000-1.18l-3.75-7.043a1.65 1.65 0 00-2.831.31l-3.75 7.043a1.65 1.65 0 001.416 2.493h9.832a1.65 1.65 0 001.416-2.493z" clipRule="evenodd" />
            </svg>
            <span>Creative Studio</span>
        </ToolButton>
        
        <ToolButton onClick={() => onOpenModal('videoStudio')} title="AI Video Studio" className="md:col-span-2 bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-slate-700 dark:text-slate-200 font-bold border-cyan-500/30">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 001.553.832l3-2a1 1 0 000-1.664l-3-2z" /></svg>
            <span>Video Studio</span>
        </ToolButton>

        <ToolButton onClick={() => onOpenModal('studyYoutube')} title="Study with YouTube">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"></path></svg>
            <span>Study Youtube</span>
        </ToolButton>
        
        <ToolButton onClick={() => onOpenModal('focusFlow')} title="Focus Flow">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10.49 2.23a1 1 0 00-1.02-.02l-7.5 4.5a1 1 0 00.52 1.858L10 6.556l7.51 2.016a1 1 0 10.52-1.858l-7.5-4.5zM10 8.5L2.5 10.516a1 1 0 10.52 1.858L10 10.444l7.51 2.016a1 1 0 10.52-1.858L10 8.5zM3 14a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" /></svg>
            <span>Focus Flow</span>
        </ToolButton>
        
        <ToolButton onClick={() => onOpenModal('globalPulseMesh')} title="Global Pulse Mesh">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM4.332 8.027a6.002 6.002 0 019.336 0l.243.243a1 1 0 01-1.415 1.415L12 9.272a4 4 0 00-4.002 0l-.41.41a1 1 0 01-1.415-1.415l.159-.159zM10 15a4 4 0 004-4H6a4 4 0 004 4z" clipRule="evenodd" /></svg>
            <span>Pulse Mesh</span>
        </ToolButton>

        <ToolButton onClick={() => onOpenModal('dejaLearn')} title="Memory Injection (DejaLearn)">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8.257 3.099A.75.75 0 019 2.5h2a.75.75 0 01.743.599l.823 3.292a.75.75 0 01-.364 1.118l-1.921.96a.75.75 0 01-.867 0l-1.921-.96a.75.75 0 01-.364-1.118l.823-3.292zM12 11a1 1 0 11-2 0 1 1 0 012 0zM11.601 14.341a.75.75 0 01-1.202 0l-.823-1.646a.75.75 0 011.06-1.06l.265.265.265-.265a.75.75 0 011.06 1.06l-.823 1.646z" clipRule="evenodd" /><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM3 10a7 7 0 1114 0 7 7 0 01-14 0z" clipRule="evenodd" /></svg>
            <span>DejaLearn</span>
        </ToolButton>
        
        <ToolButton onClick={() => onOpenModal('conceptStressTest')} title="Concept Stress Test">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
            <span>Stress Test</span>
        </ToolButton>

        <ToolButton onClick={() => onOpenModal('summarizer')} title="AI Summarizer">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v1h-2V4H7v1H5V4zM5 7h10v9a2 2 0 01-2 2H7a2 2 0 01-2-2V7z" /><path d="M7 9a1 1 0 000 2h6a1 1 0 100-2H7zM7 13a1 1 0 000 2h4a1 1 0 100-2H7z" /></svg>
            <span>AI Summarizer</span>
        </ToolButton>

        <ToolButton onClick={() => onOpenModal('mindMap')} title="Create a Mind Map">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.657a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 4.95a1 1 0 00-1.414 1.414l.707.707a1 1 0 001.414-1.414l-.707-.707zM3 10a1 1 0 011-1h1a1 1 0 110 2H4a1 1 0 01-1-1zM10 15a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.657 14.343a1 1 0 00-1.414 1.414l.707.707a1 1 0 001.414-1.414l-.707-.707zM15.05 15.05a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM10 6a4 4 0 100 8 4 4 0 000-8z" /></svg>
            <span>New Mind Map</span>
        </ToolButton>

        <ToolButton onClick={() => onOpenModal('studyPodSetup')} title="Start a Study Pod">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" /></svg>
             <span>Study Pod</span>
        </ToolButton>
        
        <ToolButton onClick={onWellBeingCheck} title="Well-being Check">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
            </svg>
             <span>Well-being</span>
        </ToolButton>
        <ToolButton onClick={() => onOpenModal('calculator')} title="AI Math Solver">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 3a1 1 0 000 2h10a1 1 0 100-2H5zm0 4a1 1 0 000 2h10a1 1 0 100-2H5zm0 4a1 1 0 000 2h10a1 1 0 100-2H5zm0 4a1 1 0 000 2h10a1 1 0 100-2H5z" clipRule="evenodd" /></svg>
             <span>Math Solver</span>
        </ToolButton>
        <ToolButton onClick={() => onOpenModal('graphingCalculator')} title="Graphing Calculator">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 6C8.5 6 9 18 15 18s5-12 8-12" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h18" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18" />
            </svg>
            <span>Graphing Calc</span>
        </ToolButton>
        <ToolButton onClick={() => onOpenModal('pulseMarketplace')} title="PulseMarketplace">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
            </svg>
            <span>Marketplace</span>
        </ToolButton>
      </div>
    </section>
  );
};
export default QuickTools;