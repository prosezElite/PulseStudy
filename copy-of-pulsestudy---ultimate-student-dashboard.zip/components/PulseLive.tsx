import React from 'react';

interface PulseLiveProps {
    onOpen: () => void;
}

export default function PulseLive({ onOpen }: PulseLiveProps) {
    return (
        <div className="p-4 rounded-xl bg-gradient-to-br from-violet-500/10 to-cyan-500/10 border border-violet-400/30">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                     <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                    <div className="text-xs font-semibold text-violet-600 dark:text-violet-400">PULSE LIVE</div>
                </div>
                <button onClick={onOpen} className="px-3 py-1 text-xs font-semibold rounded-md bg-white/50 dark:bg-slate-700/50 hover:bg-white/80 dark:hover:bg-slate-600/50 border border-slate-200 dark:border-slate-600 transition-colors text-slate-700 dark:text-slate-200">
                    Start Live Session
                </button>
            </div>
            <p className="mt-3 text-sm text-slate-500 dark:text-slate-400">Talk to your AI tutor in real-time. Click "Start" to begin your voice chat session.</p>
        </div>
    );
}