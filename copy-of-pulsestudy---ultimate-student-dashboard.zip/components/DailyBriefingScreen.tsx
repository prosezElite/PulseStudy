import React, { useState, useEffect } from 'react';
import type { DailyBriefing } from '../types';

interface DailyBriefingScreenProps {
  briefing: DailyBriefing;
  userName: string;
  onComplete: () => void;
}

type InitStage = 'connecting' | 'personalizing' | 'briefing' | 'ready';

const SystemCheckItem: React.FC<{ text: string; delay: number }> = ({ text, delay }) => (
    <p className="system-check-line" style={{ animationDelay: `${delay}s` }}>
        <span className="text-green-400">[✓]</span> {text}
    </p>
);

const DailyBriefingScreen: React.FC<DailyBriefingScreenProps> = ({ briefing, userName, onComplete }) => {
  const [stage, setStage] = useState<InitStage>('connecting');

  useEffect(() => {
    const timers: number[] = [];
    timers.push(window.setTimeout(() => setStage('personalizing'), 2000));
    timers.push(window.setTimeout(() => setStage('briefing'), 5500));
    timers.push(window.setTimeout(() => setStage('ready'), 8000));
    return () => timers.forEach(clearTimeout);
  }, []);

  const systemChecks = [
    'INITIALIZING TASK MODULE',
    'CONFIGURING NOTE MATRIX',
    'SYNCING FOCUS PROTOCOLS',
    'LOADING AI COGNITIVE CORE',
  ];

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-8 bg-slate-900 text-white font-mono overflow-hidden">
        <div className="init-grid-bg" />

        <div className="relative w-full max-w-3xl text-center z-10">
            {/* Stage 1: Connecting */}
            <div className={`transition-opacity duration-1000 ${stage === 'connecting' ? 'opacity-100' : 'opacity-0'}`}>
                <h1 className="text-2xl text-cyan-300 tracking-widest init-text">ESTABLISHING SECURE CONNECTION...</h1>
            </div>

            {/* Stage 2: Personalizing */}
            <div className={`absolute inset-0 transition-opacity duration-1000 ${stage === 'personalizing' ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                 <h1 className="text-2xl text-cyan-300 tracking-widest init-text">
                    CALIBRATING WORKSPACE FOR <span className="text-yellow-400">{userName}</span>...
                </h1>
                <div className="mt-6 text-left max-w-md mx-auto text-slate-400">
                    {systemChecks.map((text, i) => (
                        <SystemCheckItem key={text} text={text} delay={i * 0.4} />
                    ))}
                </div>
            </div>

            {/* Stage 3 & 4: Briefing & Ready */}
            <div className={`transition-opacity duration-1000 ${stage === 'briefing' || stage === 'ready' ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                <div className="w-20 h-20 mb-6 mx-auto rounded-2xl bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center text-white font-bold text-5xl shadow-lg init-logo-pulse">
                    P
                </div>
                <div className="space-y-3 animate-fade-in-up">
                    {briefing.priorityTask && (
                        <div>
                            <p className="text-sm text-yellow-400 tracking-widest">PRIORITY FOCUS</p>
                            <p className="text-2xl text-yellow-300">{briefing.priorityTask.title}</p>
                        </div>
                    )}
                     <div>
                        <p className="text-sm text-green-400 tracking-widest">PULSE INSIGHT</p>
                        <p className="text-lg text-green-300 max-w-xl mx-auto">{briefing.insight}</p>
                    </div>
                </div>

                 <button
                    onClick={onComplete}
                    className={`mt-12 px-8 py-3 text-lg bg-slate-800/50 border-2 border-slate-700 rounded-md backdrop-blur-sm hover:bg-slate-700/50 hover:border-slate-600 transition-all duration-500 focus:outline-none focus:ring-2 focus:ring-cyan-400 ${
                    stage === 'ready' ? 'opacity-100' : 'opacity-0'
                    }`}
                >
                    BEGIN SESSION
                </button>
            </div>
        </div>
    </div>
  );
};

export default DailyBriefingScreen;
