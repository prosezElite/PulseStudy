import { GoogleGenAI, FunctionDeclaration, Type, GenerateContentResponse, LiveServerMessage, Modality, Blob, } from '@google/genai';
import type { TaskPriority, ChatMessage, FocusSessionHistory, WeeklyPlan, Note, Quiz, Task, FocusNode, FocusLink, SessionRewindData, ConceptChallenge, Dream, QuizMode, KeyTimestamp } from '../types';
import { AI_SYSTEM_INSTRUCTION, AI_LIVE_SYSTEM_INSTRUCTION, AI_SOCRATIC_SYSTEM_INSTRUCTION, AI_TIME_TWIN_SYSTEM_INSTRUCTION, AI_QUANTUM_LEARNING_SYSTEM_INSTRUCTION, AI_STRESS_TEST_SYSTEM_INSTRUCTION } from '../constants';

const createTaskFunctionDeclaration: FunctionDeclaration = {
  name: 'createTask',
  parameters: {
    type: Type.OBJECT,
    description: 'Creates a new task with a title, priority, and optional due date.',
    properties: {
      title: {
        type: Type.STRING,
        description: 'The title of the task.',
      },
      priority: {
        type: Type.STRING,
        description: 'The priority of the task: high, medium, or low.',
        enum: ['high', 'medium', 'low'],
      },
      dueDate: {
        type: Type.NUMBER,
        description: 'The due date of the task as a Unix timestamp in milliseconds. For example, if a task is due tomorrow, calculate tomorrow\'s date and convert it to a timestamp.',
      },
    },
    required: ['title'],
  },
};


export async function getAIChatResponseStream(history: ChatMessage[], mode: 'direct' | 'socratic' | 'time-twin' | 'quantum') {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

    const systemInstructions = {
        'direct': AI_SYSTEM_INSTRUCTION,
        'socratic': AI_SOCRATIC_SYSTEM_INSTRUCTION,
        'time-twin': AI_TIME_TWIN_SYSTEM_INSTRUCTION,
        'quantum': AI_QUANTUM_LEARNING_SYSTEM_INSTRUCTION,
    };

    const contents = history.map(msg => {
        const parts: any[] = [];
        let messageText = msg.text;

        if (msg.file && !messageText) {
            messageText = `Analyze the attached file: ${msg.file.name}`;
        }
        
        if (messageText) {
            parts.push({ text: messageText });
        }
        
        if (msg.from === 'user' && msg.file) {
            parts.push({
                inlineData: {
                    mimeType: msg.file.type,
                    data: msg.file.dataUrl.split(',')[1],
                }
            });
        }
        
        if (parts.length === 0) {
            parts.push({ text: '' }); 
        }

        return {
            role: msg.from === 'user' ? 'user' : 'model',
            parts
        };
    });
    
    const stream = await ai.models.generateContentStream({
        model: 'gemini-2.5-flash',
        contents: contents,
        config: {
            systemInstruction: systemInstructions[mode],
            tools: [{ functionDeclarations: [createTaskFunctionDeclaration] }],
        }
    });

    return stream;
}

export async function connectToPulseLive(callbacks: {
    onopen: () => void;
    onmessage: (message: LiveServerMessage) => void;
    onerror: (e: ErrorEvent) => void;
    onclose: (e: CloseEvent) => void;
}) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

    const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks,
        config: {
            responseModalities: [Modality.AUDIO],
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            systemInstruction: AI_LIVE_SYSTEM_INSTRUCTION,
        },
    });

    return sessionPromise;
}

export async function getAIRating(xp: number, taskCount: number, focusTime: number, noteCount: number): Promise<number> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `
        Calculate a student's "AI Rating" based on these stats:
        - XP: ${xp}
        - Total tasks created: ${taskCount}
        - Total focus minutes: ${focusTime}
        - Total notes created: ${noteCount}
        The rating should be between 1,000 and 10,000.
        Provide only the final number.
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });

    const rating = parseInt(response.text.replace(/,/g, ''), 10);
    return isNaN(rating) ? 1000 : Math.max(1000, Math.min(10000, rating));
}

export async function getAIRatingAdjustment(xp: number, tasks: Task[], focusTime: number, noteCount: number): Promise<{ adjustment: number; reason: string }> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `
        Analyze a student's recent productivity data to determine a "Quantum Calibration" adjustment for their AI Rating.
        - Current XP: ${xp}
        - Recent Tasks (last 5): ${JSON.stringify(tasks.slice(0, 5).map(t => ({ title: t.title, done: t.done })))}
        - Total Focus Minutes: ${focusTime}
        - Total Notes: ${noteCount}
        
        Based on this, determine a rating adjustment (between -500 and +500).
        Also, provide a short, one-sentence "reason" for this adjustment in an encouraging or analytical tone.
        For example, if they completed many tasks, the reason could be "High task completion velocity detected."
        If they have low focus time, "Focus matrix shows potential for deeper engagement."

        Return ONLY a JSON object with "adjustment" (number) and "reason" (string).
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    adjustment: { type: Type.NUMBER },
                    reason: { type: Type.STRING },
                },
                required: ['adjustment', 'reason'],
            },
        }
    });
    
    try {
        const result = JSON.parse(response.text);
        return {
            adjustment: result.adjustment || 0,
            reason: result.reason || "System recalibrated based on recent activity."
        };
    } catch (e) {
        console.error("Failed to parse AI rating adjustment:", e);
        return { adjustment: 0, reason: "Nominal activity detected. Calibration stable." };
    }
}

export async function getAIMathResponse(problem: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `Solve the following math problem and provide a step-by-step explanation. Format the final answer clearly. Problem: "${problem}"`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
    });
    return response.text;
}

export async function generateCode(prompt: string): Promise<{ html: string, css: string, js: string, explanation: string }> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const fullPrompt = `
        Generate HTML, CSS, and JavaScript code for the following request: "${prompt}".
        Provide a brief explanation of how the code works.
        The HTML should be within a <body> tag.
        The CSS should be complete.
        The JavaScript should be functional and self-contained.
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: fullPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    html: { type: Type.STRING },
                    css: { type: Type.STRING },
                    js: { type: Type.STRING },
                    explanation: { type: Type.STRING },
                },
                required: ['html', 'css', 'js', 'explanation'],
            },
        }
    });
    
    return JSON.parse(response.text);
}


export async function generateStudyPlan({ history, timezone, availability, goals, currentDay }: {
    history: FocusSessionHistory[],
    timezone: string,
    availability: string,
    goals: string,
    currentDay: string,
}): Promise<WeeklyPlan> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `
        Create a 7-day study plan for a student based on this data:
        - Recent study history: ${JSON.stringify(history.slice(-10))}
        - Timezone: ${timezone}
        - Availability: "${availability}"
        - Weekly Goals: "${goals}"
        - Today is: ${currentDay}

        The plan should be realistic, incorporating breaks and aligning with their stated goals.
        Distribute study sessions logically across the week starting from today.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    Monday: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, activity: { type: Type.STRING } } } },
                    Tuesday: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, activity: { type: Type.STRING } } } },
                    Wednesday: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, activity: { type: Type.STRING } } } },
                    Thursday: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, activity: { type: Type.STRING } } } },
                    Friday: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, activity: { type: Type.STRING } } } },
                    Saturday: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, activity: { type: Type.STRING } } } },
                    Sunday: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, activity: { type: Type.STRING } } } },
                }
            }
        }
    });
    
    return JSON.parse(response.text);
}

export async function scanNoteWithOCR(imageDataUrl: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const imagePart = {
      inlineData: {
        mimeType: 'image/jpeg',
        data: imageDataUrl.split(',')[1],
      },
    };
    const textPart = { text: "Extract the handwritten text from this image." };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] },
    });
    return response.text;
}

export async function generateQuiz(note: Note, mode: QuizMode): Promise<Quiz> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `
        Based on the following note, create a quiz with 5 questions.
        The quiz mode is '${mode}'. For 'stress-test' mode, make the questions more conceptual, abstract, or require multi-step reasoning. For 'standard' mode, focus on key facts and definitions.
        Include a mix of multiple-choice and true/false questions.
        For each question, provide a brief explanation for the correct answer.

        Note Title: "${note.title}"
        Note Body:
        ---
        ${note.body}
        ---
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    questions: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                questionText: { type: Type.STRING },
                                type: { type: Type.STRING, enum: ['multiple-choice', 'true-false'] },
                                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                                answer: { type: Type.STRING },
                                explanation: { type: Type.STRING },
                            },
                            required: ['questionText', 'type', 'answer', 'explanation'],
                        },
                    },
                },
                required: ['title', 'questions'],
            },
        }
    });
    
    return JSON.parse(response.text);
}

export async function getProactiveInsights(tasks: any[], focusHistory: any[]): Promise<string[]> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `
        Analyze the student's recent productivity data:
        - Today's tasks: ${JSON.stringify(tasks.slice(0, 5))}
        - Recent focus sessions: ${JSON.stringify(focusHistory.slice(-5))}
        
        Provide 2-3 brief, actionable, and encouraging "Pulse Insights" in a conversational tone.
        Focus on patterns, like upcoming deadlines, focus session consistency, or task priorities.
        For example: "Your Chemistry midterm is in in 5 days, but you've only had one focus session on it. Want to schedule two more?"
        or "I noticed you added three tasks related to 'Calculus'. Would you like me to create a 'Calculus' note to centralize your thoughts?"
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    insights: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                    },
                },
                required: ['insights'],
            },
        }
    });

    const json = JSON.parse(response.text);
    return json.insights || [];
}


export async function generateMindMapSuggestions(centralTopic: string, existingNodes: string[]): Promise<string[]> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `Based on the central topic "${centralTopic}" and the existing ideas [${existingNodes.join(', ')}], brainstorm 3-5 related sub-topics or concepts to expand this mind map. Provide only the new ideas.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['suggestions'],
        },
      },
    });

    const json = JSON.parse(response.text);
    return json.suggestions || [];
  } catch (error) {
    console.error("Error generating mind map suggestions:", error);
    throw new Error("The AI failed to generate suggestions. Please try again.");
  }
}

export async function getBurnoutSuggestion(history: FocusSessionHistory[]): Promise<string> {
   try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const systemInstruction = "You are a caring and empathetic wellness assistant in a student productivity app. Your goal is to notice when a student might be overworking and gently encourage them to take a break for their well-being, without being alarming. Frame your suggestions positively.";

    // Simple analysis of recent history
    const recentSessions = history.slice(-10); // Look at last 10 sessions
    const prompt = `A student's recent focus session history is: ${JSON.stringify(recentSessions)}. Based on this, it looks like they might be studying late or for very long periods. Write a short, kind, and encouraging message (2-3 sentences) suggesting they take a well-deserved break. Mention the benefits of resting for learning and productivity.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.8,
      },
    });
    
    return response.text;
  } catch (error) {
    console.error("Error generating burnout suggestion:", error);
    return "It looks like you've been working hard! Remember that taking short breaks can actually boost your focus and help you learn better. Great job on the dedication!";
  }
}

export async function getAISummary(content: { text?: string; image?: string }): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    
    const parts: any[] = [];
    
    if (content.image) {
        parts.push({
            inlineData: {
                mimeType: content.image.substring(content.image.indexOf(':') + 1, content.image.indexOf(';')),
                data: content.image.split(',')[1],
            },
        });
    }

    if (content.text) {
        parts.push({ text: `Please provide a concise summary of the following text:\n\n${content.text}` });
    } else if (content.image) {
        parts.push({ text: "Please provide a concise summary of the text in this image." });
    } else {
        throw new Error("No content provided to summarize.");
    }

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts },
    });

    return response.text;
}

export async function getResearchAssistantResponse(topic: string): Promise<{ text: string; sources: any[] }> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `Provide a detailed explanation and find relevant, high-quality, free, and legally available educational materials online for the topic: "${topic}". Prioritize open-source textbooks, university lecture notes, and public-domain PDFs. Format your response in markdown.`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });

    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    return { text: response.text, sources };
}


// --- NEW FEATURE SERVICES ---

export async function getConceptStressTest(topic: string): Promise<ConceptChallenge> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `My topic is: "${topic}"`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction: AI_STRESS_TEST_SYSTEM_INSTRUCTION,
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    challenge: { type: Type.STRING },
                    hint: { type: Type.STRING },
                },
                required: ['challenge', 'hint'],
            },
        }
    });
    return JSON.parse(response.text);
}


export async function getSemanticConnections(tasks: Task[], notes: Note[]): Promise<{ nodes: FocusNode[], links: FocusLink[] }> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

    const content = `
        Tasks: ${JSON.stringify(tasks.map(t => ({ id: `task-${t.id}`, title: t.title })))}
        Notes: ${JSON.stringify(notes.map(n => ({ id: `note-${n.id}`, title: n.title, body: n.body.substring(0, 100) })))}
    `;

    const prompt = `
        Analyze the following tasks and notes. Identify semantic connections between them based on shared topics or keywords.
        Return a list of links between item IDs. For example, if a task and a note are both about "Calculus", link them.
        Only link items with a strong thematic connection. Link tasks to notes, notes to notes, or tasks to tasks. Max 10 links.
        Content:
        ${content}
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    links: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                source: { type: Type.STRING, description: "The ID of the source item (e.g., 'task-123')." },
                                target: { type: Type.STRING, description: "The ID of the target item (e.g., 'note-456')." },
                            },
                        },
                    },
                },
            },
        }
    });

    const nodes: FocusNode[] = [
        ...tasks.map(t => ({ id: `task-${t.id}`, label: t.title, type: 'task' as const, x: 0, y: 0, vx: 0, vy: 0 })),
        ...notes.map(n => ({ id: `note-${n.id}`, label: n.title, type: 'note' as const, x: 0, y: 0, vx: 0, vy: 0 })),
    ];
    const links = JSON.parse(response.text).links || [];

    return { nodes, links };
}

export async function generateSessionSummary(session: FocusSessionHistory, tasks: Task[], notes: Note[]): Promise<SessionRewindData> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

    const relevantTasks = tasks.filter(t => t.created >= session.startTime && t.created <= session.endTime);
    const relevantNotes = notes.filter(n => n.created >= session.startTime && n.created <= session.endTime);

    const prompt = `
        A student just completed a focus session lasting ${Math.round((session.endTime - session.startTime) / 60000)} minutes.
        During this time, they worked on tasks and created notes.

        Tasks created: ${JSON.stringify(relevantTasks.map(t => t.title))}
        Notes created: ${JSON.stringify(relevantNotes.map(n => ({ id: n.id, title: n.title, body: n.body.substring(0, 150) })))}
        
        Please provide the following in JSON format:
        1. A brief, exciting, one-sentence "summary" of their accomplishment for a cinematic replay.
           Example: "In a 45-minute sprint, you laid the groundwork for your history essay and outlined key concepts!"
        2. An array called "noteKeyPhrases" where each object contains the "noteId" and a single, impactful "keyPhrase" (max 5 words) extracted from that note's body.
    `;

    const response = await ai.models.generateContent({ 
        model: 'gemini-2.5-flash', 
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    summary: { type: Type.STRING },
                    noteKeyPhrases: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                noteId: { type: Type.STRING },
                                keyPhrase: { type: Type.STRING }
                            }
                        }
                    }
                }
            }
        }
    });

    const result = JSON.parse(response.text);
    
    const keyEvents = [
        ...relevantTasks.map(t => ({ time: t.created, text: `Task created: ${t.title}`, type: 'task' as const })),
        ...relevantNotes.map(n => {
            const analysis = result.noteKeyPhrases?.find((na: any) => na.noteId === n.id);
            return { 
                time: n.created, 
                text: `Note started: ${n.title}`, 
                type: 'note' as const,
                keyPhrase: analysis?.keyPhrase || n.title // Fallback to title
            };
        }),
    ].sort((a, b) => a.time - b.time);

    return {
        summary: result.summary || "You had a great focus session!",
        keyEvents,
    };
}

export async function getAICollaborationSuggestion(goal: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `A study group is working on the goal: "${goal}". Provide one helpful suggestion, question, or piece of information to facilitate their discussion. Keep it concise.`;
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
    return response.text;
}

export async function generateSpeech(text: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: `Say with a slightly excited and encouraging tone: ${text}` }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
            throw new Error("No audio data returned from TTS API.");
        }
        return base64Audio;
    } catch (error) {
        console.error("Error generating speech:", error);
        throw new Error("Failed to generate AI voice-over.");
    }
}

export async function generate3DModelCode(prompt: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const fullPrompt = `
        Generate a single, self-contained HTML file that uses Three.js to render a 3D model based on the following prompt: "${prompt}".

        **Requirements:**
        1.  **Self-Contained:** All HTML, CSS, and JavaScript must be in a single HTML file. Do not use external file links.
        2.  **Three.js:** Use the Three.js library. You MUST use an import map to import it and OrbitControls from a reliable CDN, for example:
            <script type="importmap">
              {
                "imports": {
                  "three": "https://unpkg.com/three@0.166.0/build/three.module.js",
                  "three/addons/": "https://unpkg.com/three@0.166.0/examples/jsm/"
                }
              }
            </script>
        3.  **Camera Controls:** Include OrbitControls for interactivity. The camera should be positioned to view the model.
        4.  **Lighting:** The scene must have adequate lighting (e.g., AmbientLight, DirectionalLight).
        5.  **Responsive:** The canvas should fill the browser window and resize correctly.
        6.  **Model:** Create a 3D model that accurately represents the prompt. Use basic geometries (BoxGeometry, SphereGeometry, CylinderGeometry, etc.) and materials (MeshStandardMaterial, etc.) to construct the model. For complex shapes, be creative with combinations of simple geometries.
        7.  **No External Models:** Do not use any external 3D model files (e.g., .gltf, .obj). The model MUST be constructed with Three.js geometry.
        8.  **Return ONLY the HTML code.** Do not include any other text or markdown formatting like \`\`\`html.
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: fullPrompt,
    });
    
    const text = response.text;
    const codeBlockMatch = text.match(/```(?:html)?\s*([\s\S]*?)```/);
    if (codeBlockMatch && codeBlockMatch[1]) {
        return codeBlockMatch[1];
    }
    return text;
}

export async function generateImage(prompt: string, aspectRatio: string) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt,
        config: {
            numberOfImages: 1,
            outputMimeType: 'image/jpeg',
            aspectRatio: aspectRatio as "1:1" | "3:4" | "4:3" | "9:16" | "16:9",
        },
    });
    return response.generatedImages[0].image.imageBytes;
}

export async function startVideoGeneration(prompt: string, note: Note | null) {
    // This function must be called from a context where the API key is already selected via window.aistudio
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const finalPrompt = note ? `Create a short educational video based on the following note. Prompt: ${prompt}. Note Title: ${note.title}. Note Content: ${note.body.substring(0, 500)}` : prompt;
    
    const operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: finalPrompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });
    return operation;
}

export async function checkVideoOperation(operation: any) {
    // This function must be called from a context where the API key is already selected via window.aistudio
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const updatedOperation = await ai.operations.getVideosOperation({ operation });
    return updatedOperation;
}

export async function analyzeDreamCorrelations(dreams: Dream[], tasks: Task[], notes: Note[]): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `
        A student is logging their dreams and their study topics. Analyze for potential symbolic or thematic connections.
        This is for fun and inspiration, not a scientific analysis. Be creative and insightful.
        
        Recent Dreams:
        ${dreams.slice(-3).map(d => `- "${d.content}"`).join('\n')}

        Current Tasks & Notes:
        ${tasks.slice(0, 5).map(t => `- Task: ${t.title}`).join('\n')}
        ${notes.slice(0, 3).map(n => `- Note: ${n.title}`).join('\n')}

        Provide a short, interesting analysis (2-3 sentences) connecting one dream to one study topic.
    `;
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
    return response.text;
}

export async function getDejaLearnQuestion(item: Task | Note): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const itemType = 'done' in item ? 'task' : 'note';
    const content = `Title: ${item.title}` + (itemType === 'note' ? `\nBody: ${(item as Note).body.substring(0, 200)}` : '');
    
    const prompt = `
        Based on the following ${itemType}, generate a single, short question to test the user's memory of it.
        The question should be concise and focused on a key piece of information.
        
        Content:
        ---
        ${content}
        ---

        Return only the question text.
    `;
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
    return response.text;
}

export async function summarizeYouTubeVideo(videoUrl: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `Based on the title and topic of this YouTube video URL, please provide a concise summary of its likely educational content. URL: "${videoUrl}"`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
}

export async function generateQuizFromYouTubeVideo(videoUrl: string, questionCount: number = 5): Promise<Quiz> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `You are a teacher creating a quiz. Based on the likely educational content of a YouTube video with this URL, create a quiz with ${questionCount} questions to test comprehension. Include a mix of multiple-choice and true/false questions. For each question, provide a brief explanation for the correct answer. URL: "${videoUrl}"`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    questions: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                questionText: { type: Type.STRING },
                                type: { type: Type.STRING, enum: ['multiple-choice', 'true-false'] },
                                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                                answer: { type: Type.STRING },
                                explanation: { type: Type.STRING },
                            },
                            required: ['questionText', 'type', 'answer', 'explanation'],
                        },
                    },
                },
                required: ['title', 'questions'],
            },
        }
    });
    
    return JSON.parse(response.text);
}

export async function getKeyTimestampsFromYouTubeVideo(videoUrl: string): Promise<{ timestamps: KeyTimestamp[] }> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const prompt = `Analyze the likely content of a YouTube video from this URL: "${videoUrl}". Identify 5-7 key moments or topics. For each, provide a timestamp (e.g., "1:23") and a brief, one-sentence description of what is being discussed.`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    timestamps: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                time: { type: Type.STRING },
                                description: { type: Type.STRING },
                            },
                            required: ['time', 'description'],
                        }
                    }
                },
                required: ['timestamps'],
            },
        }
    });
    return JSON.parse(response.text);
}