import type { GenerateContentResponse } from '@google/genai';

export interface Rank {
  name: 'CALIBRATING' | 'IRON' | 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM' | 'DIAMOND' | 'MASTER' | 'SPECIAL' | 'ELITE';
  min: number;
  max: number;
  badgeColors: string[];
  icon: string;
  animationClass?: string;
  description?: string;
}

export interface Task {
  id: string;
  title: string;
  done: boolean;
  priority: TaskPriority;
  created: number;
  dueDate?: number;
  reminder?: number; // Timestamp for the reminder
  reminderSent?: boolean; // Flag to prevent duplicate notifications
}

export type TaskPriority = 'high' | 'medium' | 'low';

export interface NoteFile {
    name: string;
    type: string;
    dataUrl: string; // base64 encoded
}

export interface Note {
  id: string;
  title: string;
  body: string;
  created: number;
  file?: NoteFile;
}

export interface PomodoroSession {
  completed: number;
  total: number;
}

export interface PomodoroTheme {
    id: string;
    name: string;
    background: string;
    class: string;
}

export interface FocusSessionHistory {
    startTime: number;
    endTime: number;
    date: string; // YYYY-MM-DD
}

export interface ChatMessage {
  text: string;
  from: 'user' | 'ai';
  file?: NoteFile;
}

export interface Track {
    title: string;
    artist: string;
    albumArt: string;
    audioSrc: string;
}

export interface WeeklyPlan {
    [day: string]: { time: string; activity: string }[];
}

export interface Quiz {
    title: string;
    questions: Question[];
}

export type QuizMode = 'standard' | 'stress-test';

export interface Question {
    questionText: string;
    type: 'multiple-choice' | 'true-false' | 'fill-in-the-blank';
    options?: string[];
    answer: string;
    explanation: string;
}

export interface StudyPodMember {
    name: string;
    avatar: string;
    isYou: boolean;
    focusStreak: number;
    isLeader: boolean;
}

export interface StudyPod {
    isActive: boolean;
    goal: string;
    members: StudyPodMember[];
}

export interface MindMapNode {
  id: string;
  text: string;
  parentId: string | null;
  x: number;
  y: number;
  width?: number;
  height?: number;
}

export interface MindMap {
  id: string;
  title: string;
  nodes: MindMapNode[];
  created: number;
}

export interface LiveTranscriptionTurn {
  id: number;
  user: string;
  ai: string;
}

// --- NEW FEATURE TYPES ---
export interface CognitiveLoadData {
    load: number; // 0 to 1
    message: string;
}

export interface DailyBriefing {
  priorityTask: Task | null;
  insight: string;
}

export interface Dream {
  id: string;
  date: number;
  content: string;
  analysis?: string;
}

export interface DailyLog {
  id: string;
  date: string; // YYYY-MM-DD
  sleepHours: number;
  mood: 'great' | 'good' | 'okay' | 'bad' | 'awful';
}

export interface DejaLearnItem {
  type: 'note' | 'task';
  item: Note | Task;
  memoryDecay: number; // 0 to 1, higher is more forgotten
}

export interface FocusNode {
    id: string;
    label: string;
    type: 'task' | 'note';
    x: number;
    y: number;
    vx: number;
    vy: number;
}
export interface FocusLink {
    source: string;
    target: string;
}

export interface SessionRewindData {
    summary: string;
    keyEvents: { 
        time: number; 
        text: string; 
        type: 'task' | 'note' | 'ai';
        keyPhrase?: string;
    }[];
}

export interface ConceptChallenge {
    challenge: string;
    hint: string;
}

export interface KeyTimestamp {
    time: string; // e.g., "2:35"
    description: string;
}

export interface YouTubeBookmark {
  url: string;
  videoId: string;
  note: string;
  date: number;
}

export type ModalContentType =
  | 'note'
  | 'ranks'
  | 'stats'
  | 'build'
  | 'calculator'
  | 'graphingCalculator'
  | 'aiRatingInfo'
  | 'fileEditor'
  | 'fullScreenPomodoro'
  | 'leaderboard'
  | 'quiz'
  | 'studyPodSetup'
  | 'mindMap'
  | 'wellBeing'
  | 'summarizer'
  | 'welcomeEmail'
  | 'legal'
  | 'focusFlow'
  | 'sessionRewind'
  | 'collaborationCanvas'
  | 'conceptStressTest'
  | 'imageStudio'
  | 'videoStudio'
  | 'pulseMarketplace'
  | 'dreamJournal'
  | 'dailyLog'
  | 'dejaLearn'
  | 'globalPulseMesh'
  | 'pulseLive'
  | 'researchAssistant'
  | 'studyYoutube';

export type ModalContent = {
  type: ModalContentType;
  data?: any;
};