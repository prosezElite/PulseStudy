
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';

// Components
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import TasksSection from './components/TasksSection';
import NotesSection from './components/NotesSection';
import QuickTools from './components/QuickTools';
import Footer from './components/Footer';
import AiChatButton from './components/AiChatButton';
import AiSolver from './components/AiSolver';
import MusicController from './components/MusicController';
import LoginScreen from './components/LoginScreen';

// Modals
import NoteModal from './components/modals/NoteModal';
import RanksModal from './components/modals/RanksModal';
import StatsModal from './components/modals/StatsModal';
import BuildModal from './components/modals/BuildModal';
import CalculatorModal from './components/modals/CalculatorModal';
import GraphingCalculatorModal from './components/modals/GraphingCalculatorModal';
import AIRatingInfoModal from './components/modals/AIRatingInfoModal';
import FileEditorModal from './components/modals/FileEditorModal';
import FullScreenPomodoroModal from './components/modals/FullScreenPomodoroModal';
import LeaderboardModal from './components/modals/LeaderboardModal';
import QuizModal from './components/modals/QuizModal';
import StudyPodSetupModal from './components/modals/StudyPodSetupModal';
import MindMapModal from './components/modals/MindMapModal';
import WellBeingModal from './components/modals/WellBeingModal';
import SummarizerModal from './components/modals/SummarizerModal';
import WelcomeEmailModal from './components/modals/WelcomeEmailModal';
import LegalModal from './components/modals/LegalModal';
import PulseLiveModal from './components/modals/PulseLiveModal';
import FocusFlowModal from './components/modals/FocusFlowModal';
import SessionRewindModal from './components/modals/SessionRewindModal';
import CollaborationCanvasModal from './components/modals/CollaborationCanvasModal';
import ConceptStressTestModal from './components/modals/ConceptStressTestModal';
import ImageStudioModal from './components/modals/ImageStudioModal';
import VideoStudioModal from './components/modals/VideoStudioModal';
import PulseMarketplaceModal from './components/modals/PulseMarketplaceModal';
import DreamJournalModal from './components/modals/DreamJournalModal';
import DailyLogModal from './components/modals/DailyLogModal';
import DejaLearnModal from './components/modals/DejaLearnModal';
import GlobalPulseMeshModal from './components/modals/GlobalPulseMeshModal';
import ResearchAssistantModal from './components/modals/ResearchAssistantModal';
import StudyYoutubeModal from './components/modals/StudyYoutubeModal';

// Hooks, Types, Constants, Services
import { useLocalStorage } from './hooks/useLocalStorage';
import { ranks } from './constants';
import { getAIRating, getProactiveInsights, getBurnoutSuggestion, scanNoteWithOCR } from './services/geminiService';
import type { 
  Task, TaskPriority, Note, Rank, ModalContent, PomodoroSession, NoteFile, StudyPod, MindMap, ModalContentType, CognitiveLoadData, Dream, DailyLog, FocusSessionHistory 
} from './types';

export type Theme = 'light' | 'dark';

function App() {
  // === PERSISTENT STATE ===
  const [userName, setUserName] = useLocalStorage<string>('pulse-userName', '');
  const [userEmail, setUserEmail] = useLocalStorage<string>('pulse-userEmail', '');
  const [tasks, setTasks] = useLocalStorage<Task[]>('pulse-tasks', []);
  const [notes, setNotes] = useLocalStorage<Note[]>('pulse-notes', []);
  const [xp, setXp] = useLocalStorage<number>('pulse-xp', 0);
  const [focusSessionHistory, setFocusSessionHistory] = useLocalStorage<FocusSessionHistory[]>('pulse-focusHistory', []);
  const [pomodoroSession, setPomodoroSession] = useLocalStorage<PomodoroSession>('pulse-pomodoroSession', { completed: 0, total: 4 });
  const [pulseCredits, setPulseCredits] = useLocalStorage<number>('pulse-credits', 1000);
  const [mindMaps, setMindMaps] = useLocalStorage<MindMap[]>('pulse-mindMaps', []);
  const [dreams, setDreams] = useLocalStorage<Dream[]>('pulse-dreams', []);
  const [dailyLogs, setDailyLogs] = useLocalStorage<DailyLog[]>('pulse-dailyLogs', []);
  const [theme, setTheme] = useLocalStorage<Theme>('pulse-theme', 'light');
  const [hasSeenWelcome, setHasSeenWelcome] = useLocalStorage<boolean>('pulse-hasSeenWelcome', false);

  // === SESSION STATE ===
  const [modalContent, setModalContent] = useState<ModalContent | null>(null);
  const [showMusicPlayer, setShowMusicPlayer] = useState(false);
  const [showAiSolver, setShowAiSolver] = useState(false);
  const [aiRating, setAiRating] = useState(0);
  const [burnoutSuggestion, setBurnoutSuggestion] = useState('');
  const [studyPod, setStudyPod] = useState<StudyPod>({ isActive: false, goal: '', members: [] });

  // Pomodoro state
  const [pomodoroDuration, setPomodoroDuration] = useLocalStorage<number>('pulse-pomodoroDuration', 25);
  const [breakDuration, setBreakDuration] = useLocalStorage<number>('pulse-breakDuration', 5);
  const [isBreak, setIsBreak] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(pomodoroDuration * 60);
  const [isPomodoroRunning, setIsPomodoroRunning] = useState(false);
  const pomodoroStartTime = useRef<number | null>(null);
  
  // Cognitive Load state (simulated)
  const [cognitiveLoad, setCognitiveLoad] = useState<CognitiveLoadData>({ load: 0, message: 'Ready to focus' });
  
  const addXp = useCallback((amount: number) => setXp(prev => prev + amount), [setXp]);
  const addCredits = useCallback((amount: number) => setPulseCredits(prev => prev + amount), [setPulseCredits]);

  // === DERIVED STATE ===
  const rank: Rank = useMemo(() => {
    return ranks.find(r => xp >= r.min && xp <= r.max) ?? ranks[0];
  }, [xp]);
  const focusTime = useMemo(() => Math.round(focusSessionHistory.reduce((acc, s) => acc + (s.endTime - s.startTime), 0) / 60000), [focusSessionHistory]);

  // === EFFECTS ===
  
  // Theme controller
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);
  
  // AI Rating calculator
  useEffect(() => {
    const calculateAIRating = async () => {
        if(userName) {
            const rating = await getAIRating(xp, tasks.length, focusTime, notes.length);
            setAiRating(rating);
        }
    };
    calculateAIRating();
  }, [xp, tasks.length, focusTime, notes.length, userName]);

  // Pomodoro Timer
  useEffect(() => {
    let interval: number | null = null;
    if (isPomodoroRunning && secondsLeft > 0) {
        interval = window.setInterval(() => {
            setSecondsLeft(s => s - 1);
        }, 1000);
    } else if (isPomodoroRunning && secondsLeft === 0) {
        if (isBreak) { // Break has finished
            setIsPomodoroRunning(false); // Stop timer
            setIsBreak(false);
            setSecondsLeft(pomodoroDuration * 60);
            new Notification('PulseStudy', { body: "Break's over! Time for the next focus session." });
        } else { // Focus session has finished
            // Log focus session
            setPomodoroSession(s => ({ ...s, completed: s.completed + 1 }));
            addXp(100);
            addCredits(25);
            const sessionEndTime = Date.now();
            if (pomodoroStartTime.current) {
                setFocusSessionHistory(prev => [...prev, { startTime: pomodoroStartTime.current, endTime: sessionEndTime, date: new Date(sessionEndTime).toISOString().split('T')[0] }]);
            }
            pomodoroStartTime.current = null;
            new Notification('PulseStudy', { body: 'Pomodoro session complete! Time for a short break.' });

            // Start break
            setIsBreak(true);
            setSecondsLeft(breakDuration * 60);
            // setIsPomodoroRunning(true); // This would automatically start the break timer
        }
    }
    return () => {
        if (interval) clearInterval(interval);
    };
  }, [isPomodoroRunning, secondsLeft, pomodoroDuration, breakDuration, isBreak, addXp, addCredits, setFocusSessionHistory, setPomodoroSession]);

  
  // Update timer duration when changed
  useEffect(() => {
    if (!isPomodoroRunning) {
        setSecondsLeft(isBreak ? breakDuration * 60 : pomodoroDuration * 60);
    }
  }, [pomodoroDuration, breakDuration, isBreak]);
  
  // Cognitive Load Simulation
  useEffect(() => {
    let interval: number | null = null;
    if (isPomodoroRunning && !isBreak) {
        interval = window.setInterval(() => {
            const sessionProgress = ((pomodoroDuration * 60) - secondsLeft) / (pomodoroDuration * 60);
            let load = Math.min(1, sessionProgress * 1.5);
            let message = 'Deep focus initiated.';
            if (load > 0.4) message = 'Maintaining cognitive flow.';
            if (load > 0.7) message = 'High cognitive load detected.';
            if (load > 0.9) message = 'Cognitive peak. Consider a break soon.';
            setCognitiveLoad({ load, message });
        }, 2000);
    } else {
      setCognitiveLoad(cl => ({ load: Math.max(0, cl.load - 0.1), message: 'Resting state.' }));
    }
    return () => {
        if(interval) clearInterval(interval);
    }
  }, [isPomodoroRunning, isBreak, secondsLeft, pomodoroDuration]);
  
  // === HANDLERS ===
  const handleOpenModal = (type: ModalContentType, data: any = null) => setModalContent({ type, data });
  const handleCloseModal = () => setModalContent(null);
  
  const handleAddTask = (title: string, priority: TaskPriority, dueDate?: number, reminder?: number) => {
    const newTask: Task = { id: Date.now().toString(), title, priority, done: false, created: Date.now(), dueDate, reminder };
    setTasks(prev => [newTask, ...prev]);
    addXp(10);
  };

  const handleToggleTask = (id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        if (!t.done) {
          addXp(25);
          addCredits(5);
        }
        return { ...t, done: !t.done };
      }
      return t;
    }));
  };
  
  const handleDeleteTask = (id: string) => setTasks(prev => prev.filter(t => t.id !== id));
  const handleUpdateTaskPriority = (id: string, priority: TaskPriority) => setTasks(prev => prev.map(t => t.id === id ? { ...t, priority } : t));
  
  const handleSaveNote = (note: Note) => {
    setNotes(prev => {
        const exists = prev.some(n => n.id === note.id);
        if (exists) {
            return prev.map(n => n.id === note.id ? note : n);
        }
        addXp(20);
        addCredits(10);
        return [note, ...prev];
    });
    handleCloseModal();
  };
  
  const handleDeleteNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
    handleCloseModal();
  };
  
  const handleNoteScanned = async (imageData: string) => {
    handleOpenModal('note'); // Open an empty note modal
    try {
        const text = await scanNoteWithOCR(imageData);
        handleSaveNote({ id: Date.now().toString(), title: 'Scanned Note', body: text, created: Date.now(), file: { name: 'scan.jpg', type: 'image/jpeg', dataUrl: imageData } });
    } catch(e) {
        console.error("OCR failed", e);
        handleSaveNote({ id: Date.now().toString(), title: 'Scanned Note (OCR Failed)', body: 'Could not extract text.', created: Date.now(), file: { name: 'scan.jpg', type: 'image/jpeg', dataUrl: imageData } });
    }
  };
  
  const handleSignUp = (name: string, email: string) => {
    setUserName(name);
    setUserEmail(email);
    if (!hasSeenWelcome) {
        handleOpenModal('welcomeEmail');
        setHasSeenWelcome(true);
    }
  };

  const handleGenerateInsights = () => getProactiveInsights(tasks, focusSessionHistory);
  
  const handleWellBeingCheck = async () => {
    const suggestion = await getBurnoutSuggestion(focusSessionHistory);
    setBurnoutSuggestion(suggestion);
    handleOpenModal('wellBeing');
  };

  const pomodoroControls = {
    duration: pomodoroDuration,
    setDuration: setPomodoroDuration,
    breakDuration: breakDuration,
    setBreakDuration: (d: number) => setBreakDuration(Math.max(1, Math.min(15, d))),
    secondsLeft,
    isRunning: isPomodoroRunning,
    setIsRunning: (running: boolean) => {
      if(running && !pomodoroStartTime.current && !isBreak) pomodoroStartTime.current = Date.now();
      if(!running && !isBreak) pomodoroStartTime.current = null; // Paused, reset start time
      setIsPomodoroRunning(running);
    },
    reset: () => {
        setIsPomodoroRunning(false);
        setIsBreak(false);
        setSecondsLeft(pomodoroDuration * 60);
        pomodoroStartTime.current = null;
    },
    session: pomodoroSession,
    setSession: setPomodoroSession,
    openFullScreen: () => handleOpenModal('fullScreenPomodoro'),
    isBreak: isBreak,
  };
  
  // === RENDER LOGIC ===
  if (!userName) {
    return <LoginScreen setUserName={setUserName} onSignUp={handleSignUp} />;
  }

  return (
    <>
      <Header 
        theme={theme}
        setTheme={setTheme}
        xp={xp}
        pulseCredits={pulseCredits}
        onToggleMusicPlayer={() => setShowMusicPlayer(p => !p)}
      />
      <main className="max-w-7xl mx-auto px-4 sm:px-8 py-24 space-y-6">
        <Dashboard 
          userName={userName}
          taskCount={tasks.length}
          noteCount={notes.length}
          focusTime={focusTime}
          xp={xp}
          rank={rank}
          onOpenModal={handleOpenModal}
          aiRating={aiRating}
          pomodoro={pomodoroControls}
          onGenerateInsights={handleGenerateInsights}
          studyPod={studyPod}
          onLeavePod={() => setStudyPod({ isActive: false, goal: '', members: [] })}
          onOpenPulseLive={() => handleOpenModal('pulseLive')}
          cognitiveLoad={cognitiveLoad}
        />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <TasksSection tasks={tasks} onAddTask={handleAddTask} onToggleTask={handleToggleTask} onDeleteTask={handleDeleteTask} onUpdateTaskPriority={handleUpdateTaskPriority} />
          <NotesSection notes={notes} onOpenModal={handleOpenModal} onNoteScanned={handleNoteScanned} />
        </div>
        <QuickTools onOpenModal={handleOpenModal} onWellBeingCheck={handleWellBeingCheck} />
      </main>
      <Footer onOpenModal={handleOpenModal} />
      
      <AiChatButton onClick={() => setShowAiSolver(true)} />
      <AiSolver 
        isOpen={showAiSolver}
        onClose={() => setShowAiSolver(false)}
        userName={userName}
        setUserName={setUserName}
        onAddTask={handleAddTask}
      />
      
      {showMusicPlayer && <MusicController onClose={() => setShowMusicPlayer(false)} />}
      
      {/* Modal Manager */}
      {modalContent && (
        <div className="fixed inset-0 z-50 bg-slate-400/30 dark:bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={handleCloseModal}>
          <div onClick={e => e.stopPropagation()}>
            {modalContent.type === 'note' && <NoteModal note={modalContent.data} onSave={handleSaveNote} onDelete={handleDeleteNote} onClose={handleCloseModal} onOpenModal={handleOpenModal} />}
            {modalContent.type === 'ranks' && <RanksModal onClose={handleCloseModal} />}
            {modalContent.type === 'stats' && <StatsModal onClose={handleCloseModal} userName={userName} focusSessionHistory={focusSessionHistory} onOpenModal={handleOpenModal} />}
            {modalContent.type === 'build' && <BuildModal onClose={handleCloseModal} />}
            {modalContent.type === 'calculator' && <CalculatorModal onClose={handleCloseModal} />}
            {modalContent.type === 'graphingCalculator' && <GraphingCalculatorModal onClose={handleCloseModal} />}
            {modalContent.type === 'aiRatingInfo' && <AIRatingInfoModal rating={aiRating} onClose={handleCloseModal} />}
            {modalContent.type === 'fileEditor' && <FileEditorModal file={modalContent.data.file} onClose={handleCloseModal} onSave={(file) => handleSaveNote({ ...notes.find(n => n.id === modalContent.data.noteId)!, file })} />}
            {modalContent.type === 'fullScreenPomodoro' && <FullScreenPomodoroModal {...pomodoroControls} onClose={handleCloseModal} />}
            {modalContent.type === 'leaderboard' && <LeaderboardModal onClose={handleCloseModal} currentUser={{ name: userName, xp, rank }} />}
            {modalContent.type === 'quiz' && <QuizModal note={modalContent.data.note} onClose={handleCloseModal} />}
            {modalContent.type === 'studyPodSetup' && <StudyPodSetupModal onClose={handleCloseModal} onStart={(goal) => { setStudyPod({ isActive: true, goal, members: [{ name: userName, avatar: userName.charAt(0), isYou: true, focusStreak: 1, isLeader: true }]}); handleCloseModal(); }} />}
            {modalContent.type === 'mindMap' && <MindMapModal mindMap={modalContent.data || { id: Date.now().toString(), title: "New Mind Map", nodes: [], created: Date.now() }} onSave={(mm) => { setMindMaps(mms => mms.some(m => m.id === mm.id) ? mms.map(m => m.id === mm.id ? mm : m) : [...mms, mm]); handleCloseModal();}} onClose={handleCloseModal} />}
            {modalContent.type === 'wellBeing' && <WellBeingModal suggestion={burnoutSuggestion} onClose={handleCloseModal} />}
            {modalContent.type === 'summarizer' && <SummarizerModal onClose={handleCloseModal} />}
            {modalContent.type === 'welcomeEmail' && <WelcomeEmailModal userName={userName} userEmail={userEmail} onClose={handleCloseModal} />}
            {modalContent.type === 'legal' && <LegalModal policyType={modalContent.data.policyType} onClose={handleCloseModal} />}
            {modalContent.type === 'pulseLive' && <PulseLiveModal isOpen={true} onClose={handleCloseModal} />}
            {modalContent.type === 'focusFlow' && <FocusFlowModal tasks={tasks} notes={notes} onClose={handleCloseModal} />}
            {modalContent.type === 'sessionRewind' && <SessionRewindModal session={modalContent.data} tasks={tasks} notes={notes} onClose={handleCloseModal} />}
            {modalContent.type === 'collaborationCanvas' && <CollaborationCanvasModal podGoal={modalContent.data.podGoal} onClose={handleCloseModal} />}
            {modalContent.type === 'conceptStressTest' && <ConceptStressTestModal onClose={handleCloseModal} />}
            {modalContent.type === 'imageStudio' && <ImageStudioModal onClose={handleCloseModal} />}
            {modalContent.type === 'videoStudio' && <VideoStudioModal notes={notes} onClose={handleCloseModal} />}
            {modalContent.type === 'pulseMarketplace' && <PulseMarketplaceModal pulseCredits={pulseCredits} onClose={handleCloseModal} />}
            {modalContent.type === 'dreamJournal' && <DreamJournalModal dreams={dreams} setDreams={setDreams} tasks={tasks} notes={notes} onClose={handleCloseModal} />}
            {modalContent.type === 'dailyLog' && <DailyLogModal dailyLogs={dailyLogs} setDailyLogs={setDailyLogs} onClose={handleCloseModal} />}
            {modalContent.type === 'dejaLearn' && <DejaLearnModal notes={notes} tasks={tasks} onClose={handleCloseModal} />}
            {modalContent.type === 'globalPulseMesh' && <GlobalPulseMeshModal onClose={handleCloseModal} />}
            {modalContent.type === 'researchAssistant' && <ResearchAssistantModal onClose={handleCloseModal} />}
            {modalContent.type === 'studyYoutube' && <StudyYoutubeModal onClose={handleCloseModal} />}
          </div>
        </div>
      )}
    </>
  );
}

export default App;
